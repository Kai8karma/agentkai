# GTM OS

A self-hosted GTM operating system: your CRM, your keys, your machine. GTM OS
scores and operates your go-to-market data with agents that run **locally**
via the `claude` CLI — nothing about your CRM leaves your infrastructure
unless you point it at a service you already use (HubSpot).

**Positioning:** audit-first, self-hosted, zero-egress as the tiebreaker.
Every other CRM tool asks you to pour your pipeline into their cloud. GTM OS
runs the audit engine and the agent harness on your machine, against your
own HubSpot token, with a receipts log you can read.

## Install

Requires Python 3.11+.

```bash
# uv (recommended)
uv pip install -e .

# or plain pip
pip install -e .
```

This installs the `gtmos` console script (see `pyproject.toml`).

## Command reference

GTM OS covers a full GTM team from one CLI. Role map (written into
`gtmos-team.json` by `gtmos init`):

| role | commands |
|---|---|
| founder / CRO | `today`, `audit`, `abm`, `prospect`, `stalk`, `draft`, `brief`, `outcomes`, `team` |
| RevOps | `today`, `audit`, `funnel`, `weekly`, `eval` |
| SDR / outbound | `today`, `prospect`, `stalk`, `draft`, `play` |
| marketing / ABM | `today`, `abm`, `draft`, `play` |

Everyone's day starts with the same command — `gtmos today` — and
non-terminal teammates get the same data in a browser via `gtmos serve`.
The full operating cadence lives in
[`docs/TEAM-PLAYBOOK.md`](docs/TEAM-PLAYBOOK.md).

`audit`, `funnel`, `play` (planning), `eval`, `weekly`, `init`, and `team`
are deterministic, offline-capable Python — no LLM in the score path.
`prospect`, `stalk`, `draft`, `brief`, and `play --draft` are **harness
commands**: they shell out to the `claude` CLI and lean on whatever MCP
servers (HubSpot, Apollo, LinkedIn, etc.) you have authorized in your own
Claude Code setup. `outcomes` wraps the `brain` CLI to log recall outcomes.

### `gtmos audit`

Deterministic CRM Integrity Score. Paginates a HubSpot portal (or reads a
JSON export offline), scores every record across five dimensions
(completeness, validity, freshness, ownership, consistency — see
[`docs/integrity-score-methodology.md`](docs/integrity-score-methodology.md)),
clusters duplicates, and estimates revenue leaking out through unreachable
records.

```bash
# live portal, using an ACV of $8,000 for the $-leak estimate
export GTMOS_HUBSPOT_TOKEN=pat-xxxxxxxx
gtmos audit --acv 8000 --out report.json

# offline, from an exported JSON dump (no token needed)
gtmos audit --input contacts.json --acv 8000 --out report.json
```

### `gtmos funnel`

Deterministic deal-stage revenue-leak analysis — the "where you're losing
money" engine, on deals rather than contacts. Builds a stage table,
survivorship conversion funnel, stalled-deal detection, and a $-leak model
(`closed-lost value + 0.5 × stalled open value`, with median imputation for
unvalued deals). Reads `--acv` and `stall_days` defaults from
`gtmos-team.json` when present.

```bash
gtmos funnel --input deals.json --out ./funnel-out
gtmos funnel --portal --stall-days 30       # live, GTMOS_HUBSPOT_TOKEN
```

### `gtmos init` / `gtmos team`

Scaffolds a team workspace: `gtmos-team.json` (roles, ICP, ACV, stage
config, action-oriented tiers), `DOCTRINE.md` (operating manual),
`PLAN.md` (wave-based plan), `PLAYS.md`. Idempotent; `--force` overwrites.
`gtmos team` shows or edits the config.

```bash
gtmos init --name "Acme GTM"
gtmos team --set team.acv=9000
gtmos team --get team.acv
```

### `gtmos play`

Signal-play library + multi-touch sequence planner. Four built-in plays
(post-merger, new-revops-hire, hiring-spree, compliance-wall), each a 4–5
touch comment-before-DM sequence over ~14 days. Planning is deterministic;
`--draft` upgrades copy per target through the harness (capped at 10).

```bash
gtmos play list
gtmos play show compliance-wall
gtmos play run new-revops-hire --targets targets.json --start-date 2026-07-14
```

### `gtmos eval`

The eval harness (catch silent failures before customers do): audit
regression against a committed golden, determinism check, receipts-log
integrity, and a static harness-contract scan (no LLM calls outside the
chokepoint). `--judge` adds an LLM-graded report-quality check. Exit 1 on
any failure — wire it into pre-push.

```bash
gtmos eval
gtmos eval --judge
```

### `gtmos weekly`

Closed-loop weekly ops review. Assembles whatever exists — audit score,
funnel leak, harness activity from the receipts log — into
`weekly-review.md` with a leak headline and gaps list. Missing sources are
reported, never fatal.

```bash
gtmos weekly
```

### `gtmos today`

The morning loop — one role-aware checklist assembled from everything the
OS knows: stalled deals (funnel), audit grade, due/overdue play touches
(with copy), unstarted targets, yesterday's activity pulse. Overdue first,
then by dollars at risk.

```bash
gtmos today                  # whole team
gtmos today --role sdr       # just your section
```

Touches you actually send get logged the same minute — the state file is
the truth `today` reads tomorrow:

```bash
gtmos play touch new-revops-hire --target "Acme" --step 2
gtmos play status new-revops-hire
```

### `gtmos prompts`

The prompt pack: every harness prompt is versioned, inspectable, and
overridable per workspace — tune the voice without forking code.

```bash
gtmos prompts list
gtmos prompts show draft-outreach
gtmos prompts export         # writes gtmos-prompts.json; edit what you keep
```

### `gtmos serve`

Local web dashboard for non-terminal roles — reads the same JSON artifacts
the CLI writes (leak headline, role checklists, funnel, plays progress,
weekly review). Zero-egress holds: localhost by default, `--lan` to expose
on the office network, no external assets, read-only.

```bash
gtmos serve                  # http://127.0.0.1:8390
```

### `gtmos prospect`

Harness command. Builds a targeted lead list against an ICP description,
using whatever prospecting MCP (Apollo, HubSpot, etc.) is available in your
Claude Code session, and returns tagged, deduplicated candidates.

```bash
gtmos prospect "Series A-C fintech, RevOps or Sales Ops title, 50-500 employees" --count 25

# offline, from a pre-fetched candidate leads JSON (no MCP/network needed)
gtmos prospect "Series A-C fintech" --input candidates.json --dry-run
```

### `gtmos stalk`

Harness command. Pulls together a personalization brief on a single
contact — public profile, recent activity, prior CRM touch history — and
suggests an opening hook for outreach.

```bash
gtmos stalk "Jane Doe" --company "Acme Robotics"

# offline, from a pre-fetched CRM context JSON (no HubSpot token needed)
gtmos stalk "Jane Doe" --company "Acme Robotics" --input crm-context.json --dry-run
```

### `gtmos draft`

Harness command. Drafts outreach copy or a narrative summary (e.g. an audit
cover note) from a structured input, in your voice.

```bash
gtmos draft --type linkedin "why most CRM audits miss the $-leak"
```

### `gtmos brief`

Harness command. Assembles a pre-call or morning brief from CRM state plus
whatever context sources (calendar, brain memory, recent emails) your
Claude Code session has access to.

```bash
gtmos brief

# offline, from a pre-fetched pipeline state JSON (no HubSpot token needed)
gtmos brief --input pipeline.json --dry-run
```

### `gtmos outcomes`

Thin wrapper around the `brain` CLI (`kai-brain`). Logs a win/loss/neutral
outcome against a recall or decision so the accuracy loop stays honest.

```bash
gtmos outcomes --log "mem_9182 win"
gtmos outcomes --roi
```

## Architecture

```
                 ┌─────────────────────────┐
  HubSpot API ──▶│   fetch layer (REST)    │
  --input file ─▶│   or JSON file fallback │
                 └───────────┬─────────────┘
                             │ records
                             ▼
                 ┌─────────────────────────┐
                 │  deterministic audit    │   <- no LLM here.
                 │  engine (pure Python)   │      pure functions,
                 │  score → dupes → $-leak │      unit-testable.
                 └───────────┬─────────────┘
                             │ report.json
                             ▼
                 ┌─────────────────────────┐
                 │   gtmos/harness.py      │   <- single chokepoint
                 │   run_harness()         │      for every claude CLI
                 │                         │      subprocess call
                 └───────────┬─────────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
          prospect        stalk      draft / brief
        (narrative / drafting / research — LLM-backed, MCP-backed)
                             │
                             ▼
                 ~/.gtmos/receipts.jsonl
        (ts, command, prompt_chars, duration_s, exit — every call)
```

Two hard rules enforce this split:

- **Scoring is deterministic.** The audit engine never calls an LLM. Every
  score is reproducible from the same input.
- **All LLM calls go through one chokepoint.** `run_harness()` in
  `gtmos/harness.py` is the only place that shells to `claude`. One
  subprocess call per invocation, 180s per-call timeout, and a receipt
  written for every call; commands that loop on harness calls (like
  `draft`'s judge-revision loop) are bounded by the shared
  `MAX_ITERATIONS = 3`. Agent usage stays auditable, not a black box.

## Status (honest)

- **`gtmos audit` / `funnel` / `init` / `team` / `play` (planning) /
  `eval` / `weekly`** — the production paths. Deterministic,
  offline-testable, no external dependency beyond an optional HubSpot
  token.
- **`gtmos prospect` / `stalk` / `draft` / `brief`** — harness commands.
  They require a working `claude` CLI on your machine and whatever MCP
  servers the command needs (HubSpot, Apollo, LinkedIn, etc.) to already be
  authorized in your Claude Code environment. Output quality depends on
  those MCPs being connected.
- **`gtmos outcomes`** — a thin wrapper around the `brain` CLI (kai-brain).
  It assumes `brain` is installed and on `PATH`; GTM OS does not ship or
  vendor it.

## Self-hosting model

The only two systems GTM OS talks to outside your machine are:

1. The **HubSpot API** — the CRM you already use, via a token you hold
   (`GTMOS_HUBSPOT_TOKEN`).
2. The **`claude` CLI** — run as a local subprocess, using your own Claude
   Code auth.

Everything else — the scoring engine, the receipts log, the dupe pass, the
$-leak model — runs as plain Python on your machine.
