#!/usr/bin/env bash
# Offline smoke test runner for GTM OS. Zero network, zero `claude` calls.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

export PYTHONPATH="$REPO_ROOT"

if python3 -c "import pytest" >/dev/null 2>&1; then
  if python3 -m pytest tests/ -x -q; then
    echo "PASS: smoke tests green (pytest)"
    exit 0
  else
    echo "FAIL: smoke tests failed (pytest)"
    exit 1
  fi
else
  if python3 -m unittest discover -s tests -v; then
    echo "PASS: smoke tests green (unittest)"
    exit 0
  else
    echo "FAIL: smoke tests failed (unittest)"
    exit 1
  fi
fi
