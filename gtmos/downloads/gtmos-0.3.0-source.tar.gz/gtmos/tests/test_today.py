"""Offline tests for gtmos.today (the daily loop). No network, no LLM.

Builds a tiny fixture workspace per test (team config, funnel.json,
scores.json, a play plan + state) under tmp_path, and always injects
`today` / paths_override so results are deterministic.
"""

from __future__ import annotations

import argparse
import json

from gtmos.today import cli_entry, engine


def _make_args(**overrides) -> argparse.Namespace:
    defaults = dict(role=None, dir=None, out=None, today=None, dry_run=False)
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


TEAM_CONFIG = {
    "team": {
        "name": "Acme",
        "icp": "",
        "acv": 9000.0,
        "roles": {
            "founder": ["audit", "abm"],
            "revops": ["audit", "funnel", "weekly"],
            "sdr": ["prospect", "play"],
            "marketing": ["abm", "play"],
        },
    },
    "stages": {"order": ["prospect", "closed_won"], "stall_days": 21},
    "tiers": ["respond", "nurture", "wait", "skip"],
}

FUNNEL = {
    "leak_total": 42000.0,
    "stalled_deals": [
        {"id": "1", "dealname": "Small Co", "dealstage": "qualifiedtobuy", "amount": 1000.0, "days_stale": 25, "owner": "sam"},
        {"id": "2", "dealname": "Big Co", "dealstage": "contractsent", "amount": 50000.0, "days_stale": 30, "owner": "lee"},
        {"id": "3", "dealname": "Mid Co", "dealstage": "presentationscheduled", "amount": 10000.0, "days_stale": 22, "owner": "sam"},
    ],
}

SCORES = {"portal_score": 79.96, "grade": "B"}


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _play_plan(company: str, touches: list[dict]) -> dict:
    return {
        "play": "post-merger",
        "start_date": "2026-01-01",
        "targets": [{"target": {"company": company, "first_name": "Priya"}, "touches": touches}],
        "warnings": [],
    }


def _build_workspace(tmp_path):
    _write_json(tmp_path / "gtmos-team.json", TEAM_CONFIG)
    _write_json(tmp_path / "audit-out" / "scores.json", SCORES)
    _write_json(tmp_path / "funnel-out" / "funnel.json", FUNNEL)

    plan = _play_plan(
        "Acme Corp",
        [
            {"step": 1, "channel": "linkedin_comment", "day_offset": 0, "date": "2026-01-01", "copy": "Congrats on the merger, Acme Corp — this is a fairly long line of outreach copy text that runs well past eighty characters."},
            {"step": 2, "channel": "email", "day_offset": 3, "date": "2026-07-13", "copy": "Following up today."},
        ],
    )
    play_dir = tmp_path / "play-out"
    play_dir.mkdir(parents=True, exist_ok=True)
    (play_dir / "post-merger-plan.json").write_text(json.dumps(plan), encoding="utf-8")
    return plan


TODAY = "2026-07-13"


# ---------------------------------------------------------------------------
# build_today — full workspace
# ---------------------------------------------------------------------------


def test_build_today_full_workspace_only_activity_gap(tmp_path):
    _build_workspace(tmp_path)

    result = engine.build_today(workspace=str(tmp_path), today=TODAY, paths_override={"receipts_path": tmp_path / "receipts.jsonl"})

    assert result["today"] == TODAY
    assert set(result["sections"]) == {"revops", "sdr", "marketing", "founder"}
    # funnel + audit + play present, only receipts (never written) gaps.
    assert any("activity" in g for g in result["gaps"])
    assert not any(g.startswith("funnel") for g in result["gaps"])
    assert not any(g.startswith("audit") for g in result["gaps"])
    assert not any(g.startswith("plays") for g in result["gaps"])


def test_build_today_revops_section_has_audit_and_stalled_deals(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    revops_lines = [item["line"] for item in result["sections"]["revops"]]
    assert any("80.0" in line and "B" in line for line in revops_lines)
    assert any("Big Co" in line for line in revops_lines)


def test_build_today_overdue_first_ordering(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    sdr_items = result["sections"]["sdr"]
    assert len(sdr_items) == 2
    # step 1 (date 2026-01-01) is overdue; step 2 (date == today) is not.
    assert sdr_items[0]["overdue"] is True
    assert sdr_items[1]["overdue"] is False
    assert "overdue" in sdr_items[0]["line"]


def test_build_today_stalled_deals_sorted_by_amount_desc(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    deal_items = [i for i in result["sections"]["revops"] if i["type"] == "stalled_deal"]
    amounts = [i["amount"] for i in deal_items]
    assert amounts == sorted(amounts, reverse=True)
    assert amounts[0] == 50000.0


def test_build_today_marketing_section_lists_unstarted_targets(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    marketing_lines = [item["line"] for item in result["sections"]["marketing"]]
    assert any("post-merger" in line and "Acme Corp" in line for line in marketing_lines)


def test_build_today_copy_snippet_capped_at_80_chars(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    touch_item = next(i for i in result["sections"]["sdr"] if i["step"] == 1)
    # The line embeds the (<=80 char) snippet; just confirm the raw copy
    # was longer than 80 chars so truncation was exercised.
    original_plan = json.loads((tmp_path / "play-out" / "post-merger-plan.json").read_text())
    raw_copy = original_plan["targets"][0]["touches"][0]["copy"]
    assert len(raw_copy) > 80
    assert raw_copy[:80] in touch_item["line"]


def test_build_today_summary_counts_actions_and_biggest_leak(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), today=TODAY)

    summary = result["summary"]
    # 3 stalled deals + 2 due touches + 1 unstarted-play entry = 6 actions.
    assert summary["actions"] == 6
    assert summary["overdue"] == 1
    assert summary["biggest_leak"] == 42000.0


# ---------------------------------------------------------------------------
# role filtering
# ---------------------------------------------------------------------------


def test_build_today_role_filter_returns_single_section(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), role="sdr", today=TODAY)

    assert set(result["sections"]) == {"sdr"}


def test_build_today_role_filter_case_insensitive(tmp_path):
    _build_workspace(tmp_path)
    result = engine.build_today(workspace=str(tmp_path), role="SDR", today=TODAY)

    assert set(result["sections"]) == {"sdr"}


def test_build_today_unknown_role_raises(tmp_path):
    _build_workspace(tmp_path)
    try:
        engine.build_today(workspace=str(tmp_path), role="engineering", today=TODAY)
        assert False, "expected ValueError"
    except ValueError as exc:
        assert "engineering" in str(exc)
        assert "sdr" in str(exc)


# ---------------------------------------------------------------------------
# missing everything
# ---------------------------------------------------------------------------


def test_build_today_missing_everything_returns_gaps_no_crash(tmp_path):
    result = engine.build_today(
        workspace=str(tmp_path),
        today=TODAY,
        paths_override={"receipts_path": tmp_path / "nope.jsonl"},
    )

    assert result["gaps"]
    assert any(g.startswith("audit") for g in result["gaps"])
    assert any(g.startswith("funnel") for g in result["gaps"])
    assert any(g.startswith("plays") for g in result["gaps"])
    assert any(g.startswith("activity") for g in result["gaps"])
    assert result["summary"]["actions"] == 0
    assert result["summary"]["biggest_leak"] == 0.0


# ---------------------------------------------------------------------------
# cli_entry
# ---------------------------------------------------------------------------


def test_cli_today_writes_report_files_and_prints_summary(tmp_path, capsys):
    _build_workspace(tmp_path)
    out_dir = tmp_path / "today-out"

    rc = cli_entry.run(_make_args(dir=str(tmp_path), out=str(out_dir), today=TODAY))
    out = capsys.readouterr().out

    assert rc == 0
    assert out.startswith("today: 6 actions (1 overdue)")
    assert (out_dir / "today.md").exists()
    assert (out_dir / "today.json").exists()

    payload = json.loads((out_dir / "today.json").read_text(encoding="utf-8"))
    assert payload["today"] == TODAY


def test_cli_today_unknown_role_exits_2(tmp_path, capsys):
    _build_workspace(tmp_path)

    rc = cli_entry.run(_make_args(dir=str(tmp_path), role="engineering", today=TODAY, out=str(tmp_path / "out")))
    out = capsys.readouterr().out

    assert rc == 2
    assert "today:" in out
    assert "unknown role" in out


def test_cli_today_dry_run_prints_plan_without_writing(tmp_path, capsys):
    out_dir = tmp_path / "today-out"
    rc = cli_entry.run(_make_args(dir=str(tmp_path), out=str(out_dir), dry_run=True))
    out = capsys.readouterr().out

    assert rc == 0
    assert "dry-run" in out
    assert not out_dir.exists()
