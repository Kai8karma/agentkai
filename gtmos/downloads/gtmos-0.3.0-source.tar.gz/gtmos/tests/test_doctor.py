"""Offline tests for gtmos.doctor — the enterprise preflight check. No
network, no LLM; env/paths are always injected so tests never touch the
real PATH, environment variables, or home directory.
"""

from __future__ import annotations

import argparse
import json
import stat

from gtmos import doctor


def _ns(**kwargs) -> argparse.Namespace:
    defaults = dict(dir=None, json=False, env=None, home=None, which=None)
    defaults.update(kwargs)
    return argparse.Namespace(**defaults)


class _FakeVersion:
    def __init__(self, major, minor, micro):
        self.major = major
        self.minor = minor
        self.micro = micro


# -- individual checks ----------------------------------------------------


def test_check_python_version_ok_for_supported_version():
    result = doctor.check_python_version(version_info=_FakeVersion(3, 12, 0))
    assert result.status == "ok"


def test_check_python_version_fails_below_minimum():
    result = doctor.check_python_version(version_info=_FakeVersion(3, 10, 0))
    assert result.status == "fail"


def test_check_claude_cli_ok_when_on_path():
    result = doctor.check_claude_cli(which=lambda name: "/usr/local/bin/claude")
    assert result.status == "ok"
    assert result.detail == "/usr/local/bin/claude"


def test_check_claude_cli_warns_when_missing():
    result = doctor.check_claude_cli(which=lambda name: None)
    assert result.status == "warn"


def test_check_hubspot_token_absent_warns():
    result = doctor.check_hubspot_token(env={})
    assert result.status == "warn"


def test_check_hubspot_token_present_masks_it():
    token = "secret-crm-token-abc123XYZ"
    result = doctor.check_hubspot_token(env={"GTMOS_HUBSPOT_TOKEN": token})
    assert result.status == "ok"
    assert token not in result.detail
    assert result.detail.startswith(token[:6])


def test_check_workspace_warns_when_no_config(tmp_path):
    result = doctor.check_workspace(str(tmp_path))
    assert result.status == "warn"
    assert "gtmos init" in result.detail


def test_check_workspace_ok_when_config_present(tmp_path):
    (tmp_path / "gtmos-team.json").write_text("{}", encoding="utf-8")
    result = doctor.check_workspace(str(tmp_path))
    assert result.status == "ok"


def test_check_gtmos_home_warns_when_missing(tmp_path):
    result = doctor.check_gtmos_home(home=tmp_path / ".gtmos")
    assert result.status == "warn"


def test_check_gtmos_home_tightens_loose_permissions(tmp_path):
    home = tmp_path / ".gtmos"
    home.mkdir()
    home.chmod(0o755)
    result = doctor.check_gtmos_home(home=home)
    assert result.status == "ok"
    assert stat.S_IMODE(home.stat().st_mode) == 0o700
    assert "chmod" in result.detail


def test_check_gtmos_home_counts_receipts(tmp_path):
    home = tmp_path / ".gtmos"
    home.mkdir(mode=0o700)
    (home / "receipts.jsonl").write_text('{"a": 1}\n{"b": 2}\n\n', encoding="utf-8")
    result = doctor.check_gtmos_home(home=home)
    assert "2 receipt" in result.detail


def test_check_writable_cwd_ok(tmp_path):
    result = doctor.check_writable_cwd(str(tmp_path))
    assert result.status == "ok"


# -- run_checks / run ------------------------------------------------------


def test_run_checks_all_ok_when_environment_is_healthy(tmp_path):
    (tmp_path / "gtmos-team.json").write_text("{}", encoding="utf-8")
    home = tmp_path / ".gtmos"
    home.mkdir(mode=0o700)

    results = doctor.run_checks(
        start_dir=str(tmp_path),
        env={"GTMOS_HUBSPOT_TOKEN": "tok-123456789"},
        home=home,
        which=lambda name: "/usr/bin/claude",
    )
    assert all(r.status != "fail" for r in results)


def test_run_exits_zero_when_no_fail(tmp_path):
    args = _ns(dir=str(tmp_path), env={}, home=tmp_path / ".gtmos", which=lambda name: None)
    exit_code = doctor.run(args)
    assert exit_code == 0


def test_run_json_flag_emits_parseable_json(tmp_path, capsys):
    args = _ns(dir=str(tmp_path), json=True, env={}, home=tmp_path / ".gtmos", which=lambda name: None)
    exit_code = doctor.run(args)
    assert exit_code == 0

    out = capsys.readouterr().out
    payload = json.loads(out)
    assert isinstance(payload, list)
    names = {c["name"] for c in payload}
    assert "python-version" in names
    assert "hubspot-token" in names


def test_run_full_token_never_appears_in_output(tmp_path, capsys):
    token = "super-secret-full-token-value-should-not-leak"
    args = _ns(dir=str(tmp_path), env={"GTMOS_HUBSPOT_TOKEN": token}, home=tmp_path / ".gtmos", which=lambda name: None)
    doctor.run(args)
    out = capsys.readouterr().out
    assert token not in out


def test_run_fails_when_cwd_not_writable(tmp_path, monkeypatch):
    args = _ns(dir=str(tmp_path), env={}, home=tmp_path / ".gtmos", which=lambda name: None)
    monkeypatch.setattr(doctor.os, "access", lambda path, mode: False)
    exit_code = doctor.run(args)
    assert exit_code == 1
