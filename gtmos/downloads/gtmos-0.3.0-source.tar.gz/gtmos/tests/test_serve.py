"""Offline tests for gtmos.serve — the local dashboard. No network beyond
loopback, no LLM.

Spins up a real WorkspaceHTTPServer bound to port 0 (OS-assigned) in a
background thread, fetches with urllib, and shuts it down in the fixture
teardown so no server outlives a test.
"""

from __future__ import annotations

import argparse
import json
import threading
import urllib.error
import urllib.request

import pytest

from gtmos.serve import cli_entry
from gtmos.serve.server import build_server


@pytest.fixture
def running_server(tmp_path):
    server = build_server("127.0.0.1", 0, str(tmp_path))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    port = server.server_address[1]
    try:
        yield tmp_path, port
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def _get(port: int, path: str) -> tuple[int, str]:
    url = f"http://127.0.0.1:{port}{path}"
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            return resp.status, resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8")


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


# -- / --------------------------------------------------------------------

def test_dashboard_shows_leak_headline_when_funnel_present(running_server):
    tmp_path, port = running_server
    _write_json(tmp_path / "funnel-out" / "funnel.json", {"leak_total": 42000.0, "stalled_count": 3})

    status, body = _get(port, "/")

    assert status == 200
    assert "$42,000" in body


def test_dashboard_empty_state_when_funnel_missing(running_server):
    tmp_path, port = running_server

    status, body = _get(port, "/")

    assert status == 200
    assert "gtmos funnel" in body


# -- /role/<name> -----------------------------------------------------------

def test_role_unknown_returns_404_or_role_list(running_server):
    _, port = running_server

    status, body = _get(port, "/role/not-a-real-role")

    assert status == 404 or "known roles" in body.lower() or "role" in body.lower()


# -- /plays -----------------------------------------------------------------

def test_plays_renders_state_progress(running_server):
    tmp_path, port = running_server
    play_dir = tmp_path / "play-out"
    play_dir.mkdir(parents=True)

    plan = {
        "play": "post-merger",
        "start_date": "2026-01-01",
        "targets": [
            {
                "target": {"company": "Acme", "first_name": "Priya"},
                "touches": [
                    {"step": 1, "channel": "email", "date": "2026-01-01", "copy": "hi"},
                    {"step": 2, "channel": "email", "date": "2026-01-05", "copy": "bye"},
                ],
            }
        ],
        "warnings": [],
    }
    (play_dir / "post-merger-plan.json").write_text(json.dumps(plan), encoding="utf-8")

    state = {"play": "post-merger", "targets": {"Acme": {"steps_done": [1], "last_touch": "2026-01-01T00:00:00+00:00"}}}
    (play_dir / "post-merger-state.json").write_text(json.dumps(state), encoding="utf-8")

    status, body = _get(port, "/plays")

    assert status == 200
    assert "Acme" in body
    assert "1/2" in body


def test_plays_empty_state_when_no_plans(running_server):
    _, port = running_server

    status, body = _get(port, "/plays")

    assert status == 200
    assert "gtmos play run" in body


# -- html escaping ------------------------------------------------------------

def test_funnel_page_escapes_company_name(running_server):
    tmp_path, port = running_server
    funnel = {
        "leak_total": 1000.0,
        "stalled_count": 1,
        "stage_counts": {},
        "stage_amounts": {},
        "leak_by_owner": {},
        "stalled_deals": [
            {
                "id": "1",
                "dealname": "<script>alert(1)</script>",
                "dealstage": "qualifiedtobuy",
                "amount": 500.0,
                "days_stale": 10,
                "owner": "sam",
            }
        ],
    }
    _write_json(tmp_path / "funnel-out" / "funnel.json", funnel)

    status, body = _get(port, "/funnel")

    assert status == 200
    assert "<script>alert(1)</script>" not in body
    assert "&lt;script&gt;" in body


# -- /api/refresh -------------------------------------------------------------

def test_api_refresh_returns_204(running_server):
    _, port = running_server
    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/refresh", method="POST", data=b"")
    with urllib.request.urlopen(req, timeout=5) as resp:
        assert resp.status == 204


# -- unknown path -------------------------------------------------------------

def test_unknown_path_returns_404_json(running_server):
    _, port = running_server

    status, body = _get(port, "/nope")

    assert status == 404
    payload = json.loads(body)
    assert payload["error"] == "not found"


# -- cli_entry: --host 0.0.0.0 without --lan ---------------------------------

def test_bind_0000_without_lan_exits_2():
    args = argparse.Namespace(host="0.0.0.0", port=0, dir=".", lan=False, dry_run=False)

    assert cli_entry.run(args) == 2


def test_dry_run_prints_routes_and_does_not_bind(capsys):
    args = argparse.Namespace(host="127.0.0.1", port=8390, dir=".", lan=False, dry_run=True)

    exit_code = cli_entry.run(args)

    assert exit_code == 0
    out = capsys.readouterr().out
    assert "/funnel" in out
    assert "/plays" in out
