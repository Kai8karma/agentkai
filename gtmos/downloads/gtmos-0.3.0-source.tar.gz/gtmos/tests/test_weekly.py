"""Offline tests for gtmos.weekly — closed-loop weekly ops review. No network, no LLM.

cli.py wiring for `gtmos weekly` happens later (integrator's job) so these
tests call gtmos.weekly.cli_entry.run() directly with a hand-built
argparse.Namespace, exactly like the module will be invoked once wired.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timedelta, timezone

from gtmos.weekly import assemble, cli_entry


def _ns(**kwargs) -> argparse.Namespace:
    return argparse.Namespace(**kwargs)


NOW = datetime(2026, 7, 13, tzinfo=timezone.utc)


def _write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _write_receipts(path, entries):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(json.dumps(e) for e in entries) + "\n", encoding="utf-8")


# -- gather: full / partial / none ---------------------------------------

def test_gather_full_sources_present(tmp_path):
    audit_path = tmp_path / "audit-out" / "scores.json"
    funnel_path = tmp_path / "funnel-out" / "funnel.json"
    receipts_path = tmp_path / "receipts.jsonl"

    _write_json(audit_path, {"portal_score": 79.96, "grade": "B"})
    _write_json(funnel_path, {"leak_total": 12000, "stalled_count": 4})
    _write_receipts(
        receipts_path,
        [{"ts": NOW.timestamp(), "command": "audit", "prompt_chars": 0, "duration_s": 0.1, "exit": 0}],
    )

    weekly = assemble.gather(audit_path=audit_path, funnel_path=funnel_path, receipts_path=receipts_path, now=NOW)

    assert weekly["audit"] == {"portal_score": 79.96, "grade": "B"}
    assert weekly["funnel"] == {"leak_total": 12000, "stalled_count": 4}
    assert weekly["activity"]["harness_calls_7d"] == 1
    assert weekly["gaps"] == []


def test_gather_partial_no_funnel(tmp_path):
    audit_path = tmp_path / "audit-out" / "scores.json"
    funnel_path = tmp_path / "funnel-out" / "funnel.json"  # not written
    receipts_path = tmp_path / "receipts.jsonl"  # not written

    _write_json(audit_path, {"portal_score": 55.0, "grade": "C"})

    weekly = assemble.gather(audit_path=audit_path, funnel_path=funnel_path, receipts_path=receipts_path, now=NOW)

    assert weekly["audit"] == {"portal_score": 55.0, "grade": "C"}
    assert weekly["funnel"] is None
    assert weekly["activity"] == {"harness_calls_7d": 0, "commands_breakdown": {}}
    assert any("funnel" in g for g in weekly["gaps"])
    assert any("activity" in g for g in weekly["gaps"])
    assert not any("audit" in g for g in weekly["gaps"])


def test_gather_none_all_gaps(tmp_path):
    audit_path = tmp_path / "audit-out" / "scores.json"
    funnel_path = tmp_path / "funnel-out" / "funnel.json"
    receipts_path = tmp_path / "receipts.jsonl"

    weekly = assemble.gather(audit_path=audit_path, funnel_path=funnel_path, receipts_path=receipts_path, now=NOW)

    assert weekly["audit"] is None
    assert weekly["funnel"] is None
    assert weekly["activity"] == {"harness_calls_7d": 0, "commands_breakdown": {}}
    assert len(weekly["gaps"]) == 3


# -- 7-day receipt windowing ----------------------------------------------

def test_gather_windows_receipts_to_last_7_days(tmp_path):
    receipts_path = tmp_path / "receipts.jsonl"
    in_window = NOW - timedelta(days=3)
    out_of_window = NOW - timedelta(days=10)

    _write_receipts(
        receipts_path,
        [
            {"ts": in_window.timestamp(), "command": "audit", "prompt_chars": 0, "duration_s": 0.1, "exit": 0},
            {"ts": in_window.timestamp(), "command": "audit", "prompt_chars": 0, "duration_s": 0.1, "exit": 0},
            {"ts": out_of_window.timestamp(), "command": "audit", "prompt_chars": 0, "duration_s": 0.1, "exit": 0},
        ],
    )

    weekly = assemble.gather(
        audit_path=tmp_path / "no-audit.json",
        funnel_path=tmp_path / "no-funnel.json",
        receipts_path=receipts_path,
        now=NOW,
    )

    assert weekly["activity"]["harness_calls_7d"] == 2
    assert weekly["activity"]["commands_breakdown"] == {"audit": 2}


# -- render ----------------------------------------------------------------

def test_render_writes_review_and_json(tmp_path):
    weekly = assemble.gather(
        audit_path=tmp_path / "no-audit.json",
        funnel_path=tmp_path / "no-funnel.json",
        receipts_path=tmp_path / "no-receipts.jsonl",
        now=NOW,
    )
    out_dir = tmp_path / "weekly-out"
    summary = assemble.render(weekly, str(out_dir))

    review_path = out_dir / "weekly-review.md"
    json_path = out_dir / "weekly.json"
    assert review_path.exists()
    assert json_path.exists()
    assert summary["report_path"] == str(review_path)

    text = review_path.read_text(encoding="utf-8")
    assert "Scoreboard" in text
    assert "losing money" in text
    assert "Gaps" in text
    assert "Next actions" in text


# -- cli_entry --------------------------------------------------------------

def test_cli_run_prints_leak_headline_when_available(tmp_path, capsys, monkeypatch):
    monkeypatch.chdir(tmp_path)
    _write_json(tmp_path / "audit-out" / "scores.json", {"portal_score": 79.96, "grade": "B"})
    _write_json(tmp_path / "funnel-out" / "funnel.json", {"leak_total": 12000, "stalled_count": 4})

    out_dir = tmp_path / "weekly-out"
    args = _ns(out=str(out_dir), dry_run=False)
    exit_code = cli_entry.run(args)

    assert exit_code == 0
    assert (out_dir / "weekly-review.md").exists()
    captured = capsys.readouterr()
    assert "portal score 80.0" in captured.out
    assert "funnel leak $12,000" in captured.out


def test_cli_run_dry_run_writes_nothing(tmp_path, capsys):
    out_dir = tmp_path / "weekly-out"
    args = _ns(out=str(out_dir), dry_run=True)
    exit_code = cli_entry.run(args)
    assert exit_code == 0
    assert not out_dir.exists()
    captured = capsys.readouterr()
    assert "dry-run" in captured.out
