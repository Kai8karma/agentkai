"""Tests for the prompt registry (gtmos.prompts), its CLI (gtmos.prompts_cli),
and the migrated inline-prompt commands. No network, no real `claude`
subprocess calls — run_harness is monkeypatched wherever a command's run()
is exercised end to end.
"""

from __future__ import annotations

import argparse
import json

import gtmos.harness as harness
from gtmos.prompts import PROMPTS, get_prompt, is_overridden, render_prompt
from gtmos import prompts_cli
from gtmos.commands import brief, draft, prospect, stalk

EXPECTED_NAMES = {
    "prospect",
    "stalk",
    "draft-linkedin",
    "draft-x",
    "draft-outreach",
    "brief",
    "play-draft",
    "eval-judge",
}

# ---------------------------------------------------------------------------
# registry completeness
# ---------------------------------------------------------------------------


def test_registry_has_exactly_the_eight_named_prompts():
    assert set(PROMPTS) == EXPECTED_NAMES


def test_every_declared_placeholder_appears_in_its_template():
    from string import Template

    for name, entry in PROMPTS.items():
        found = Template(entry["template"]).get_identifiers()
        declared = set(entry["placeholders"])
        assert declared == set(found), f"{name}: declared {declared} != found {found}"
        assert entry["template"].count("\n") + 1 <= 35, f"{name}: template over 35 lines"
        assert isinstance(entry["version"], int)
        assert entry["description"]


# ---------------------------------------------------------------------------
# get_prompt / render_prompt
# ---------------------------------------------------------------------------


def test_get_prompt_unknown_name_raises_keyerror():
    try:
        get_prompt("does-not-exist")
        assert False, "expected KeyError"
    except KeyError:
        pass


def test_render_prompt_safe_substitute_leaves_missing_tokens_visible():
    rendered = render_prompt("brief", ".", pipeline_block="PIPE-DATA")
    assert "PIPE-DATA" in rendered
    assert "$receipts_block" in rendered  # missing sub stays visible, no KeyError


def test_render_prompt_name_placeholder_does_not_collide_with_call_site(tmp_path):
    # stalk's own template placeholder is literally called "name" — this must
    # not collide with render_prompt's first positional "name" argument.
    rendered = render_prompt(
        "stalk", str(tmp_path), name="Jane Doe", company="Acme",
        coi_lanes="none", crm_block="CRM-BLOCK",
    )
    assert "Jane Doe" in rendered
    assert "Acme" in rendered


def test_workspace_override_wins_over_builtin(tmp_path):
    override = {"prospect": {"template": "OVERRIDDEN prospect template $icp"}}
    (tmp_path / "gtmos-prompts.json").write_text(json.dumps(override), encoding="utf-8")

    assert is_overridden("prospect", str(tmp_path)) is True
    assert is_overridden("stalk", str(tmp_path)) is False  # partial override, no error

    rendered = render_prompt("prospect", str(tmp_path), icp="ICP-X")
    assert rendered == "OVERRIDDEN prospect template ICP-X"


def test_workspace_override_found_by_walking_up_from_nested_dir(tmp_path):
    override = {"brief": {"template": "OVERRIDDEN brief"}}
    (tmp_path / "gtmos-prompts.json").write_text(json.dumps(override), encoding="utf-8")
    nested = tmp_path / "a" / "b" / "c"
    nested.mkdir(parents=True)

    assert is_overridden("brief", str(nested)) is True
    assert get_prompt("brief", str(nested)) == "OVERRIDDEN brief"


# ---------------------------------------------------------------------------
# prompts_cli
# ---------------------------------------------------------------------------


def _args(**overrides):
    defaults = dict(prompts_action=None, name=None, out=None, dir=None)
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


def test_cli_list_includes_every_registered_name(capsys):
    rc = prompts_cli.run(_args(prompts_action="list"))
    assert rc == 0
    out = capsys.readouterr().out
    for name in EXPECTED_NAMES:
        assert name in out


def test_cli_show_prints_effective_template_and_source(capsys):
    rc = prompts_cli.run(_args(prompts_action="show", name="brief"))
    assert rc == 0
    out = capsys.readouterr().out
    assert "source: builtin" in out
    assert "pipeline_block" in out


def test_cli_show_unknown_name_exits_1(capsys):
    rc = prompts_cli.run(_args(prompts_action="show", name="nope"))
    assert rc == 1


def test_cli_unknown_action_exits_2(capsys):
    rc = prompts_cli.run(_args(prompts_action="bogus"))
    assert rc == 2


def test_cli_export_edit_get_prompt_roundtrip(tmp_path, capsys):
    out_path = tmp_path / "gtmos-prompts.json"
    rc = prompts_cli.run(_args(prompts_action="export", out=str(out_path)))
    assert rc == 0
    assert out_path.exists()

    skeleton = json.loads(out_path.read_text(encoding="utf-8"))
    assert set(skeleton) == EXPECTED_NAMES
    skeleton["brief"]["template"] = "EDITED brief template $pipeline_block"
    out_path.write_text(json.dumps(skeleton), encoding="utf-8")

    assert is_overridden("brief", str(tmp_path)) is True
    rendered = render_prompt("brief", str(tmp_path), pipeline_block="P")
    assert rendered == "EDITED brief template P"

    rc = prompts_cli.run(_args(prompts_action="show", name="brief", dir=str(tmp_path)))
    assert rc == 0
    assert "source: override" in capsys.readouterr().out


# ---------------------------------------------------------------------------
# migrated commands build prompts via the registry
# ---------------------------------------------------------------------------


def _capture_harness(monkeypatch, module):
    captured = {}

    def fake_run_harness(command, prompt, allowed_tools, **kwargs):
        captured["command"] = command
        captured["prompt"] = prompt
        return "OK"

    monkeypatch.setattr(harness, "run_harness", fake_run_harness)
    return captured


def test_prospect_run_builds_prompt_via_registry(monkeypatch, tmp_path, capsys):
    captured = _capture_harness(monkeypatch, prospect)
    input_path = tmp_path / "leads.json"
    input_path.write_text(json.dumps([{"name": "Jane"}]), encoding="utf-8")

    args = argparse.Namespace(icp="fintech seed-stage", count=10, input=str(input_path))
    prospect.run(args)

    assert "fintech seed-stage" in captured["prompt"]
    assert "fit_reason must cite specific ICP terms" in captured["prompt"]  # registry marker


def test_stalk_run_builds_prompt_via_registry(monkeypatch, tmp_path):
    captured = _capture_harness(monkeypatch, stalk)
    args = argparse.Namespace(name="Jane Doe", company="Acme", input=None)
    stalk.run(args)

    assert "Jane Doe" in captured["prompt"]
    assert "Acme" in captured["prompt"]
    assert "recon only" in captured["prompt"]  # registry marker


def test_brief_run_builds_prompt_via_registry(monkeypatch, tmp_path):
    captured = _capture_harness(monkeypatch, brief)
    input_path = tmp_path / "pipeline.json"
    input_path.write_text(json.dumps({"deals": []}), encoding="utf-8")

    args = argparse.Namespace(input=str(input_path))
    brief.run(args)

    assert "No receipts logged yet." in captured["prompt"] or "receipts" in captured["prompt"]
    assert "highest-leverage actions" in captured["prompt"]  # registry marker


def test_draft_run_selects_registry_template_by_kind(monkeypatch):
    calls = []

    def fake_run_harness(command, prompt, allowed_tools, **kwargs):
        calls.append((command, prompt))
        if command == "draft":
            return "draft output"
        return "SCORES: VOICE=9 HOOK=9 DENSITY=9 CTA=9 FORMAT=9\nFEEDBACK: none"

    monkeypatch.setattr(harness, "run_harness", fake_run_harness)

    args = argparse.Namespace(type="linkedin", topic="shipping fast")
    draft.run(args)

    draft_prompt = calls[0][1]
    assert "shipping fast" in draft_prompt
    assert "LinkedIn ghostwriter" in draft_prompt  # registry marker unique to draft-linkedin
