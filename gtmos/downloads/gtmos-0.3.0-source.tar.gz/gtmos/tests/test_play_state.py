"""Offline tests for gtmos.plays.state (execution-state tracking) and the
"touch"/"status" actions on gtmos.plays.cli_entry. No network, no LLM.
"""

from __future__ import annotations

import argparse
import json

from gtmos.plays import cli_entry, state


def _make_args(**overrides) -> argparse.Namespace:
    defaults = dict(
        action=None,
        name=None,
        targets=None,
        out=None,
        start_date=None,
        draft=False,
        dry_run=False,
        target=None,
        step=None,
        today=None,
    )
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


def _sample_plan() -> dict:
    return {
        "play": "post-merger",
        "start_date": "2026-01-01",
        "targets": [
            {
                "target": {"company": "Acme Corp", "first_name": "Priya"},
                "touches": [
                    {"step": 1, "channel": "linkedin_comment", "day_offset": 0, "date": "2026-01-01", "copy": "hi"},
                    {"step": 2, "channel": "linkedin_dm", "day_offset": 3, "date": "2026-01-04", "copy": "hi2"},
                    {"step": 3, "channel": "email", "day_offset": 6, "date": "2026-01-07", "copy": "hi3"},
                ],
            },
            {
                "target": {"company": "Nimbus Freight", "first_name": "Dana"},
                "touches": [
                    {"step": 1, "channel": "linkedin_comment", "day_offset": 0, "date": "2026-01-01", "copy": "yo"},
                    {"step": 2, "channel": "linkedin_dm", "day_offset": 3, "date": "2026-01-04", "copy": "yo2"},
                ],
            },
        ],
        "warnings": [],
    }


# ---------------------------------------------------------------------------
# state module — load/save/mark roundtrip
# ---------------------------------------------------------------------------


def test_load_state_missing_file_returns_empty_scaffold(tmp_path):
    result = state.load_state(tmp_path, "post-merger")
    assert result == {"play": "post-merger", "targets": {}}


def test_mark_save_load_roundtrip(tmp_path):
    st = state.load_state(tmp_path, "post-merger")
    state.mark_touch(st, "Acme Corp", 1, ts="2026-01-02T00:00:00+00:00")
    state.save_state(tmp_path, "post-merger", st)

    reloaded = state.load_state(tmp_path, "post-merger")
    assert reloaded["targets"]["Acme Corp"]["steps_done"] == [1]
    assert reloaded["targets"]["Acme Corp"]["last_touch"] == "2026-01-02T00:00:00+00:00"

    state_path = tmp_path / "post-merger-state.json"
    assert state_path.exists()
    on_disk = json.loads(state_path.read_text(encoding="utf-8"))
    assert on_disk == reloaded


def test_mark_touch_dedupes_step_but_refreshes_last_touch():
    st = {"play": "post-merger", "targets": {}}
    state.mark_touch(st, "Acme Corp", 2, ts="t1")
    state.mark_touch(st, "Acme Corp", 2, ts="t2")
    state.mark_touch(st, "Acme Corp", 1, ts="t3")

    assert st["targets"]["Acme Corp"]["steps_done"] == [1, 2]
    assert st["targets"]["Acme Corp"]["last_touch"] == "t3"


def test_load_state_ignores_corrupt_json(tmp_path):
    path = tmp_path / "post-merger-state.json"
    path.write_text("not json", encoding="utf-8")
    result = state.load_state(tmp_path, "post-merger")
    assert result == {"play": "post-merger", "targets": {}}


def test_load_state_corrupt_json_prints_one_warning_line(tmp_path, capsys):
    path = tmp_path / "post-merger-state.json"
    path.write_text("not json", encoding="utf-8")
    result = state.load_state(tmp_path, "post-merger")
    assert result == {"play": "post-merger", "targets": {}}
    out = capsys.readouterr().out
    assert "corrupt" in out
    assert len([l for l in out.splitlines() if l.strip()]) == 1


# ---------------------------------------------------------------------------
# save_state — atomic tmp-then-replace write
# ---------------------------------------------------------------------------


def test_save_state_leaves_no_tmp_file_and_content_is_correct(tmp_path):
    st = {"play": "post-merger", "targets": {"Acme Corp": {"steps_done": [1], "last_touch": "t1"}}}
    path = state.save_state(tmp_path, "post-merger", st)

    tmp_file = tmp_path / "post-merger-state.json.tmp"
    assert not tmp_file.exists()
    assert json.loads(path.read_text(encoding="utf-8")) == st


def test_save_state_crash_during_replace_leaves_original_file_intact(tmp_path, monkeypatch):
    original = {"play": "post-merger", "targets": {}}
    state.save_state(tmp_path, "post-merger", original)
    path = tmp_path / "post-merger-state.json"
    original_bytes = path.read_bytes()

    def _boom(*args, **kwargs):
        raise OSError("simulated crash mid-replace")

    monkeypatch.setattr(state.os, "replace", _boom)

    corrupted_attempt = {"play": "post-merger", "targets": {"Acme Corp": {"steps_done": [1], "last_touch": "t2"}}}
    raised = False
    try:
        state.save_state(tmp_path, "post-merger", corrupted_attempt)
    except OSError:
        raised = True

    assert raised
    assert path.read_bytes() == original_bytes
    assert not (tmp_path / "post-merger-state.json.tmp").exists()


# ---------------------------------------------------------------------------
# due_touches — boundaries
# ---------------------------------------------------------------------------


def test_due_touches_date_equal_today_is_due_not_overdue():
    plan = _sample_plan()
    empty_state = {"play": "post-merger", "targets": {}}
    due = state.due_touches(plan, empty_state, today="2026-01-01")

    step1s = [t for t in due if t["step"] == 1]
    assert len(step1s) == 2
    assert all(t["overdue"] is False for t in step1s)


def test_due_touches_date_before_today_is_overdue():
    plan = _sample_plan()
    empty_state = {"play": "post-merger", "targets": {}}
    due = state.due_touches(plan, empty_state, today="2026-01-05")

    step1s = [t for t in due if t["step"] == 1]
    assert all(t["overdue"] is True for t in step1s)  # 2026-01-01 < 2026-01-05
    step2s = [t for t in due if t["step"] == 2]
    assert all(t["overdue"] is True for t in step2s)  # 2026-01-04 < 2026-01-05


def test_due_touches_date_after_today_is_not_due():
    plan = _sample_plan()
    empty_state = {"play": "post-merger", "targets": {}}
    due = state.due_touches(plan, empty_state, today="2026-01-01")

    assert not any(t["step"] == 3 for t in due)  # date 2026-01-07 > today


def test_due_touches_done_step_excluded():
    plan = _sample_plan()
    st = {"play": "post-merger", "targets": {"Acme Corp": {"steps_done": [1], "last_touch": "x"}}}
    due = state.due_touches(plan, st, today="2026-01-05")

    acme_due_steps = [t["step"] for t in due if t["company"] == "Acme Corp"]
    assert 1 not in acme_due_steps
    assert 2 in acme_due_steps


# ---------------------------------------------------------------------------
# cli_entry — touch
# ---------------------------------------------------------------------------


def _write_plan(tmp_path, plan=None):
    plan = plan or _sample_plan()
    (tmp_path / "post-merger-plan.json").write_text(json.dumps(plan), encoding="utf-8")
    return plan


def test_cli_touch_marks_step_done(tmp_path, capsys):
    _write_plan(tmp_path)

    rc = cli_entry.run(
        _make_args(action="touch", name="post-merger", target="acme corp", step=1, out=str(tmp_path))
    )
    out = capsys.readouterr().out
    assert rc == 0
    assert "Acme Corp" in out

    st = state.load_state(tmp_path, "post-merger")
    assert st["targets"]["Acme Corp"]["steps_done"] == [1]


def test_cli_touch_missing_plan_exits_1(tmp_path, capsys):
    rc = cli_entry.run(
        _make_args(action="touch", name="post-merger", target="Acme Corp", step=1, out=str(tmp_path))
    )
    out = capsys.readouterr().out
    assert rc == 1
    assert "gtmos play run" in out


def test_cli_touch_unknown_company_exits_2(tmp_path, capsys):
    _write_plan(tmp_path)

    rc = cli_entry.run(
        _make_args(action="touch", name="post-merger", target="Not A Company", step=1, out=str(tmp_path))
    )
    out = capsys.readouterr().out
    assert rc == 2
    assert "unknown company" in out
    assert "Acme Corp" in out  # known targets listed


def test_cli_touch_unknown_play_exits_2(tmp_path, capsys):
    rc = cli_entry.run(
        _make_args(action="touch", name="not-a-play", target="Acme Corp", step=1, out=str(tmp_path))
    )
    out = capsys.readouterr().out
    assert rc == 2
    assert "unknown play" in out


# ---------------------------------------------------------------------------
# cli_entry — status
# ---------------------------------------------------------------------------


def test_cli_status_reports_due_overdue_complete(tmp_path, capsys):
    _write_plan(tmp_path)
    st = state.load_state(tmp_path, "post-merger")
    state.mark_touch(st, "Nimbus Freight", 1)
    state.mark_touch(st, "Nimbus Freight", 2)
    state.save_state(tmp_path, "post-merger", st)

    rc = cli_entry.run(
        _make_args(action="status", name="post-merger", out=str(tmp_path), today="2026-01-05")
    )
    out = capsys.readouterr().out
    assert rc == 0
    assert "Acme Corp" in out
    assert "Nimbus Freight" in out
    # Acme has step 1 (2026-01-01) and step 2 (2026-01-04) both overdue as of
    # 2026-01-05; Nimbus completed both its steps.
    assert "play: 0 due today, 2 overdue, 1 complete" in out


def test_cli_status_missing_plan_exits_1(tmp_path, capsys):
    rc = cli_entry.run(_make_args(action="status", name="post-merger", out=str(tmp_path)))
    out = capsys.readouterr().out
    assert rc == 1
    assert "gtmos play run" in out
