"""Offline tests for gtmos.evals — the Layer-5 eval harness. No network, no LLM.

cli.py wiring for `gtmos eval` happens later (integrator's job) so these
tests call gtmos.evals.cli_entry.run() directly with a hand-built
argparse.Namespace, exactly like the module will be invoked once wired.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from gtmos.evals import cli_entry, suite


def _ns(**kwargs) -> argparse.Namespace:
    return argparse.Namespace(**kwargs)


# -- individual checks --------------------------------------------------

def test_audit_regression_passes_against_committed_golden():
    result = suite.check_audit_regression()
    assert result.passed, result.detail
    assert result.name == "audit-regression"


def test_audit_regression_fails_on_tampered_golden(tmp_path):
    golden_path = tmp_path / "golden_audit.json"
    golden_path.write_text(
        json.dumps({"now": "2026-07-13T00:00:00+00:00", "total_records": 25, "portal_score": 1.0}),
        encoding="utf-8",
    )
    result = suite.check_audit_regression(golden_path=golden_path)
    assert not result.passed
    assert "portal_score" in result.detail


def test_audit_determinism_passes():
    result = suite.check_audit_determinism()
    assert result.passed, result.detail


def test_receipts_integrity_missing_file_passes(tmp_path):
    missing = tmp_path / "receipts.jsonl"
    result = suite.check_receipts_integrity(receipts_path=missing)
    assert result.passed
    assert "no receipts yet" in result.detail


def test_receipts_integrity_good_file_passes(tmp_path):
    path = tmp_path / "receipts.jsonl"
    good_lines = [
        {"ts": time.time(), "command": "audit-narrative", "prompt_chars": 120, "duration_s": 1.2, "exit": 0},
        {"ts": time.time(), "command": "eval-judge", "prompt_chars": 300, "duration_s": 2.4, "exit": 0},
    ]
    path.write_text("\n".join(json.dumps(l) for l in good_lines) + "\n", encoding="utf-8")
    result = suite.check_receipts_integrity(receipts_path=path)
    assert result.passed, result.detail


def test_receipts_integrity_bad_file_fails(tmp_path):
    path = tmp_path / "receipts.jsonl"
    lines = [
        json.dumps({"ts": time.time(), "command": "audit-narrative", "prompt_chars": 1, "duration_s": 1, "exit": 0}),
        "not valid json",
        json.dumps({"ts": time.time(), "command": "missing-keys"}),
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result = suite.check_receipts_integrity(receipts_path=path)
    assert not result.passed
    assert "line 2" in result.detail
    assert "line 3" in result.detail


def test_harness_contract_passes_on_current_tree():
    result = suite.check_harness_contract()
    assert result.passed, result.detail


def test_harness_contract_flags_a_bypass(tmp_path):
    fake_root = tmp_path / "gtmos"
    (fake_root / "sneaky").mkdir(parents=True)
    offender = fake_root / "sneaky" / "shortcut.py"
    offender.write_text('import subprocess\nsubprocess.run(["claude", "-p", "hi"])\n', encoding="utf-8")
    result = suite.check_harness_contract(source_root=fake_root)
    assert not result.passed
    assert "shortcut.py" in result.detail


def test_token_hygiene_passes_on_current_tree():
    result = suite.check_token_hygiene()
    assert result.passed, result.detail


def test_token_hygiene_flags_a_leaking_print(tmp_path):
    fake_root = tmp_path / "gtmos"
    fake_root.mkdir()
    offender = fake_root / "leaky.py"
    offender.write_text(
        "import os\n\n"
        "def run():\n"
        "    token = os.environ.get(\"GTMOS_HUBSPOT_TOKEN\")\n"
        "    print(f\"got token {token}\")\n",
        encoding="utf-8",
    )
    result = suite.check_token_hygiene(source_root=fake_root)
    assert not result.passed
    assert "leaky.py" in result.detail


def test_token_hygiene_exempts_fetch_py_modules(tmp_path):
    fake_root = tmp_path / "gtmos"
    fake_root.mkdir()
    offender = fake_root / "fetch.py"
    offender.write_text(
        "import os\n\n"
        "def run():\n"
        "    token = os.environ.get(\"GTMOS_HUBSPOT_TOKEN\")\n"
        "    print(f\"got token {token}\")\n",
        encoding="utf-8",
    )
    result = suite.check_token_hygiene(source_root=fake_root)
    assert result.passed


def test_token_hygiene_ignores_unrelated_prints(tmp_path):
    fake_root = tmp_path / "gtmos"
    fake_root.mkdir()
    clean = fake_root / "clean.py"
    clean.write_text(
        "import os\n\n"
        "def run():\n"
        "    token = os.environ.get(\"GTMOS_HUBSPOT_TOKEN\")\n"
        "    if not token:\n"
        "        print('GTMOS_HUBSPOT_TOKEN not set')\n"
        "    return token\n",
        encoding="utf-8",
    )
    result = suite.check_token_hygiene(source_root=fake_root)
    assert result.passed, result.detail


def test_state_atomicity_passes_on_current_tree():
    result = suite.check_state_atomicity()
    assert result.passed, result.detail


def test_state_atomicity_fails_when_os_replace_missing(tmp_path):
    fake_state = tmp_path / "state.py"
    fake_state.write_text(
        "def save_state(out_dir, play_name, state):\n"
        "    path.write_text('x')\n"
        "    return path\n",
        encoding="utf-8",
    )
    result = suite.check_state_atomicity(state_path=fake_state)
    assert not result.passed
    assert "os.replace" in result.detail


def test_judge_skips_cleanly_when_report_absent(tmp_path):
    missing = tmp_path / "integrity-report.md"
    result = suite.check_judge(report_path=missing)
    assert result.passed
    assert "skipped" in result.detail


# -- cli_entry ------------------------------------------------------------

def test_cli_run_writes_report_and_exits_zero_when_all_pass(tmp_path):
    out_dir = tmp_path / "eval-out"
    args = _ns(judge=False, out=str(out_dir), dry_run=False)
    exit_code = cli_entry.run(args)
    assert exit_code == 0
    report_path = out_dir / "eval-report.md"
    assert report_path.exists()
    text = report_path.read_text(encoding="utf-8")
    assert "audit-regression" in text
    assert "harness-contract" in text


def test_cli_run_dry_run_lists_checks_and_writes_nothing(tmp_path, capsys):
    out_dir = tmp_path / "eval-out"
    args = _ns(judge=False, out=str(out_dir), dry_run=True)
    exit_code = cli_entry.run(args)
    assert exit_code == 0
    assert not out_dir.exists()
    captured = capsys.readouterr()
    assert "audit-regression" in captured.out


def test_cli_run_exits_nonzero_when_a_check_fails(tmp_path, monkeypatch):
    def _always_fail(*args, **kwargs):
        return suite.EvalResult("fake-check", False, "forced failure")

    monkeypatch.setitem(suite.REGISTRY, "fake-check", _always_fail)
    out_dir = tmp_path / "eval-out"
    args = _ns(judge=False, out=str(out_dir), dry_run=False)
    exit_code = cli_entry.run(args)
    assert exit_code == 1
    text = (out_dir / "eval-report.md").read_text(encoding="utf-8")
    assert "FAIL" in text
