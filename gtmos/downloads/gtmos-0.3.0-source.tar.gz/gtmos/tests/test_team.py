"""Tests for the team module: `gtmos init` scaffolding + `gtmos team` config
access. Calls run_init/run_team/run directly with argparse.Namespace stand-ins
— the integrator wires the real subparsers later.
"""

from __future__ import annotations

import argparse
import json

from gtmos.team.cli_entry import run, run_init, run_team
from gtmos.team.config import config_get, find_config_path, load_config

SCAFFOLD_FILES = ("gtmos-team.json", "DOCTRINE.md", "PLAN.md", "PLAYS.md")


def _init_args(tmp_path, force=False, name="Acme"):
    return argparse.Namespace(dir=str(tmp_path), force=force, name=name)


def test_init_creates_four_files_with_content_anchors(tmp_path, capsys):
    rc = run_init(_init_args(tmp_path))
    assert rc == 0

    for fname in SCAFFOLD_FILES:
        assert (tmp_path / fname).exists(), f"{fname} was not created"

    config = json.loads((tmp_path / "gtmos-team.json").read_text(encoding="utf-8"))
    assert config["team"]["name"] == "Acme"
    assert "roles" in config["team"]
    assert "sdr" in config["team"]["roles"]
    assert config["stages"]["order"]
    assert config["tiers"]

    doctrine = (tmp_path / "DOCTRINE.md").read_text(encoding="utf-8")
    assert "hard rules" in doctrine.lower()
    assert "harness" in doctrine.lower()
    assert "zero-egress" in doctrine.lower()
    assert "Acme" in doctrine

    plan = (tmp_path / "PLAN.md").read_text(encoding="utf-8")
    assert "Wave" in plan

    plays = (tmp_path / "PLAYS.md").read_text(encoding="utf-8")
    assert "gtmos play list" in plays

    out = capsys.readouterr().out
    assert "created 4" in out


def test_second_init_skips_existing_files(tmp_path, capsys):
    run_init(_init_args(tmp_path))
    capsys.readouterr()  # discard first-run output

    doctrine_path = tmp_path / "DOCTRINE.md"
    doctrine_path.write_text("EDITED BY USER", encoding="utf-8")

    rc = run_init(_init_args(tmp_path))
    assert rc == 0
    assert doctrine_path.read_text(encoding="utf-8") == "EDITED BY USER"

    out = capsys.readouterr().out
    assert "skipped" in out


def test_force_overwrites_existing_files(tmp_path):
    run_init(_init_args(tmp_path))

    doctrine_path = tmp_path / "DOCTRINE.md"
    doctrine_path.write_text("EDITED BY USER", encoding="utf-8")

    rc = run_init(_init_args(tmp_path, force=True))
    assert rc == 0
    assert doctrine_path.read_text(encoding="utf-8") != "EDITED BY USER"
    assert "Acme" in doctrine_path.read_text(encoding="utf-8")


def test_config_walk_up_finds_file_from_nested_dir(tmp_path):
    run_init(_init_args(tmp_path))

    nested = tmp_path / "a" / "b" / "c"
    nested.mkdir(parents=True)

    found = find_config_path(str(nested))
    assert found is not None
    assert found.name == "gtmos-team.json"

    cfg = load_config(str(nested))
    assert cfg is not None
    assert cfg["team"]["name"] == "Acme"


def test_load_config_returns_none_when_absent(tmp_path):
    lonely = tmp_path / "nowhere"
    lonely.mkdir()
    assert load_config(str(lonely)) is None


def test_set_get_roundtrip_including_float_coercion(tmp_path, capsys):
    run_init(_init_args(tmp_path))

    rc = run_team(argparse.Namespace(dir=str(tmp_path), get=None, set="team.acv=9000"))
    assert rc == 0

    rc = run_team(argparse.Namespace(dir=str(tmp_path), get="team.acv", set=None))
    assert rc == 0
    out = capsys.readouterr().out
    assert "9000" in out

    cfg = load_config(str(tmp_path))
    acv = config_get(cfg, "team.acv")
    assert isinstance(acv, float)
    assert acv == 9000.0


def test_set_get_roundtrip_string_value(tmp_path, capsys):
    run_init(_init_args(tmp_path))

    rc = run_team(argparse.Namespace(dir=str(tmp_path), get=None, set="team.icp=Series B fintech"))
    assert rc == 0

    cfg = load_config(str(tmp_path))
    assert config_get(cfg, "team.icp") == "Series B fintech"


def test_show_default_prints_role_table(tmp_path, capsys):
    run_init(_init_args(tmp_path))

    rc = run_team(argparse.Namespace(dir=str(tmp_path), get=None, set=None))
    assert rc == 0
    out = capsys.readouterr().out
    assert "founder" in out
    assert "sdr" in out
    assert "icp" in out.lower()
    assert "acv" in out.lower()


def test_team_without_config_reports_error(tmp_path):
    empty = tmp_path / "empty"
    empty.mkdir()
    rc = run_team(argparse.Namespace(dir=str(empty), get=None, set=None))
    assert rc == 1


def test_run_dispatches_on_team_cmd(tmp_path):
    args = argparse.Namespace(dir=str(tmp_path), force=False, name="Acme", team_cmd="init")
    rc = run(args)
    assert rc == 0
    assert (tmp_path / "gtmos-team.json").exists()

    args2 = argparse.Namespace(dir=str(tmp_path), get="team.name", set=None, team_cmd="team")
    rc2 = run(args2)
    assert rc2 == 0
