"""Offline tests for gtmos.quickstart — the one-command CRM onboarding
path. No network, no LLM; GTMOS_HUBSPOT_TOKEN is always cleared so every
run takes the offline (file-based) branch unless a test says otherwise.
"""

from __future__ import annotations

import argparse
import json

from gtmos import doctor, quickstart


def _ns(**kwargs) -> argparse.Namespace:
    defaults = dict(contacts=None, deals=None, acv=None, dir=None, out_root=None, dry_run=False)
    defaults.update(kwargs)
    return argparse.Namespace(**defaults)


CONTACTS = [
    {
        "email": "a@brightpath.com", "firstname": "Rohan", "lastname": "Mehta",
        "company": "BrightPath", "jobtitle": "VP Sales", "phone": "5551234567",
        "lifecyclestage": "customer", "owner": "1",
    },
    {
        "email": "b@brightpath.com", "firstname": "Dana", "lastname": "Lee",
        "company": "BrightPath", "jobtitle": "CTO", "phone": "5551234568",
        "lifecyclestage": "opportunity", "owner": "1",
    },
]

DEALS = [
    {
        "id": "1", "dealname": "Deal A", "amount": "10000", "dealstage": "closedwon",
        "createdate": "2026-01-01", "hs_lastmodifieddate": "2026-01-05",
        "closedate": "2026-01-05", "hubspot_owner_id": "1",
    },
    {
        "id": "2", "dealname": "Deal B", "amount": "5000", "dealstage": "qualifiedtobuy",
        "createdate": "2026-01-01", "hs_lastmodifieddate": "2026-01-02",
        "closedate": None, "hubspot_owner_id": "1",
    },
]


def _write_json(path, payload) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_dry_run_prints_plan_and_touches_nothing(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("GTMOS_HUBSPOT_TOKEN", raising=False)
    args = _ns(dir=str(tmp_path), out_root=str(tmp_path), dry_run=True)

    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    assert exit_code == 0
    assert "dry-run" in out
    assert not (tmp_path / "audit-out").exists()
    assert not (tmp_path / "gtmos-team.json").exists()


def test_full_offline_run_writes_banner_and_outputs(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("GTMOS_HUBSPOT_TOKEN", raising=False)
    contacts_path = tmp_path / "contacts.json"
    deals_path = tmp_path / "deals.json"
    _write_json(contacts_path, CONTACTS)
    _write_json(deals_path, DEALS)

    args = _ns(
        contacts=str(contacts_path),
        deals=str(deals_path),
        acv=9000.0,
        dir=str(tmp_path),
        out_root=str(tmp_path),
    )
    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    assert exit_code == 0
    for step in ("[1/5]", "[2/5]", "[3/5]", "[4/5]", "[5/5]"):
        assert step in out
    assert "quickstart complete" in out
    assert "portal score" in out
    assert "funnel leak" in out
    assert "gtmos serve" in out
    assert "gtmos today --role" in out

    assert (tmp_path / "gtmos-team.json").exists()
    assert (tmp_path / "audit-out" / "scores.json").exists()
    assert (tmp_path / "funnel-out" / "funnel.json").exists()


def test_no_sources_skips_audit_and_funnel_but_still_completes(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("GTMOS_HUBSPOT_TOKEN", raising=False)
    args = _ns(dir=str(tmp_path), out_root=str(tmp_path))

    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    assert exit_code == 0
    assert "audit skipped" in out
    assert "funnel skipped" in out
    assert "n/a" in out  # banner reflects the missing data honestly
    assert "quickstart complete" in out


def test_malformed_deals_file_reported_but_remaining_steps_still_run(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("GTMOS_HUBSPOT_TOKEN", raising=False)
    contacts_path = tmp_path / "contacts.json"
    deals_path = tmp_path / "deals.json"
    _write_json(contacts_path, CONTACTS)
    deals_path.write_text("not valid json", encoding="utf-8")

    args = _ns(
        contacts=str(contacts_path),
        deals=str(deals_path),
        dir=str(tmp_path),
        out_root=str(tmp_path),
    )
    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    # partial data still yields partial impact: exit 0, remaining steps ran
    assert exit_code == 0
    assert "[4/5] funnel: failed" in out
    assert "[5/5]" in out
    assert "quickstart complete" in out
    assert (tmp_path / "audit-out" / "scores.json").exists()


def test_doctor_failure_aborts_before_any_step(tmp_path, capsys, monkeypatch):
    def _fake_run_checks(**kwargs):
        return [doctor.CheckResult("writable-cwd", "fail", "not writable")]

    monkeypatch.setattr(quickstart.doctor, "run_checks", _fake_run_checks)
    args = _ns(dir=str(tmp_path), out_root=str(tmp_path))

    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    assert exit_code == 1
    assert "aborting" in out
    assert "[1/5]" not in out
    assert not (tmp_path / "gtmos-team.json").exists()


def test_team_config_already_present_skips_scaffold(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("GTMOS_HUBSPOT_TOKEN", raising=False)
    (tmp_path / "gtmos-team.json").write_text(json.dumps({"team": {"name": "Acme", "acv": 5000}}), encoding="utf-8")

    args = _ns(dir=str(tmp_path), out_root=str(tmp_path))
    exit_code = quickstart.run(args)
    out = capsys.readouterr().out

    assert exit_code == 0
    assert "already present" in out
