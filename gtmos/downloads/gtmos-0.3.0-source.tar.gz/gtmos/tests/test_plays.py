"""Offline tests for `gtmos play` — signal-play library + planner + CLI.
No network, no real `claude` subprocess calls (run_harness is monkeypatched
wherever --draft is exercised)."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import gtmos.harness as harness
from gtmos.plays import cli_entry, library
from gtmos.plays.planner import build_plan

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "play_targets.json"


def _load_targets() -> list[dict]:
    with open(FIXTURE_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def _make_args(**overrides) -> argparse.Namespace:
    defaults = dict(
        action=None,
        name=None,
        targets=None,
        out=None,
        start_date=None,
        draft=False,
        dry_run=False,
    )
    defaults.update(overrides)
    return argparse.Namespace(**defaults)


# ---------------------------------------------------------------------------
# library
# ---------------------------------------------------------------------------


def test_library_has_four_named_plays():
    names = set(library.PLAYS)
    assert names == {"post-merger", "new-revops-hire", "hiring-spree", "compliance-wall"}


def test_every_play_has_valid_sequence_shape():
    for play in library.list_plays():
        assert 4 <= len(play.sequence) <= 5
        assert play.sequence[0].channel == "linkedin_comment", (
            f"{play.name}: sequence must open with linkedin_comment (comment-before-DM)"
        )
        first_dm_index = next(
            (i for i, t in enumerate(play.sequence) if t.channel == "linkedin_dm"), None
        )
        first_comment_index = next(
            i for i, t in enumerate(play.sequence) if t.channel == "linkedin_comment"
        )
        if first_dm_index is not None:
            assert first_comment_index < first_dm_index
        assert play.sequence[-1].day_offset <= 14


# ---------------------------------------------------------------------------
# planner — template rendering
# ---------------------------------------------------------------------------


def test_template_rendering_exact_for_known_target_and_touch():
    play = library.get_play("post-merger")
    targets = _load_targets()
    priya = next(t for t in targets if t["first_name"] == "Priya")

    plan = build_plan(play, [priya], start_date="2026-01-01")
    touch = plan["targets"][0]["touches"][0]

    expected = (
        "Congrats on the closed their Series C-backed acquisition of Dray Logistics, "
        "Nimbus Freight — mergers like this are exactly when CRM data quietly forks "
        "into two systems of record. Following along."
    )
    assert touch["copy"] == expected
    assert touch["step"] == 1
    assert touch["channel"] == "linkedin_comment"


def test_missing_field_renders_fill_placeholder_and_warns():
    play = library.get_play("hiring-spree")
    targets = _load_targets()
    dana = next(t for t in targets if t["first_name"] == "Dana")  # no 'signal' field

    plan = build_plan(play, [dana], start_date="2026-01-01")
    touches = plan["targets"][0]["touches"]

    assert any("[FILL: signal]" in t["copy"] for t in touches)
    assert plan["warnings"] == ["Dana: missing 'signal' evidence field"]


# ---------------------------------------------------------------------------
# planner — date arithmetic
# ---------------------------------------------------------------------------


def test_date_arithmetic_with_fixed_start_date():
    play = library.get_play("post-merger")
    targets = _load_targets()
    priya = next(t for t in targets if t["first_name"] == "Priya")

    plan = build_plan(play, [priya], start_date="2026-01-01")
    dates = [t["date"] for t in plan["targets"][0]["touches"]]
    offsets = [t.day_offset for t in play.sequence]

    expected = ["2026-01-01", "2026-01-04", "2026-01-07", "2026-01-11", "2026-01-15"]
    assert offsets == [0, 3, 6, 10, 14]
    assert dates == expected
    assert plan["start_date"] == "2026-01-01"


# ---------------------------------------------------------------------------
# cli_entry — list / show
# ---------------------------------------------------------------------------


def test_cli_list_contents(capsys):
    rc = cli_entry.run(_make_args(action="list"))
    out = capsys.readouterr().out
    assert rc == 0
    for name in library.PLAYS:
        assert name in out
    assert "TRIGGER" in out


def test_cli_show_unknown_play_exits_2(capsys):
    rc = cli_entry.run(_make_args(action="show", name="not-a-real-play"))
    out = capsys.readouterr().out
    assert rc == 2
    assert "unknown play" in out


def test_cli_run_unknown_play_exits_2(tmp_path, capsys):
    rc = cli_entry.run(
        _make_args(action="run", name="not-a-real-play", targets=str(FIXTURE_PATH), out=str(tmp_path))
    )
    out = capsys.readouterr().out
    assert rc == 2
    assert "unknown play" in out


def test_cli_unknown_action_exits_2():
    rc = cli_entry.run(_make_args(action="bogus"))
    assert rc == 2


# ---------------------------------------------------------------------------
# cli_entry — run, plan files
# ---------------------------------------------------------------------------


def test_cli_run_writes_plan_files(tmp_path):
    rc = cli_entry.run(
        _make_args(
            action="run",
            name="post-merger",
            targets=str(FIXTURE_PATH),
            out=str(tmp_path),
            start_date="2026-01-01",
        )
    )
    assert rc == 0

    json_path = tmp_path / "post-merger-plan.json"
    md_path = tmp_path / "post-merger-plan.md"
    assert json_path.exists()
    assert md_path.exists()

    plan = json.loads(json_path.read_text(encoding="utf-8"))
    assert plan["play"] == "post-merger"
    assert len(plan["targets"]) == len(_load_targets())
    assert "draft_note" not in plan

    md_text = md_path.read_text(encoding="utf-8")
    assert "Nimbus Freight" in md_text
    assert "Warnings" in md_text  # Dana is missing 'signal'


def test_cli_run_missing_targets_file_exits_1(tmp_path):
    rc = cli_entry.run(
        _make_args(action="run", name="post-merger", targets=str(tmp_path / "nope.json"), out=str(tmp_path))
    )
    assert rc == 1


# ---------------------------------------------------------------------------
# cli_entry — --draft (monkeypatched run_harness, no network/subprocess)
# ---------------------------------------------------------------------------


def test_cli_run_draft_applies_harness_copy_and_caps(tmp_path, monkeypatch):
    calls = []

    def fake_run_harness(command, prompt, allowed_tools, dry_run=False, **kwargs):
        calls.append((command, dry_run))
        return "STEP 1: Rewritten opener.\nSTEP 2: Rewritten DM."

    monkeypatch.setattr(harness, "run_harness", fake_run_harness)

    rc = cli_entry.run(
        _make_args(
            action="run",
            name="post-merger",
            targets=str(FIXTURE_PATH),
            out=str(tmp_path),
            start_date="2026-01-01",
            draft=True,
        )
    )
    assert rc == 0

    targets = _load_targets()
    assert len(calls) == len(targets)  # 4 targets, under the cap of 10
    assert all(cmd == "play-draft" for cmd, _ in calls)

    plan = json.loads((tmp_path / "post-merger-plan.json").read_text(encoding="utf-8"))
    assert plan["draft_note"].startswith(f"--draft applied to {len(targets)} of {len(targets)}")
    first_touches = plan["targets"][0]["touches"]
    assert first_touches[0]["copy"] == "Rewritten opener."
    assert first_touches[1]["copy"] == "Rewritten DM."
    # Steps beyond what the fake harness rewrote keep their template copy.
    assert first_touches[2]["copy"] != ""


def test_cli_run_draft_honors_dry_run(tmp_path, monkeypatch):
    seen_dry_run = []

    def fake_run_harness(command, prompt, allowed_tools, dry_run=False, **kwargs):
        seen_dry_run.append(dry_run)
        return ""

    monkeypatch.setattr(harness, "run_harness", fake_run_harness)

    rc = cli_entry.run(
        _make_args(
            action="run",
            name="hiring-spree",
            targets=str(FIXTURE_PATH),
            out=str(tmp_path),
            start_date="2026-01-01",
            draft=True,
            dry_run=True,
        )
    )
    assert rc == 0
    assert seen_dry_run and all(v is True for v in seen_dry_run)
