"""Offline smoke tests for `gtmos abm` — deterministic planner + CLI, zero
network, zero `claude` subprocess calls.

The abm modules (gtmos/abm/planner.py, gtmos/abm/cli_entry.py, ...) are
being built by a parallel agent. We poll for gtmos.abm.planner to import
(up to 120s) instead of hardcoding a fixed startup order, matching the
pattern in tests/test_engine.py / tests/test_cli.py.
"""

from __future__ import annotations

import importlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent
FIXTURE_PATH = Path(__file__).parent / "fixtures" / "abm_accounts.json"

LINKEDIN_AUDIENCE_FLOOR = 300


def _import_with_retry(module_name: str, timeout: float = 120.0, interval: float = 3.0):
    deadline = time.monotonic() + timeout
    last_err: Exception | None = None
    while True:
        try:
            return importlib.import_module(module_name)
        except ImportError as exc:
            last_err = exc
            if time.monotonic() >= deadline:
                raise ImportError(
                    f"{module_name} did not become importable within {timeout}s "
                    f"(last error: {last_err})"
                ) from last_err
            time.sleep(interval)


def _run_cli(args: list[str], timeout: float = 30.0) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT)
    env.pop("LINKEDIN_ACCESS_TOKEN", None)
    return subprocess.run(
        [sys.executable, "-m", "gtmos.cli", *args],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _wait_for_cli(timeout: float = 120.0, interval: float = 3.0) -> None:
    """Parallel builders may still be writing gtmos/abm/* — poll before failing."""
    deadline = time.monotonic() + timeout
    last_result = None
    while True:
        try:
            last_result = _run_cli(["abm", "--help"])
            if last_result.returncode == 0:
                return
        except Exception:
            pass
        if time.monotonic() >= deadline:
            detail = f" (last stderr: {last_result.stderr})" if last_result else ""
            raise RuntimeError(f"gtmos abm did not become runnable within {timeout}s{detail}")
        time.sleep(interval)


def _iter_output_files(out_dir: Path):
    for path in out_dir.rglob("*"):
        if path.is_file():
            yield path


class AbmPlannerTests(unittest.TestCase):
    """Unit-level checks on the deterministic ad-set planner."""

    @classmethod
    def setUpClass(cls):
        cls.planner = _import_with_retry("gtmos.abm.planner")
        with open(FIXTURE_PATH, encoding="utf-8") as fh:
            cls.accounts = json.load(fh)
        cls.plans = cls.planner.plan(cls.accounts)

    def test_every_plan_clears_the_audience_floor(self):
        for p in self.plans:
            self.assertGreaterEqual(
                p.estimated_audience,
                LINKEDIN_AUDIENCE_FLOOR,
                msg=f"plan {p.tier} ({[a['name'] for a in p.accounts]}) is under the audience floor",
            )

    def test_big_accounts_get_one_to_one_tier(self):
        big_names = {
            a["name"] for a in self.accounts if isinstance(a.get("employee_count"), int) and a["employee_count"] >= 5000
        }
        one_to_one_names = {
            a["name"] for p in self.plans if p.tier == "one_to_one" for a in p.accounts
        }
        self.assertTrue(big_names, "fixture has no big accounts to assert on")
        self.assertEqual(big_names, one_to_one_names)

    def test_small_accounts_get_clustered_tier(self):
        # "Small" here means "not big" — includes the null-employee_count
        # account, which the planner must treat as small-by-default rather
        # than crash on or silently drop (see the null-count test below).
        small_names = {
            a["name"]
            for a in self.accounts
            if not (isinstance(a.get("employee_count"), int) and a["employee_count"] >= 5000)
        }
        clustered_names = {
            a["name"] for p in self.plans if p.tier == "clustered" for a in p.accounts
        }
        self.assertTrue(small_names, "fixture has no small accounts to assert on")
        self.assertEqual(small_names, clustered_names)

    def test_null_employee_count_account_is_placed_not_crashed(self):
        null_names = {a["name"] for a in self.accounts if a.get("employee_count") is None}
        self.assertTrue(null_names, "fixture has no null-employee_count account to assert on")

        placed_names = {a["name"] for p in self.plans for a in p.accounts}
        self.assertTrue(null_names.issubset(placed_names))

        # A null count must not be treated as "clears the floor solo" — it
        # should land in a clustered plan alongside other small accounts,
        # not get a fabricated one_to_one plan of its own.
        one_to_one_names = {
            a["name"] for p in self.plans if p.tier == "one_to_one" for a in p.accounts
        }
        self.assertFalse(null_names & one_to_one_names)

    def test_every_account_placed_exactly_once(self):
        placed_names = [a["name"] for p in self.plans for a in p.accounts]
        self.assertEqual(len(placed_names), len(self.accounts))
        self.assertEqual(len(placed_names), len(set(placed_names)))


class AbmCliEndToEndTests(unittest.TestCase):
    """Subprocess-level checks on `python3 -m gtmos.cli abm`."""

    @classmethod
    def setUpClass(cls):
        _wait_for_cli()
        with open(FIXTURE_PATH, encoding="utf-8") as fh:
            cls.accounts = json.load(fh)

    def test_plan_run_end_to_end(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(["abm", "--accounts", str(FIXTURE_PATH), "--out", tmpdir])
            self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")

            out_dir = Path(tmpdir)
            plan_path = out_dir / "campaign-plan.json"
            summary_path = out_dir / "CAMPAIGN-SUMMARY.md"
            pages_dir = out_dir / "pages"
            creatives_dir = out_dir / "creatives"

            self.assertTrue(plan_path.exists(), "abm did not write campaign-plan.json")
            self.assertTrue(summary_path.exists(), "abm did not write CAMPAIGN-SUMMARY.md")

            # campaign-plan.json is valid JSON with every account placed exactly once.
            plans = json.loads(plan_path.read_text(encoding="utf-8"))
            self.assertIsInstance(plans, list)
            placed_names = [a["name"] for p in plans for a in p["accounts"]]
            expected_names = [a["name"] for a in self.accounts]
            self.assertEqual(sorted(placed_names), sorted(expected_names))
            self.assertEqual(len(placed_names), len(set(placed_names)))

            # CAMPAIGN-SUMMARY.md contains a sizing note.
            summary_text = summary_path.read_text(encoding="utf-8")
            self.assertRegex(summary_text, r"[Ss]izing[ _][Nn]ote")

            # pages/ and creatives/ are non-empty.
            self.assertTrue(pages_dir.exists() and any(pages_dir.iterdir()), "pages/ is missing or empty")
            self.assertTrue(
                creatives_dir.exists() and any(creatives_dir.iterdir()), "creatives/ is missing or empty"
            )

            # No unresolved {{token}} residue anywhere in the output tree.
            for path in _iter_output_files(out_dir):
                text = path.read_text(encoding="utf-8", errors="strict")
                self.assertNotIn("{{", text, msg=f"unresolved template token left in {path}")

            # HTML-escaping is pinned: the "&"-bearing account name renders
            # as "&amp;" somewhere in the generated output, never a bare "&".
            escaped_found = False
            for path in _iter_output_files(out_dir):
                if path.suffix != ".html":
                    continue
                text = path.read_text(encoding="utf-8")
                if "&amp;" in text:
                    escaped_found = True
            self.assertTrue(escaped_found, "expected '&amp;' (escaped account name) in generated HTML output")

    def test_push_without_token_exits_nonzero_and_mentions_approval(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(["abm", "--accounts", str(FIXTURE_PATH), "--out", tmpdir, "--push"])
            self.assertEqual(result.returncode, 2, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")
            combined_output = result.stdout + result.stderr
            self.assertRegex(combined_output, r"[Aa]pproval")


if __name__ == "__main__":
    unittest.main()
