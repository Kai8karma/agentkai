"""Offline end-to-end smoke tests for `python3 -m gtmos.cli`. Zero network,
zero `claude` subprocess calls — `audit --input` stays on the local
fetch-from-file path the whole way through.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent
FIXTURE_PATH = Path(__file__).parent / "fixtures" / "contacts_sample.json"


def _run_cli(args: list[str], timeout: float = 30.0) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(REPO_ROOT)
    return subprocess.run(
        [sys.executable, "-m", "gtmos.cli", *args],
        cwd=REPO_ROOT,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _wait_for_module(timeout: float = 90.0, interval: float = 3.0) -> None:
    """Parallel builders may still be writing gtmos/cli.py — poll before failing."""
    deadline = time.monotonic() + timeout
    last_result = None
    while True:
        try:
            last_result = _run_cli(["--help"])
            if last_result.returncode == 0:
                return
        except Exception:
            pass
        if time.monotonic() >= deadline:
            detail = f" (last stderr: {last_result.stderr})" if last_result else ""
            raise RuntimeError(f"gtmos.cli did not become runnable within {timeout}s{detail}")
        time.sleep(interval)


class CliContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _wait_for_module()

    def test_help_exits_zero(self):
        result = _run_cli(["--help"])
        self.assertEqual(result.returncode, 0, msg=result.stderr)

    def test_audit_help_exits_zero(self):
        result = _run_cli(["audit", "--help"])
        self.assertEqual(result.returncode, 0, msg=result.stderr)

    def test_audit_end_to_end_on_fixture(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                [
                    "audit",
                    "--input",
                    str(FIXTURE_PATH),
                    "--acv",
                    "50000",
                    "--out",
                    tmpdir,
                ]
            )
            self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")

            report_path = Path(tmpdir) / "integrity-report.md"
            scores_path = Path(tmpdir) / "scores.json"
            self.assertTrue(report_path.exists(), "audit did not write integrity-report.md")
            self.assertTrue(scores_path.exists(), "audit did not write scores.json")

            report_text = report_path.read_text(encoding="utf-8")
            self.assertRegex(
                report_text,
                r"[Oo]verall.*\d",
                "report is missing a score line",
            )
            self.assertRegex(
                report_text,
                r"[Dd]uplicate|[Dd]upe",
                "report is missing a duplicate-clusters section",
            )

            scores_text = scores_path.read_text(encoding="utf-8")
            self.assertIn("portal_score", scores_text)

    def test_draft_dry_run_post_subcommand(self):
        """Regression: cli.py wired --type, draft.py read args.kind. This is
        the exact invocation form from the punch list (--dry-run after the
        subcommand token, which only works if the subparser accepts it)."""
        result = _run_cli(["draft", "--dry-run", "--type", "linkedin", "test topic"])
        self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")
        self.assertIn("draft", result.stdout)

    def test_prospect_dry_run_with_input(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump([{"name": "Jane Doe", "company": "Acme"}], f)
            input_path = f.name
        try:
            result = _run_cli(["prospect", "test icp", "--input", input_path, "--dry-run"])
            self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")
        finally:
            os.unlink(input_path)

    def test_stalk_dry_run_with_input(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({"touches": []}, f)
            input_path = f.name
        try:
            result = _run_cli(
                ["stalk", "Jane Doe", "--company", "Acme", "--input", input_path, "--dry-run"]
            )
            self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")
        finally:
            os.unlink(input_path)

    def test_brief_dry_run_with_input(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({"deals": []}, f)
            input_path = f.name
        try:
            result = _run_cli(["brief", "--input", input_path, "--dry-run"])
            self.assertEqual(result.returncode, 0, msg=f"stdout={result.stdout!r} stderr={result.stderr!r}")
        finally:
            os.unlink(input_path)

    def test_outcomes_help_exits_zero(self):
        result = _run_cli(["outcomes", "--help"])
        self.assertEqual(result.returncode, 0, msg=result.stderr)


if __name__ == "__main__":
    unittest.main()
