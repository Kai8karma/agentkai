"""Eval checks — a registry of named functions, each returning an EvalResult.

Every check is pure/offline by default (Pattern 8: catch silent agent
failures without needing a live LLM). The one exception is "judge", which
is opt-in via --judge and goes through gtmos.harness (the single chokepoint
for claude CLI calls).
"""

from __future__ import annotations

import ast
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from gtmos.audit import engine

REPO_ROOT = Path(__file__).resolve().parents[2]
FIXTURE_PATH = REPO_ROOT / "tests" / "fixtures" / "contacts_sample.json"
GOLDEN_PATH = REPO_ROOT / "tests" / "fixtures" / "golden_audit.json"
GTMOS_SRC = REPO_ROOT / "gtmos"
STATE_PATH = REPO_ROOT / "gtmos" / "plays" / "state.py"
DEFAULT_RECEIPTS_PATH = Path.home() / ".gtmos" / "receipts.jsonl"

REQUIRED_RECEIPT_KEYS = ("ts", "command", "prompt_chars", "duration_s", "exit")

SUBPROCESS_CALL_RE = re.compile(r"subprocess\.(run|Popen|call|check_output|check_call)")

TOKEN_ENV_VAR = "GTMOS_HUBSPOT_TOKEN"


@dataclass
class EvalResult:
    name: str
    passed: bool
    detail: str


def _load_contacts(fixture_path: Path) -> list[dict]:
    with open(fixture_path, encoding="utf-8") as f:
        return json.load(f)


def check_audit_regression(
    fixture_path: Path = FIXTURE_PATH,
    golden_path: Path = GOLDEN_PATH,
) -> EvalResult:
    """Run the engine against the fixture and compare against the committed golden."""
    name = "audit-regression"
    try:
        with open(golden_path, encoding="utf-8") as f:
            golden = json.load(f)
    except (OSError, ValueError) as exc:
        return EvalResult(name, False, f"cannot read golden {golden_path}: {exc}")

    try:
        contacts = _load_contacts(fixture_path)
    except (OSError, ValueError) as exc:
        return EvalResult(name, False, f"cannot read fixture {fixture_path}: {exc}")

    now = datetime.fromisoformat(golden["now"])
    result = engine.run_engine(contacts, now=now)

    mismatches = []
    if result.total_records != golden["total_records"]:
        mismatches.append(f"total_records {result.total_records} != golden {golden['total_records']}")
    if round(result.portal_score, 2) != round(golden["portal_score"], 2):
        mismatches.append(f"portal_score {result.portal_score:.2f} != golden {golden['portal_score']:.2f}")

    if mismatches:
        return EvalResult(name, False, "; ".join(mismatches))
    return EvalResult(
        name, True,
        f"portal_score {result.portal_score:.2f}, {result.total_records} records — matches golden",
    )


def check_audit_determinism(fixture_path: Path = FIXTURE_PATH) -> EvalResult:
    """Run the engine twice on the same input; results must be identical."""
    name = "audit-determinism"
    try:
        contacts = _load_contacts(fixture_path)
    except (OSError, ValueError) as exc:
        return EvalResult(name, False, f"cannot read fixture {fixture_path}: {exc}")

    now = datetime.now(timezone.utc)
    first = engine.run_engine(contacts, now=now)
    second = engine.run_engine(contacts, now=now)

    if first.portal_score != second.portal_score:
        return EvalResult(name, False, f"portal_score drifted: {first.portal_score} != {second.portal_score}")
    if [r.overall for r in first.records] != [r.overall for r in second.records]:
        return EvalResult(name, False, "per-record overall scores drifted between runs")

    return EvalResult(name, True, f"two runs of {first.total_records} records identical")


def check_receipts_integrity(receipts_path: Path | None = None) -> EvalResult:
    """Every receipts.jsonl line must parse as JSON with the required keys."""
    name = "receipts-integrity"
    path = Path(receipts_path) if receipts_path is not None else DEFAULT_RECEIPTS_PATH

    if not path.exists():
        return EvalResult(name, True, "no receipts yet")

    lines = path.read_text(encoding="utf-8").splitlines()
    bad_lines = []
    for i, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            bad_lines.append(f"line {i}: not valid JSON")
            continue
        missing = [k for k in REQUIRED_RECEIPT_KEYS if k not in record]
        if missing:
            bad_lines.append(f"line {i}: missing keys {missing}")

    if bad_lines:
        return EvalResult(name, False, "; ".join(bad_lines))
    return EvalResult(name, True, f"{len([l for l in lines if l.strip()])} receipts, all valid")


def check_harness_contract(source_root: Path = GTMOS_SRC) -> EvalResult:
    """No file outside harness.py may shell out to claude directly.

    Simple string scan: flag any .py file (other than harness.py) that
    contains a subprocess call *and* mentions "claude" — the signature of
    bypassing the single chokepoint.
    """
    name = "harness-contract"
    offenders = []
    for path in sorted(source_root.rglob("*.py")):
        if path.name == "harness.py":
            continue
        text = path.read_text(encoding="utf-8")
        if SUBPROCESS_CALL_RE.search(text) and "claude" in text.lower():
            try:
                offenders.append(str(path.relative_to(source_root.parent)))
            except ValueError:
                offenders.append(str(path))

    if offenders:
        return EvalResult(name, False, f"subprocess+claude found outside harness.py: {', '.join(offenders)}")
    return EvalResult(name, True, "no subprocess calls to claude outside harness.py")


def _is_token_env_get(node: ast.AST) -> bool:
    """True for a call shaped like `<obj>.get("GTMOS_HUBSPOT_TOKEN")` —
    covers os.environ.get(...), a bare environ.get(...), and an `env.get(...)`
    parameter alias (as gtmos.doctor uses). Does not catch dict-subscript
    access (env["GTMOS_HUBSPOT_TOKEN"])."""
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "get"
        and bool(node.args)
        and isinstance(node.args[0], ast.Constant)
        and node.args[0].value == TOKEN_ENV_VAR
    )


def _references_name(node: ast.AST, names: set) -> bool:
    return any(isinstance(sub, ast.Name) and sub.id in names for sub in ast.walk(node))


def _function_leaks_token(func_node: ast.AST) -> bool:
    """True if `func_node` assigns a local from a GTMOS_HUBSPOT_TOKEN env
    lookup and then, in that same function, passes that local into a
    print(...) call (directly or nested inside an f-string/expression)."""
    token_vars = set()
    for node in ast.walk(func_node):
        if isinstance(node, ast.Assign) and _is_token_env_get(node.value):
            token_vars.update(t.id for t in node.targets if isinstance(t, ast.Name))
    if not token_vars:
        return False

    for node in ast.walk(func_node):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "print"
            and any(_references_name(arg, token_vars) for arg in node.args)
        ):
            return True
    return False


def check_token_hygiene(source_root: Path = GTMOS_SRC) -> EvalResult:
    """Static scan: no file outside a `fetch.py` module (the two places —
    audit/fetch.py, funnel/fetch.py — allowed to hold a raw token, for the
    Authorization header) may assign a GTMOS_HUBSPOT_TOKEN env lookup to a
    local and then pass that same local into a print(...) call.

    What this catches: `token = os.environ.get("GTMOS_HUBSPOT_TOKEN"); ...
    print(f"...{token}...")` in the same function — an accidental debug
    print of the raw secret.

    What this can't catch: indirection through a second function
    (`log_it(token)` defined elsewhere and called from the print site),
    dict/subscript env access (`env["GTMOS_HUBSPOT_TOKEN"]`), non-print
    output (logging calls, file writes, exception messages built from the
    raw token), or a token copied to a differently-named variable before
    printing. It is a cheap regression lock, not a security audit — pair
    it with code review for anything that touches credentials. It will
    also flag a *masked* print like `print(_mask_token(token))` as a false
    positive, since it only checks whether the name is referenced
    anywhere in the print call's arguments, not whether it's wrapped in a
    masking call first — assign the masked value to a new name before
    printing to keep this check honest.
    """
    name = "token-hygiene"
    offenders = []
    for path in sorted(source_root.rglob("*.py")):
        if path.name == "fetch.py":
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            offenders.append(f"{path}: could not parse ({exc})")
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and _function_leaks_token(node):
                try:
                    offenders.append(f"{path.relative_to(source_root.parent)}:{node.name}")
                except ValueError:
                    offenders.append(f"{path}:{node.name}")

    if offenders:
        return EvalResult(name, False, f"possible token print in: {', '.join(offenders)}")
    return EvalResult(name, True, "no print(...) of a GTMOS_HUBSPOT_TOKEN-derived local outside fetch.py")


def check_state_atomicity(state_path: Path = STATE_PATH) -> EvalResult:
    """Static regression lock: plays/state.py's save_state must still route
    through os.replace (the atomic-rename primitive that makes it
    crash-safe). This is a cheap string scan, not a behavioral test — it
    confirms the tmp-then-replace pattern hasn't been quietly reverted to a
    plain write_text(), but it can't tell if os.replace is being called
    correctly (right paths, right order)."""
    name = "state-atomicity"
    try:
        text = state_path.read_text(encoding="utf-8")
    except OSError as exc:
        return EvalResult(name, False, f"cannot read {state_path}: {exc}")

    if "os.replace(" not in text:
        return EvalResult(name, False, f"{state_path} no longer calls os.replace(...) — atomic write regressed")
    return EvalResult(name, True, f"{state_path} save path uses os.replace(...)")


def check_judge(report_path: Path | None = None) -> EvalResult:
    """Optional: grade a sample report's actionability 1-10 via the harness. Skips cleanly if absent."""
    name = "judge"
    path = Path(report_path) if report_path is not None else REPO_ROOT / "audit-out" / "integrity-report.md"

    if not path.exists():
        return EvalResult(name, True, f"skipped — {path} not present")

    from gtmos import harness

    from gtmos.prompts import render_prompt

    report_text = path.read_text(encoding="utf-8")
    prompt = render_prompt("eval-judge", report=report_text)
    output = harness.run_harness(command="eval-judge", prompt=prompt, allowed_tools=None, bare=True)

    match = re.search(r"\d+", output)
    if not match:
        return EvalResult(name, False, f"could not parse a score from judge output: {output!r}")

    score = int(match.group())
    passed = score >= 7
    return EvalResult(name, passed, f"actionability score {score}/10 ({path.name})")


REGISTRY = {
    "audit-regression": check_audit_regression,
    "audit-determinism": check_audit_determinism,
    "receipts-integrity": check_receipts_integrity,
    "harness-contract": check_harness_contract,
    "token-hygiene": check_token_hygiene,
    "state-atomicity": check_state_atomicity,
}

JUDGE_CHECK_NAME = "judge"


def run_all(judge: bool = False) -> list[EvalResult]:
    results = [fn() for fn in REGISTRY.values()]
    if judge:
        results.append(check_judge())
    return results


def list_checks(judge: bool = False) -> list[str]:
    names = list(REGISTRY.keys())
    if judge:
        names.append(JUDGE_CHECK_NAME)
    return names
