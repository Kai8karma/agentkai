"""`gtmos eval` handler. Runs the eval suite, writes eval-report.md."""

from __future__ import annotations

import argparse
from pathlib import Path

from gtmos.evals import suite


def _write_report(results: list[suite.EvalResult], out_dir: Path) -> Path:
    passed = sum(1 for r in results if r.passed)
    lines: list[str] = []
    lines.append("# GTM OS Eval Report")
    lines.append("")
    lines.append(f"{passed}/{len(results)} checks passed.")
    lines.append("")
    lines.append("| Check | Result | Detail |")
    lines.append("|---|---|---|")
    for r in results:
        status = "pass" if r.passed else "FAIL"
        lines.append(f"| {r.name} | {status} | {r.detail} |")
    lines.append("")

    out_dir.mkdir(parents=True, exist_ok=True)
    report_path = out_dir / "eval-report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def run(args: argparse.Namespace) -> int:
    judge = getattr(args, "judge", False)
    out_dir = Path(getattr(args, "out", None) or "./eval-out")

    if getattr(args, "dry_run", False):
        for name in suite.list_checks(judge=judge):
            print(f"[dry-run] would run: {name}")
        return 0

    results = suite.run_all(judge=judge)
    report_path = _write_report(results, out_dir)

    passed = sum(1 for r in results if r.passed)
    print(f"eval: {passed}/{len(results)} passed — report: {report_path}")

    return 0 if passed == len(results) else 1
