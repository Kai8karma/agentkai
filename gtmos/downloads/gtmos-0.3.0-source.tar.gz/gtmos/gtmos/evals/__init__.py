"""Layer-5 eval harness — catches silent agent/engine regressions. No LLM in the default checks."""
