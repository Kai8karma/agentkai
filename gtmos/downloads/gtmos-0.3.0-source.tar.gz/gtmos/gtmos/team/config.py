"""Config loader for gtmos-team.json — walk-up discovery + dotted-path get.

Other gtmos modules (audit, abm, commands/*) import this later to read
team.acv / team.icp / roles without re-implementing discovery. Keep the
API tiny and stable: load_config, config_get.
"""

from __future__ import annotations

import json
from pathlib import Path

CONFIG_FILENAME = "gtmos-team.json"


def find_config_path(start_dir: str = ".") -> Path | None:
    """Walk up from start_dir looking for gtmos-team.json. Returns the
    resolved path, or None if not found by the filesystem root."""
    current = Path(start_dir).resolve()
    while True:
        candidate = current / CONFIG_FILENAME
        if candidate.exists():
            return candidate
        if current.parent == current:
            return None
        current = current.parent


def load_config(start_dir: str = ".") -> dict | None:
    """Find and parse gtmos-team.json by walking up from start_dir.
    Returns the parsed dict, or None if no config file is found."""
    path = find_config_path(start_dir)
    if path is None:
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def config_get(cfg: dict | None, path_dotted: str, default=None):
    """Look up a dotted path (e.g. "team.acv") inside cfg. Returns
    `default` if cfg is None or any segment along the path is missing."""
    if cfg is None:
        return default
    node = cfg
    for part in path_dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node
