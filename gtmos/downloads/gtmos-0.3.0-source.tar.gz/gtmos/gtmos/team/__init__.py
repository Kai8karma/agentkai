"""Workspace / team module — `gtmos init` scaffolds doctrine + config into a
target directory; `gtmos team` reads/edits the resulting gtmos-team.json.

Doctrine as OS root (Pattern 1): every other gtmos command reads its
defaults (ICP, ACV, role→command map, stage order) from gtmos-team.json via
gtmos.team.config, rather than each command re-inventing its own config.
"""

from __future__ import annotations
