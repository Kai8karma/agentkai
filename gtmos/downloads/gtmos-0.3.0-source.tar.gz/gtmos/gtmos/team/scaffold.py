"""Workspace scaffolding for `gtmos init` — writes gtmos-team.json,
DOCTRINE.md, PLAN.md, and PLAYS.md into a target directory.

Idempotent per file: any file that already exists is left untouched unless
force=True is passed, so re-running `gtmos init` never clobbers edits.
"""

from __future__ import annotations

import copy
import json
from datetime import date as _date
from pathlib import Path

from gtmos.team.templates import DEFAULT_CONFIG, DOCTRINE_MD, PLAN_MD, PLAYS_MD

CONFIG_FILENAME = "gtmos-team.json"


def build_config(team_name: str) -> dict:
    """Return a fresh deep copy of DEFAULT_CONFIG with team.name set."""
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    cfg["team"]["name"] = team_name
    return cfg


def _write_if_needed(path: Path, content: str, force: bool) -> bool:
    """Write `content` to `path` unless it exists and force is False.
    Returns True if the file was (re)written, False if skipped."""
    if path.exists() and not force:
        return False
    path.write_text(content, encoding="utf-8")
    return True


def scaffold(target_dir: str, team_name: str = "Your Team", force: bool = False) -> dict:
    """Scaffold gtmos-team.json + DOCTRINE.md + PLAN.md + PLAYS.md into
    target_dir (created if missing). Returns
    {"created": [filenames], "skipped": [filenames]}.
    """
    out_dir = Path(target_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    today = _date.today().isoformat()

    created: list[str] = []
    skipped: list[str] = []

    config_path = out_dir / CONFIG_FILENAME
    config_json = json.dumps(build_config(team_name), indent=2) + "\n"
    if _write_if_needed(config_path, config_json, force):
        created.append(CONFIG_FILENAME)
    else:
        skipped.append(CONFIG_FILENAME)

    docs = {
        "DOCTRINE.md": DOCTRINE_MD.format(team_name=team_name, date=today),
        "PLAN.md": PLAN_MD.format(team_name=team_name, date=today),
        "PLAYS.md": PLAYS_MD.format(team_name=team_name, date=today),
    }
    for filename, content in docs.items():
        path = out_dir / filename
        if _write_if_needed(path, content, force):
            created.append(filename)
        else:
            skipped.append(filename)

    return {"created": created, "skipped": skipped}
