"""`gtmos init` / `gtmos team` handlers.

The integrator wires two argparse subparsers ("init" and "team") that both
point at this module's `run(args)`. `run` dispatches on `args.team_cmd` if
the integrator sets it (`set_defaults(team_cmd="init"|"team")`); failing
that it falls back to inspecting which init-only / team-only attributes are
present on `args`, so `run_init` / `run_team` also work when called
directly (as the tests do).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from gtmos.team.config import config_get, find_config_path
from gtmos.team.scaffold import scaffold

_INIT_ONLY_ATTRS = ("force", "name")
_TEAM_ONLY_ATTRS = ("show", "get", "set")


def run_init(args: argparse.Namespace) -> int:
    target_dir = getattr(args, "dir", None) or "."
    force = bool(getattr(args, "force", False))
    team_name = getattr(args, "name", None) or Path(target_dir).resolve().name or "Your Team"

    result = scaffold(target_dir, team_name=team_name, force=force)
    created, skipped = result["created"], result["skipped"]

    created_part = ", ".join(created) if created else "none"
    skipped_part = ", ".join(skipped) if skipped else "none"
    print(f"team: created {len(created)} file(s) ({created_part}); skipped {len(skipped)} ({skipped_part})")
    return 0


def _coerce(raw: str, existing=None):
    """Coerce a --set value string, matching the type of the existing
    config value where one exists (so `team.acv` stays a float even when
    the CLI is handed the plain digits "9000")."""
    if isinstance(existing, bool):
        return raw.lower() in ("true", "1", "yes")
    if isinstance(existing, float):
        try:
            return float(raw)
        except ValueError:
            return raw
    if isinstance(existing, int):
        try:
            return int(raw)
        except ValueError:
            pass
        try:
            return float(raw)
        except ValueError:
            return raw

    low = raw.lower()
    if low in ("true", "false"):
        return low == "true"
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    return raw


def _set_value(cfg: dict, path_dotted: str, raw_value: str) -> None:
    parts = path_dotted.split(".")
    node = cfg
    for part in parts[:-1]:
        nxt = node.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            node[part] = nxt
        node = nxt
    key = parts[-1]
    node[key] = _coerce(raw_value, node.get(key))


def _print_show(cfg: dict) -> None:
    team = cfg.get("team", {})
    print(f"team: {team.get('name', '')}")
    print(f"icp: {team.get('icp', '')}")
    print(f"acv: {team.get('acv', 0)}")
    print("roles:")
    for role, commands in team.get("roles", {}).items():
        print(f"  {role}: {', '.join(commands)}")


def run_team(args: argparse.Namespace) -> int:
    start_dir = getattr(args, "dir", None) or "."
    config_path = find_config_path(start_dir)
    if config_path is None:
        print("team: no gtmos-team.json found — run `gtmos init` first")
        return 1

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"team: cannot read {config_path}: {exc}")
        return 1

    set_expr = getattr(args, "set", None)
    get_path = getattr(args, "get", None)

    if set_expr:
        if "=" not in set_expr:
            print('team: --set expects "path.to.key=value" (e.g. team.acv=9000)')
            return 2
        path_dotted, raw_value = set_expr.split("=", 1)
        _set_value(cfg, path_dotted.strip(), raw_value.strip())
        config_path.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
        print(f"team: set {path_dotted.strip()} = {config_get(cfg, path_dotted.strip())!r}")
        return 0

    if get_path:
        value = config_get(cfg, get_path, default=None)
        if value is None:
            print(f"team: {get_path} not found")
            return 1
        print(value)
        return 0

    _print_show(cfg)
    return 0


def run(args: argparse.Namespace) -> int:
    team_cmd = getattr(args, "team_cmd", None)
    if team_cmd == "init":
        return run_init(args)
    if team_cmd == "team":
        return run_team(args)

    if any(hasattr(args, attr) for attr in _INIT_ONLY_ATTRS):
        return run_init(args)
    if any(hasattr(args, attr) for attr in _TEAM_ONLY_ATTRS):
        return run_team(args)

    print("team: unable to determine subcommand (init or team)")
    return 2
