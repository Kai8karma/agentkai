"""String templates for `gtmos init` — the default team config plus the
three doctrine markdown scaffolds. Docs are plain strings interpolated via
str.format({team_name}, {date}) — no templating engine, stdlib only.
"""

from __future__ import annotations

DEFAULT_CONFIG: dict = {
    "team": {
        "name": "",
        "icp": "",
        "acv": 0.0,
        "roles": {
            "founder": ["audit", "abm", "prospect", "stalk", "draft", "brief", "outcomes", "team"],
            "revops": ["audit", "funnel", "weekly"],
            "sdr": ["prospect", "stalk", "draft", "play"],
            "marketing": ["abm", "draft", "play"],
        },
    },
    "stages": {
        "order": ["prospect", "engaged", "qualified", "opportunity", "closed_won", "closed_lost"],
        "stall_days": 21,
    },
    "tiers": ["respond", "nurture", "wait", "skip"],
}

DOCTRINE_MD = """# {team_name} — GTM OS Doctrine

_Generated {date}_

Doctrine as OS root (Pattern 1): every gtmos command reads its defaults from
`gtmos-team.json` here rather than hardcoding ICP/ACV/roles per command.
Prune this file as the team learns — stale doctrine is worse than none
(Pattern 9: doctrine-pruning).

## Scope

{team_name} runs GTM OS as a self-hosted operating system: your CRM, your
keys, your machine. Describe what {team_name} sells and to whom here.

## Out of scope

- No cloud CRM egress beyond the portal you already own (HubSpot etc.).
- No live spend-affecting action without a human typing explicit approval.
- List anything else {team_name} has ruled out (verticals, motions, tools).

## Two hard rules

1. **Deterministic scoring.** Anything that scores/ranks/grades records
   (audit, funnel, ICP fit) is plain Python — no LLM in the score path.
2. **All LLM calls go through the harness chokepoint.** Every narrative or
   drafting command shells out via `gtmos.harness.run_harness()` — no
   command calls `claude` directly. This keeps the receipts log complete
   and the LLM surface auditable.

## Zero-egress principle

Nothing about {team_name}'s CRM leaves its infrastructure unless a command
is explicitly pointed at a service {team_name} already uses and has a token
for. Self-hosted is a tiebreaker in positioning, never the headline.

## Weekly loop cadence

- Monday: `gtmos audit` — refresh the CRM Integrity Score, check for drift.
- Mid-week: `gtmos prospect` / `gtmos abm` — feed the funnel per the roles
  in `gtmos-team.json`.
- Friday: `gtmos brief` — review the week, log outcomes with
  `gtmos outcomes`, prune this doctrine if anything here went stale.

## Doctrine-pruning rule (Pattern 9)

Review this file every weekly loop. If a rule above no longer reflects how
{team_name} actually runs GTM, cut it — don't let dead doctrine accumulate.
"""

PLAN_MD = """# {team_name} — Plan

_Generated {date}_

Wave-based plan (Pattern 17): work ships in waves, not a single roadmap.
Each wave has a charter (what it proves), a date range, and a status.

## Waves

| Wave | Charter | Start | End | Status |
|---|---|---|---|---|
| 1 | | {date} | | not-started |

Add rows as waves are chartered. Statuses: not-started, in-progress,
shipped, killed.
"""

PLAYS_MD = """# {team_name} — Plays

_Generated {date}_

Signal plays index for {team_name}. This file is a pointer, not the source
of truth — the live, current list of plays lives in the CLI:

```
gtmos play list
```

Run that command for the up-to-date play catalog (triggers, disqualifiers,
messaging angle per play) rather than trusting a stale copy here.
"""
