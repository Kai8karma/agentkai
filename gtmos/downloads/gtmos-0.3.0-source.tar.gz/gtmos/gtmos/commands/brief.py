"""gtmos brief — daily GTM brief: pipeline state, follow-ups, top 3 actions.

Pipeline state is fetched directly (no MCP dependency) via a HubSpot
REST call gated on GTMOS_HUBSPOT_TOKEN, with a --input JSON fallback so
the brief is buildable and testable with no network/token at all. The
receipts log is read directly by this module (deterministic, no LLM)
so the harness gets real recent-activity data instead of guessing.
Brain search runs inside the harness call itself (allowed_tools).

The prompt text lives in gtmos.prompts (name="brief") so a team can
retune wording per-workspace via gtmos-prompts.json without forking this
module.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path

RECEIPTS_PATH = Path.home() / ".gtmos" / "receipts.jsonl"


def _fetch_hubspot_pipeline() -> dict | None:
    token = os.environ.get("GTMOS_HUBSPOT_TOKEN")
    if not token:
        return None
    url = "https://api.hubapi.com/crm/v3/objects/deals/search"
    body = json.dumps(
        {
            "filterGroups": [
                {"filters": [{"propertyName": "dealstage", "operator": "HAS_PROPERTY"}]}
            ],
            "properties": ["dealname", "amount", "dealstage", "closedate"],
            "limit": 25,
        }
    ).encode()
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError as e:
        raise RuntimeError(f"HubSpot deals search failed: {e}") from e


def _build_pipeline_block(input_path: str | None) -> str:
    if input_path:
        with open(input_path) as f:
            data = json.load(f)
        return json.dumps(data, indent=2)
    data = _fetch_hubspot_pipeline()
    if data is None:
        return (
            "GTMOS_HUBSPOT_TOKEN not set and no --input file given — no "
            "direct pipeline fetch was performed."
        )
    return json.dumps(data, indent=2)


def _read_receipts(limit: int = 20) -> list[dict]:
    if not RECEIPTS_PATH.exists():
        return []
    lines = RECEIPTS_PATH.read_text().splitlines()
    entries = [json.loads(line) for line in lines[-limit:] if line.strip()]
    return entries


def run(args) -> None:
    from gtmos.harness import run_harness
    from gtmos.prompts import render_prompt

    pipeline_block = _build_pipeline_block(getattr(args, "input", None))
    receipts = _read_receipts()
    receipts_block = json.dumps(receipts, indent=2) if receipts else "No receipts logged yet."

    prompt = render_prompt("brief", ".", pipeline_block=pipeline_block, receipts_block=receipts_block)

    output = run_harness(
        command="brief",
        prompt=prompt,
        allowed_tools=["Bash", "mcp__kai-brain__brain_search"],
    )
    print(output)
