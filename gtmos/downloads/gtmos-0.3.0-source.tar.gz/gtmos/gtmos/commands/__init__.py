"""GTM OS LLM-harness commands: prospect, stalk, draft, brief, outcomes.

Every module here exposes a module-level PROMPT template and a run(args)
function. run() composes the final prompt and calls
gtmos.harness.run_harness() (the single chokepoint for claude CLI calls) —
except outcomes.py, which is a direct brain-CLI wrapper with no LLM step.
"""
