"""gtmos prospect — build a play-tagged, A/B-armed lead list for an ICP.

Grounded in outbound-sdr.md (plays library, disqualifiers, arm split) and
gtm-lead.md (COI boundary, offer). No live API is called from this module
directly: list-building tools (Apollo MCP / WebSearch) are whatever the
invoking claude session already has configured — we pass allowed_tools=None
so the harness inherits the user's tool config rather than guessing MCP
tool names that may differ per install.

--input lets a caller hand the harness a pre-fetched JSON array of
candidate leads (e.g. an Apollo export) so the tagging pass is testable
offline without network access or MCP auth.

The prompt text lives in gtmos.prompts (name="prospect") so a team can
retune wording per-workspace via gtmos-prompts.json without forking this
module.
"""

from __future__ import annotations

import json
import os


def _build_input_block(input_path: str | None) -> str:
    if not input_path:
        return (
            "No pre-fetched lead data was supplied — source leads live "
            "via Apollo MCP or WebSearch as described above."
        )
    with open(input_path) as f:
        candidates = json.load(f)
    return (
        f"## Candidate pool ({len(candidates)} pre-fetched records — "
        "tag/dq from this data, do not re-fetch)\n"
        f"{json.dumps(candidates, indent=2)}"
    )


def run(args) -> None:
    from gtmos.harness import run_harness
    from gtmos.prompts import render_prompt

    icp = getattr(args, "icp", None)
    if not icp:
        raise SystemExit("gtmos prospect requires an ICP (--icp \"description\")")
    count = getattr(args, "count", 75) or 75
    arm_a = count // 2 + count % 2
    arm_b = count - arm_a

    prompt = render_prompt(
        "prospect",
        ".",
        icp=icp,
        count=count,
        arm_a=arm_a,
        arm_b=arm_b,
        input_block=_build_input_block(getattr(args, "input", None)),
        coi_lanes=os.environ.get("GTMOS_COI_LANES", "none configured — set GTMOS_COI_LANES"),
    )

    output = run_harness(
        command="prospect",
        prompt=prompt,
        allowed_tools=None,
    )
    print(output)
