"""gtmos outcomes — log recall outcomes / read ROI. Direct brain CLI only.

No run_harness call here on purpose: outcome logging (win/loss/neutral →
confidence adjustment) is deterministic bookkeeping in kai-brain.db, not
a narrative/drafting step. Routing it through an LLM would make ROI
tracking non-reproducible and add a point of failure to something that
must never silently no-op — untracked recall is theater (per doctrine),
so this stays a thin, honest subprocess wrapper around the brain CLI.
"""

from __future__ import annotations

import subprocess

VERDICTS = ("win", "loss", "neutral")


def run(args) -> None:
    log = getattr(args, "log", None)
    roi = getattr(args, "roi", False)

    if not log and not roi:
        raise SystemExit("gtmos outcomes requires --log \"mem_id verdict [note]\" or --roi")

    if roi:
        result = subprocess.run(["brain", "roi"], capture_output=True, text=True)
        print(result.stdout, end="")
        if result.returncode != 0:
            print(result.stderr, end="")
            raise SystemExit(result.returncode)

    if log:
        parts = log.split(maxsplit=2)
        if len(parts) < 2:
            raise SystemExit('gtmos outcomes --log requires "mem_id verdict [note]"')
        mem_id, verdict = parts[0], parts[1]
        note = parts[2] if len(parts) > 2 else None
        if verdict not in VERDICTS:
            raise SystemExit(f"verdict must be one of {VERDICTS}, got {verdict!r}")

        cmd = ["brain", "outcome", mem_id, verdict]
        if note:
            cmd.append(note)
        result = subprocess.run(cmd, capture_output=True, text=True)
        print(result.stdout, end="")
        if result.returncode != 0:
            print(result.stderr, end="")
            raise SystemExit(result.returncode)
