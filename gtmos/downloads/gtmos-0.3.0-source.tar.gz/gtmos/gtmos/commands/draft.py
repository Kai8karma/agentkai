"""gtmos draft — content in Kai's voice, gated on a self-eval pass.

Voice fingerprint + brain recall + an internal VOICE/HOOK/DENSITY/CTA/
FORMAT eval gate all happen inside the single harness call (the harness
is one `claude -p` subprocess — the "loop" is the model revising its own
draft before it hands back output, not multiple Python-side calls).
Tool names are known and stable here (Kai's own kai-brain MCP + Bash),
so unlike prospect/stalk we pass a concrete allowed_tools list instead
of inheriting the ambient config.

The per-kind drafting prompt lives in gtmos.prompts as "draft-linkedin" /
"draft-x" / "draft-outreach" so a team can retune wording per-workspace
via gtmos-prompts.json without forking this module. The independent judge
prompt and the revision loop below stay local — they aren't part of the
registry's named surface.
"""

from __future__ import annotations

KINDS = ("linkedin", "x", "outreach")

FORMAT_RULES = {
    "linkedin": "Hook-first, under ~200 words, one idea, no hashtag stuffing.",
    "x": "Single post, under 280 characters, one idea, no thread unless asked.",
    "outreach": (
        "≤3 lines. One verified leak/fact, one number, one ask — per "
        "outbound-sdr.md copy rules. NEVER invent a trigger; if the topic "
        "gives you no verifiable fact, say so instead of drafting a "
        "generic line."
    ),
}


JUDGE_PROMPT = """You are an independent, ruthless content judge. Score this
{kind} draft 1-10 on: VOICE (operator-direct, zero corporate filler), HOOK
(first line earns the read), DENSITY (no filler, one idea), CTA (clear next
step, or deliberately none), FORMAT ({format_rules}).

Draft:
---
{draft}
---

Do not be generous; 8 means genuinely publishable. Reply in EXACTLY this
format (two lines, nothing else):
SCORES: VOICE=n HOOK=n DENSITY=n CTA=n FORMAT=n
FEEDBACK: <one sentence naming the weakest dimension and the concrete fix>
"""

GATE_MIN = 8

_SCORES_RE = None  # compiled lazily


def _parse_scores(judge_output: str) -> tuple[dict[str, int], str]:
    global _SCORES_RE
    import re

    if _SCORES_RE is None:
        _SCORES_RE = re.compile(r"(VOICE|HOOK|DENSITY|CTA|FORMAT)=(\d+)")
    scores = {m.group(1): int(m.group(2)) for m in _SCORES_RE.finditer(judge_output)}
    feedback = ""
    for line in judge_output.splitlines():
        if line.strip().upper().startswith("FEEDBACK:"):
            feedback = line.split(":", 1)[1].strip()
    return scores, feedback


def run(args) -> None:
    from gtmos.harness import MAX_ITERATIONS, run_harness
    from gtmos.prompts import render_prompt

    kind = getattr(args, "type", None)
    topic = getattr(args, "topic", None)
    if kind not in KINDS:
        raise SystemExit(f"gtmos draft requires --type one of {KINDS}")
    if not topic:
        raise SystemExit("gtmos draft requires a topic")

    tools = ["Bash", "mcp__kai-brain__brain_voice", "mcp__kai-brain__brain_search"]
    prompt = render_prompt(f"draft-{kind}", ".", topic=topic, format_rules=FORMAT_RULES[kind])

    draft = run_harness(command="draft", prompt=prompt, allowed_tools=tools)
    if not draft:
        return

    # Mechanical gate: an INDEPENDENT judge call scores the draft (bare —
    # pure text, no MCPs). Self-scores inside the drafting call are advisory;
    # this loop is what actually decides whether the draft ships.
    for attempt in range(MAX_ITERATIONS):
        judge_out = run_harness(
            command="draft-judge",
            prompt=JUDGE_PROMPT.format(kind=kind, format_rules=FORMAT_RULES[kind], draft=draft),
            allowed_tools=[],
            bare=True,
        )
        scores, feedback = _parse_scores(judge_out)
        failing = {d: s for d, s in scores.items() if s < GATE_MIN}
        if scores and not failing:
            print(draft)
            print(f"\n[gate PASS] {' '.join(f'{d}={s}' for d, s in scores.items())}")
            return
        if attempt < MAX_ITERATIONS - 1:
            draft = run_harness(
                command="draft-revise",
                prompt=(
                    f"{prompt}\n\n## Revision pass\nYour previous draft:\n---\n{draft}\n---\n"
                    f"An independent judge failed it on {sorted(failing) if failing else 'parse'}:"
                    f" {feedback or judge_out[:200]}\nRevise to fix exactly that. Same output format."
                ),
                allowed_tools=tools,
            )
            if not draft:
                break

    print(draft)
    print(f"\n[gate FAIL after {MAX_ITERATIONS} attempts] {failing or 'judge output unparseable'} — do not publish as-is")
    raise SystemExit(1)
