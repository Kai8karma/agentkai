"""gtmos stalk — founder recon before an outbound touch.

Mirrors the founder-stalk skill intent: LinkedIn presence, recent posts,
company signals, prior CRM/brain touch history, one personalization hook.

CRM touch history is fetched directly (no MCP dependency) via a HubSpot
REST call gated on GTMOS_HUBSPOT_TOKEN, with a --input JSON fallback so
the harness prompt is buildable and testable with no network/token at
all. LinkedIn/company-signal recon and brain touch history are left to
the harness's own tools (allowed_tools=None — inherit whatever WebSearch
/ brain MCP tools the invoking session already has configured).

The prompt text lives in gtmos.prompts (name="stalk") so a team can
retune wording per-workspace via gtmos-prompts.json without forking this
module.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request


def _fetch_hubspot_touch_history(name: str, company: str) -> dict | None:
    token = os.environ.get("GTMOS_HUBSPOT_TOKEN")
    if not token:
        return None
    url = "https://api.hubapi.com/crm/v3/objects/contacts/search"
    body = json.dumps(
        {
            "filterGroups": [
                {
                    "filters": [
                        {
                            "propertyName": "company",
                            "operator": "CONTAINS_TOKEN",
                            "value": company,
                        }
                    ]
                }
            ],
            "properties": [
                "firstname",
                "lastname",
                "company",
                "lastmodifieddate",
                "notes_last_contacted",
            ],
            "limit": 5,
        }
    ).encode()
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.URLError as e:
        raise RuntimeError(f"HubSpot contact search failed: {e}") from e


def _build_crm_block(name: str, company: str, input_path: str | None) -> str:
    if input_path:
        with open(input_path) as f:
            data = json.load(f)
        return f"## Pre-fetched CRM context\n{json.dumps(data, indent=2)}"
    data = _fetch_hubspot_touch_history(name, company)
    if data is None:
        return (
            "## CRM context\nGTMOS_HUBSPOT_TOKEN not set and no --input "
            "file given — no direct CRM lookup was performed. Rely on "
            "brain search for any prior-touch history."
        )
    return f"## CRM context (live HubSpot search)\n{json.dumps(data, indent=2)}"


def run(args) -> None:
    from gtmos.harness import run_harness
    from gtmos.prompts import render_prompt

    name = getattr(args, "name", None)
    company = getattr(args, "company", None)
    if not name or not company:
        raise SystemExit("gtmos stalk requires --name and --company")

    prompt = render_prompt(
        "stalk",
        ".",
        name=name,
        company=company,
        crm_block=_build_crm_block(name, company, getattr(args, "input", None)),
        coi_lanes=os.environ.get("GTMOS_COI_LANES", "none configured — set GTMOS_COI_LANES"),
    )

    output = run_harness(
        command="stalk",
        prompt=prompt,
        allowed_tools=None,
    )
    print(output)
