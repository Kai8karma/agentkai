"""`gtmos funnel` handler. Resolves a deal source, runs the leak engine, writes the report."""

from __future__ import annotations

import argparse
import os

from gtmos.funnel import engine, fetch, report


def run(args: argparse.Namespace) -> int:
    if args.input:
        try:
            deals = fetch.load_json(args.input)
        except (OSError, ValueError) as exc:
            print(f"funnel: {exc}")
            return 1
    elif args.portal:
        try:
            deals = fetch.fetch_hubspot_deals(os.environ.get("GTMOS_HUBSPOT_TOKEN"))
        except RuntimeError as exc:
            print(f"funnel: {exc}")
            return 1
    else:
        print("funnel: pass --input <file.json> or --portal (requires GTMOS_HUBSPOT_TOKEN)")
        return 2

    if not deals:
        print("funnel: no deals found in source")
        return 1

    # Team config (gtmos-team.json, written by `gtmos init`) supplies
    # defaults for anything not passed as a flag.
    from gtmos.team.config import config_get, load_config

    cfg = load_config()

    acv = getattr(args, "acv", None)
    if acv is None:
        acv = config_get(cfg, "team.acv")
    if acv and engine.all_amounts_missing(deals):
        # No deal in the source carries an amount at all — the dataset median
        # imputation has nothing to work with, so fall back to the caller's
        # average-contract-value assumption instead of imputing $0 everywhere.
        for deal in deals:
            deal["amount"] = acv

    stall_days = (
        getattr(args, "stall_days", None)
        or config_get(cfg, "stages.stall_days")
        or engine.DEFAULT_STALL_DAYS
    )
    result = engine.run_engine(deals, engine.DEFAULT_STAGE_ORDER, stall_days=stall_days)
    summary = report.render(result, args.out)

    print(
        f"funnel: {result.total_deals} deals analyzed — "
        f"losing ${summary['leak_total']:,.0f} ({summary['stalled_count']} stalled) — "
        f"report: {summary['report_path']}"
    )
    return 0
