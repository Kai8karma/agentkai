"""Gather and render the weekly ops review from whatever sources exist on disk.

Sources are read defensively — audit and funnel outputs come from separate
gtmos commands (funnel may be built by a different agent, its exact JSON
shape isn't guaranteed), and receipts.jsonl may not exist yet. Missing
sources are noted in "gaps", never a crash.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

DEFAULT_AUDIT_PATH = Path("audit-out") / "scores.json"
DEFAULT_FUNNEL_PATH = Path("funnel-out") / "funnel.json"
DEFAULT_RECEIPTS_PATH = Path.home() / ".gtmos" / "receipts.jsonl"

AUDIT_SCORE_ALIASES = ["portal_score"]
AUDIT_GRADE_ALIASES = ["grade"]
FUNNEL_LEAK_ALIASES = ["leak_total", "total_leak", "leak", "estimated_leak_usd"]
FUNNEL_STALLED_ALIASES = ["stalled_count", "stalled", "stalled_deals"]


def _get(obj: dict, aliases: list[str]):
    for name in aliases:
        if name in obj:
            return obj[name]
    return None


def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _audit_summary(path: Path, gaps: list[str]) -> dict | None:
    data = _load_json(path)
    if data is None:
        gaps.append(f"audit: no data at {path} — run `gtmos audit`")
        return None
    return {"portal_score": _get(data, AUDIT_SCORE_ALIASES), "grade": _get(data, AUDIT_GRADE_ALIASES)}


def _funnel_summary(path: Path, gaps: list[str]) -> dict | None:
    data = _load_json(path)
    if data is None:
        gaps.append(f"funnel: no data at {path} — run `gtmos funnel`")
        return None
    return {"leak_total": _get(data, FUNNEL_LEAK_ALIASES), "stalled_count": _get(data, FUNNEL_STALLED_ALIASES)}


def _activity_summary(path: Path, now: datetime, gaps: list[str]) -> dict:
    empty = {"harness_calls_7d": 0, "commands_breakdown": {}}
    if not path.exists():
        gaps.append(f"activity: no receipts at {path} yet")
        return empty

    cutoff = now - timedelta(days=7)
    breakdown: dict[str, int] = {}
    total = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        ts = record.get("ts")
        if not isinstance(ts, (int, float)):
            continue
        if datetime.fromtimestamp(ts, tz=timezone.utc) < cutoff:
            continue
        total += 1
        command = record.get("command", "unknown")
        breakdown[command] = breakdown.get(command, 0) + 1

    return {"harness_calls_7d": total, "commands_breakdown": breakdown}


def gather(
    audit_path: Path | str = DEFAULT_AUDIT_PATH,
    funnel_path: Path | str = DEFAULT_FUNNEL_PATH,
    receipts_path: Path | str = DEFAULT_RECEIPTS_PATH,
    now: datetime | None = None,
) -> dict:
    now = now or datetime.now(timezone.utc)
    gaps: list[str] = []

    audit = _audit_summary(Path(audit_path), gaps)
    funnel = _funnel_summary(Path(funnel_path), gaps)
    activity = _activity_summary(Path(receipts_path), now, gaps)

    return {
        "audit": audit,
        "funnel": funnel,
        "activity": activity,
        "gaps": gaps,
        "generated_at": now.isoformat(timespec="seconds"),
    }


def _leak_lines(weekly: dict) -> list[str]:
    lines = ["## Where you're losing money", ""]
    audit = weekly.get("audit")
    funnel = weekly.get("funnel")

    if not audit and not funnel:
        lines.append("No audit or funnel data available yet — run `gtmos audit` and `gtmos funnel`.")
        lines.append("")
        return lines

    if audit and audit.get("portal_score") is not None:
        lines.append(f"- CRM integrity: portal score {audit['portal_score']:.1f} (grade {audit.get('grade', '?')})")
    if funnel and funnel.get("leak_total") is not None:
        lines.append(f"- Funnel leak: ${funnel['leak_total']:,.0f}")
    if funnel and funnel.get("stalled_count") is not None:
        lines.append(f"- Stalled deals: {funnel['stalled_count']}")
    lines.append("")
    return lines


def render(weekly: dict, out_dir: str) -> dict:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    lines: list[str] = []
    lines.append("# Weekly GTM Review")
    lines.append("")
    lines.append(f"_Generated {weekly['generated_at']}_")
    lines.append("")

    lines.append("## Scoreboard")
    lines.append("")
    audit = weekly.get("audit")
    funnel = weekly.get("funnel")
    if audit and audit.get("portal_score") is not None:
        lines.append(f"- CRM integrity: **{audit['portal_score']:.1f}** ({audit.get('grade', '?')})")
    else:
        lines.append("- CRM integrity: no data")
    if funnel and funnel.get("leak_total") is not None:
        lines.append(f"- Funnel leak: **${funnel['leak_total']:,.0f}**")
    else:
        lines.append("- Funnel leak: no data")
    lines.append("")

    lines.extend(_leak_lines(weekly))

    lines.append("## Activity (last 7 days)")
    lines.append("")
    activity = weekly["activity"]
    lines.append(f"- Harness calls: {activity['harness_calls_7d']}")
    if activity["commands_breakdown"]:
        lines.append("")
        lines.append("| Command | Count |")
        lines.append("|---|---|")
        for command, count in sorted(activity["commands_breakdown"].items(), key=lambda kv: -kv[1]):
            lines.append(f"| {command} | {count} |")
    lines.append("")

    lines.append("## Gaps")
    lines.append("")
    if weekly["gaps"]:
        for gap in weekly["gaps"]:
            lines.append(f"- {gap}")
    else:
        lines.append("None — all sources present.")
    lines.append("")

    lines.append("## Next actions")
    lines.append("")
    lines.append("- [ ] Review the worst-scoring CRM records and reassign owners")
    lines.append("- [ ] Chase stalled deals flagged by the funnel audit")
    lines.append("- [ ] Re-run `gtmos audit` / `gtmos funnel` if any source above is stale or missing")
    lines.append("")

    report_path = out_path / "weekly-review.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")

    json_path = out_path / "weekly.json"
    json_path.write_text(json.dumps(weekly, indent=2), encoding="utf-8")

    return {"report_path": str(report_path), "json_path": str(json_path)}
