"""Closed-loop weekly ops review — assembles whatever audit/funnel/activity sources exist on disk."""
