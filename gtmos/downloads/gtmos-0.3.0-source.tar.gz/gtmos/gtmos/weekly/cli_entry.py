"""`gtmos weekly` handler. Assembles whatever sources exist and renders the weekly review."""

from __future__ import annotations

import argparse

from gtmos.weekly import assemble


def run(args: argparse.Namespace) -> int:
    out_dir = getattr(args, "out", None) or "./weekly-out"

    if getattr(args, "dry_run", False):
        print(f"[dry-run] would gather audit/funnel/receipts sources and write weekly review to {out_dir}")
        return 0

    weekly = assemble.gather()
    summary = assemble.render(weekly, out_dir)

    audit = weekly.get("audit")
    funnel = weekly.get("funnel")
    parts = []
    if audit and audit.get("portal_score") is not None:
        parts.append(f"portal score {audit['portal_score']:.1f} ({audit.get('grade', '?')})")
    if funnel and funnel.get("leak_total") is not None:
        parts.append(f"funnel leak ${funnel['leak_total']:,.0f}")
    if not parts:
        parts.append(f"{len(weekly['gaps'])} gaps — see report")

    print(f"weekly: {' — '.join(parts)} — report: {summary['report_path']}")
    return 0
