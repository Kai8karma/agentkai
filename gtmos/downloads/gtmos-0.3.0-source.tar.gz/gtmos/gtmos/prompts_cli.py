"""`gtmos prompts` handler — inspect and export the prompt registry.

Expected argparse.Namespace shape (wired by the integrator's nested
subparser under the top-level "prompts" command, same pattern as
gtmos/team/cli_entry.py):
  prompts_action: "list" | "show" | "export"
  name: str            (show — prompt name)
  out: str | None      (export — output path, default "gtmos-prompts.json")
  dir: str | None      (list, show — workspace to search for an override,
                        default ".", same convention as `gtmos team --dir`)

Exit codes: 0 success, 1 bad input (unknown prompt name, unreadable/invalid
override file), 2 unknown/missing action.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from gtmos.prompts import PROMPTS, get_prompt, is_overridden


def _list_table(workspace: str) -> str:
    rows = [("NAME", "VERSION", "OVERRIDDEN", "DESCRIPTION")]
    for name, entry in PROMPTS.items():
        overridden = "yes" if is_overridden(name, workspace) else "no"
        rows.append((name, str(entry["version"]), overridden, entry["description"]))
    widths = [max(len(r[i]) for r in rows) for i in range(4)]
    lines = []
    for i, row in enumerate(rows):
        lines.append("  ".join(cell.ljust(widths[j]) for j, cell in enumerate(row)))
        if i == 0:
            lines.append("  ".join("-" * w for w in widths))
    return "\n".join(lines)


def _show_text(name: str, workspace: str) -> str:
    entry = PROMPTS[name]
    source = "override" if is_overridden(name, workspace) else "builtin"
    template = get_prompt(name, workspace)
    lines = [
        f"name: {name}",
        f"version: {entry['version']}",
        f"source: {source}",
        f"description: {entry['description']}",
        f"placeholders: {', '.join(entry['placeholders'])}",
        "template:",
        template,
    ]
    return "\n".join(lines)


def _run_list(args: argparse.Namespace) -> int:
    workspace = getattr(args, "dir", None) or "."
    print(_list_table(workspace))
    return 0


def _run_show(args: argparse.Namespace) -> int:
    name = getattr(args, "name", None)
    if not name:
        print("prompts: show requires a prompt name")
        return 1
    if name not in PROMPTS:
        print(f"prompts: unknown prompt {name!r}")
        return 1
    workspace = getattr(args, "dir", None) or "."
    print(_show_text(name, workspace))
    return 0


def _run_export(args: argparse.Namespace) -> int:
    out_path = Path(getattr(args, "out", None) or "gtmos-prompts.json")
    skeleton = {name: {"template": entry["template"]} for name, entry in PROMPTS.items()}
    try:
        out_path.write_text(json.dumps(skeleton, indent=2) + "\n", encoding="utf-8")
    except OSError as exc:
        print(f"prompts: cannot write {out_path}: {exc}")
        return 1
    print(f"prompts: exported {len(skeleton)} template(s) to {out_path}")
    return 0


def run(args: argparse.Namespace) -> int:
    action = getattr(args, "prompts_action", None)

    if action == "list":
        return _run_list(args)
    if action == "show":
        return _run_show(args)
    if action == "export":
        return _run_export(args)

    print(f"prompts: unknown action {action!r} (expected list, show, or export)")
    return 2
