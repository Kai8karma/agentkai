"""Build `gtmos today` — one action checklist assembled from whatever
sources exist on disk. Deterministic, no LLM, no network.

Sources are all optional and read defensively, exactly like
gtmos.weekly.assemble: a missing/unreadable source is noted in "gaps" and
never crashes the build. Role sections are fixed (revops/sdr/marketing/
founder) since that's the shape `gtmos init` always scaffolds; if a team
config narrows the valid role names, unknown-role validation uses those.
"""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from gtmos.plays import state as play_state
from gtmos.team.config import config_get, load_config

DEFAULT_AUDIT_PATH = "audit-out/scores.json"
DEFAULT_FUNNEL_PATH = "funnel-out/funnel.json"
DEFAULT_PLAY_DIR = "play-out"
DEFAULT_RECEIPTS_PATH = Path.home() / ".gtmos" / "receipts.jsonl"

SECTION_NAMES = ("revops", "sdr", "marketing", "founder")
STALLED_DEAL_LIMIT = 5
COPY_SNIPPET_LIMIT = 80
ACTION_TYPES = ("stalled_deal", "touch", "play_unstarted")


def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _resolve_today(today: str | None) -> str:
    return today or date.today().isoformat()


def _days_overdue(touch_date: str, today: str) -> int:
    return (date.fromisoformat(today) - date.fromisoformat(touch_date)).days


def _audit_section(path: Path, gaps: list[str]) -> dict | None:
    data = _load_json(path)
    if data is None:
        gaps.append(f"audit: no data at {path} — run `gtmos audit`")
        return None
    return {"portal_score": data.get("portal_score"), "grade": data.get("grade")}


def _funnel_section(path: Path, gaps: list[str]) -> dict | None:
    data = _load_json(path)
    if data is None:
        gaps.append(f"funnel: no data at {path} — run `gtmos funnel`")
        return None
    stalled = sorted(
        data.get("stalled_deals") or [], key=lambda d: d.get("amount") or 0, reverse=True
    )
    return {"leak_total": data.get("leak_total"), "stalled_deals": stalled[:STALLED_DEAL_LIMIT]}


def _plays_data(play_dir: Path, today: str, gaps: list[str]) -> list[dict]:
    """Every <play>-plan.json in play_dir, cross-referenced with its
    sibling <play>-state.json (missing state = untouched plan)."""
    plan_paths = sorted(play_dir.glob("*-plan.json")) if play_dir.exists() else []
    if not plan_paths:
        gaps.append(f"plays: no plans found at {play_dir} — run `gtmos play run <name> --targets FILE`")
        return []

    plays_out = []
    for plan_path in plan_paths:
        play_name = plan_path.name[: -len("-plan.json")]
        plan = _load_json(plan_path)
        if plan is None:
            gaps.append(f"plays: unreadable plan {plan_path}")
            continue
        state = play_state.load_state(play_dir, play_name)
        due = play_state.due_touches(plan, state, today)
        target_companies = [t["target"].get("company") for t in plan.get("targets", [])]
        touched_companies = set(state.get("targets", {}).keys())
        unstarted = [c for c in target_companies if c and c not in touched_companies]
        plays_out.append({"play": play_name, "due": due, "unstarted_targets": unstarted})
    return plays_out


def _activity_section(receipts_path: Path, today: str, gaps: list[str]) -> dict:
    if not receipts_path.exists():
        gaps.append(f"activity: no receipts at {receipts_path} yet")
        return {"commands_yesterday": 0}

    today_date = date.fromisoformat(today)
    today_start = datetime(today_date.year, today_date.month, today_date.day, tzinfo=timezone.utc)
    yesterday_start = today_start - timedelta(days=1)

    total = 0
    for line in receipts_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        ts = record.get("ts")
        if not isinstance(ts, (int, float)):
            continue
        ts_dt = datetime.fromtimestamp(ts, tz=timezone.utc)
        if yesterday_start <= ts_dt < today_start:
            total += 1
    return {"commands_yesterday": total}


def _revops_section(audit: dict | None, funnel: dict | None) -> list[dict]:
    items = []
    if audit and audit.get("portal_score") is not None:
        items.append(
            {
                "type": "audit",
                "line": f"AUDIT portal score {audit['portal_score']:.1f} ({audit.get('grade') or '?'})",
            }
        )
    else:
        items.append({"type": "audit", "line": "AUDIT no score available"})

    if funnel:
        for sd in funnel["stalled_deals"]:
            amount = sd.get("amount") or 0
            owner = sd.get("owner") or "unassigned"
            name = sd.get("dealname") or sd.get("id") or "(unnamed)"
            days_stale = sd.get("days_stale")
            stale_str = f"{days_stale:.0f}d stale" if days_stale is not None else "stale"
            items.append(
                {
                    "type": "stalled_deal",
                    "amount": amount,
                    "overdue": False,
                    "line": f"CHASE {name} — ${amount:,.0f} ({stale_str}, owner {owner})",
                }
            )
    return items


def _sdr_section(plays_data: list[dict], today: str) -> list[dict]:
    items = []
    for p in plays_data:
        for touch in p["due"]:
            snippet = touch["copy"][:COPY_SNIPPET_LIMIT]
            if touch["overdue"]:
                status = f"overdue {_days_overdue(touch['date'], today)}d"
            else:
                status = "due today"
            items.append(
                {
                    "type": "touch",
                    "play": p["play"],
                    "company": touch["company"],
                    "step": touch["step"],
                    "channel": touch["channel"],
                    "date": touch["date"],
                    "overdue": touch["overdue"],
                    "line": f"TOUCH {touch['company']} step {touch['step']} ({touch['channel']}) — {status} — {snippet}",
                }
            )
    items.sort(key=lambda it: (not it["overdue"], it["date"]))
    return items


def _marketing_section(plays_data: list[dict]) -> list[dict]:
    items = []
    for p in plays_data:
        if p["unstarted_targets"]:
            items.append(
                {
                    "type": "play_unstarted",
                    "play": p["play"],
                    "overdue": False,
                    "line": (
                        f"LAUNCH {p['play']} — {len(p['unstarted_targets'])} unstarted "
                        f"target(s): {', '.join(p['unstarted_targets'])}"
                    ),
                }
            )
    return items


def _founder_section(funnel: dict | None, activity: dict, gaps: list[str]) -> list[dict]:
    items = []
    if funnel and funnel.get("leak_total") is not None:
        items.append({"type": "leak", "line": f"LEAK ${funnel['leak_total']:,.0f} total funnel leak"})
    else:
        items.append({"type": "leak", "line": "LEAK no funnel data available"})
    items.append({"type": "activity", "line": f"PULSE {activity['commands_yesterday']} command(s) run yesterday"})
    for gap in gaps:
        items.append({"type": "gap", "line": f"GAP {gap}"})
    return items


def build_today(
    workspace: str = ".",
    role: str | None = None,
    today: str | None = None,
    paths_override: dict | None = None,
) -> dict:
    """Assemble the daily checklist. Returns
    {"today", "generated_at", "role", "sections", "gaps", "summary"}.

    Raises ValueError if `role` doesn't match a known role (caller should
    catch this and exit 2, listing the known roles from the message).
    """
    paths_override = paths_override or {}
    today = _resolve_today(today)
    ws = Path(workspace)
    gaps: list[str] = []

    audit_path = Path(paths_override.get("audit_path", ws / DEFAULT_AUDIT_PATH))
    funnel_path = Path(paths_override.get("funnel_path", ws / DEFAULT_FUNNEL_PATH))
    play_dir = Path(paths_override.get("play_dir", ws / DEFAULT_PLAY_DIR))
    receipts_path = Path(paths_override.get("receipts_path", DEFAULT_RECEIPTS_PATH))

    cfg = load_config(str(ws))
    if cfg:
        config_roles = list(config_get(cfg, "team.roles", {}) or {})
        known_roles = [r for r in config_roles if r in SECTION_NAMES] or list(SECTION_NAMES)
    else:
        known_roles = list(SECTION_NAMES)

    audit = _audit_section(audit_path, gaps)
    funnel = _funnel_section(funnel_path, gaps)
    plays_data = _plays_data(play_dir, today, gaps)
    activity = _activity_section(receipts_path, today, gaps)

    all_sections = {
        "revops": _revops_section(audit, funnel),
        "sdr": _sdr_section(plays_data, today),
        "marketing": _marketing_section(plays_data),
        "founder": _founder_section(funnel, activity, gaps),
    }

    if role is not None:
        matched = next((r for r in known_roles if r.lower() == role.lower()), None)
        if matched is None:
            raise ValueError(f"unknown role '{role}' — known roles: {', '.join(known_roles)}")
        sections = {matched: all_sections.get(matched, [])}
    else:
        sections = all_sections

    actions = [item for items in sections.values() for item in items if item["type"] in ACTION_TYPES]
    overdue_count = sum(1 for item in actions if item.get("overdue"))
    biggest_leak = funnel["leak_total"] if funnel and funnel.get("leak_total") is not None else 0.0

    return {
        "today": today,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "role": role,
        "sections": sections,
        "gaps": gaps,
        "summary": {
            "actions": len(actions),
            "overdue": overdue_count,
            "biggest_leak": biggest_leak,
        },
    }
