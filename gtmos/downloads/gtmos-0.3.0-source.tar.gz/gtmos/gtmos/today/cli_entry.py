"""`gtmos today` handler — the daily loop checklist.

Expected argparse.Namespace shape (wired by the integrator):
  role: str|None    (--role, filters output to one section)
  dir: str|None     (--dir, workspace root to search from, default ".")
  out: str|None     (--out, default "./today-out")
  today: str|None   (--today "YYYY-MM-DD", default today)
  dry_run: bool     (--dry-run, default False)

Exit codes: 0 success (including partial/missing sources — those become
"gaps"), 2 unknown role.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from gtmos.today import engine

DEFAULT_OUT = "./today-out"


def _render_markdown(result: dict) -> str:
    summary = result["summary"]
    lines = [f"# Today — {result['today']}", ""]
    lines.append(
        f"_{summary['actions']} action(s), {summary['overdue']} overdue — "
        f"biggest leak ${summary['biggest_leak']:,.0f}_"
    )
    lines.append("")

    for section_name, items in result["sections"].items():
        lines.append(f"## {section_name}")
        lines.append("")
        if not items:
            lines.append("Nothing here.")
        else:
            for item in items:
                lines.append(f"- {item['line']}")
        lines.append("")

    if result["gaps"]:
        lines.append("## Gaps")
        lines.append("")
        for gap in result["gaps"]:
            lines.append(f"- {gap}")
        lines.append("")

    return "\n".join(lines)


def run(args: argparse.Namespace) -> int:
    workspace = getattr(args, "dir", None) or "."
    role = getattr(args, "role", None)
    today = getattr(args, "today", None)
    out_dir = getattr(args, "out", None) or DEFAULT_OUT

    if getattr(args, "dry_run", False):
        print(
            "[dry-run] would read team config, audit-out/scores.json, funnel-out/funnel.json, "
            f"play-out/*-plan.json + *-state.json, ~/.gtmos/receipts.jsonl and write {out_dir}"
        )
        return 0

    try:
        result = engine.build_today(workspace=workspace, role=role, today=today)
    except ValueError as exc:
        print(f"today: {exc}")
        return 2

    summary = result["summary"]
    print(
        f"today: {summary['actions']} actions ({summary['overdue']} overdue) — "
        f"biggest leak ${summary['biggest_leak']:,.0f}"
    )
    print()

    show_headers = role is None
    for section_name, items in result["sections"].items():
        if show_headers:
            print(f"[{section_name}]")
        for item in items:
            print(item["line"])
        if show_headers:
            print()

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    (out_path / "today.md").write_text(_render_markdown(result), encoding="utf-8")
    (out_path / "today.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    return 0
