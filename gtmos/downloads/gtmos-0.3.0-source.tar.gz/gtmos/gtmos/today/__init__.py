"""`gtmos today` — the daily loop. Assembles audit/funnel/play-state/receipts
into one role-aware action checklist. See gtmos.today.engine for the build
logic and gtmos.today.cli_entry for the CLI handler."""
