"""`gtmos doctor` — enterprise preflight check.

Verifies the environment a `gtmos quickstart` (or any command) is about to
run in: Python version, claude CLI presence, HubSpot token, workspace
config, ~/.gtmos permissions/receipts, and cwd writability. Every check is
defensive and takes injectable env/paths so tests never touch the real
PATH, environment, or home directory.

Exit code: 0 if no check is a hard [fail], 1 otherwise. [warn] never fails
the run — those are "degraded but usable" states (e.g. offline mode).
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import stat
import sys
from dataclasses import dataclass
from pathlib import Path

from gtmos.team.config import find_config_path

MIN_PYTHON = (3, 11)
GTMOS_HOME_MODE = 0o700


@dataclass
class CheckResult:
    name: str
    status: str  # "ok" | "warn" | "fail"
    detail: str


def _mask_token(token: str) -> str:
    """First 6 chars + an ellipsis — never the full token."""
    return token[:6] + "…"


def check_python_version(version_info=None) -> CheckResult:
    version_info = version_info or sys.version_info
    ok = (version_info.major, version_info.minor) >= MIN_PYTHON
    detail = f"{version_info.major}.{version_info.minor}.{version_info.micro}"
    return CheckResult("python-version", "ok" if ok else "fail", detail)


def check_claude_cli(which=shutil.which) -> CheckResult:
    path = which("claude")
    if path:
        return CheckResult("claude-cli", "ok", path)
    return CheckResult(
        "claude-cli", "warn",
        "not on PATH — harness (claude-backed) commands degrade; deterministic commands are unaffected",
    )


def check_hubspot_token(env=None) -> CheckResult:
    env = env if env is not None else os.environ
    token = env.get("GTMOS_HUBSPOT_TOKEN")
    if not token:
        return CheckResult("hubspot-token", "warn", "GTMOS_HUBSPOT_TOKEN not set — offline mode (--input/--contacts) still works")
    return CheckResult("hubspot-token", "ok", _mask_token(token))


def check_workspace(start_dir: str = ".") -> CheckResult:
    path = find_config_path(start_dir)
    if path is None:
        return CheckResult("workspace", "warn", "no gtmos-team.json found — run `gtmos init`")
    return CheckResult("workspace", "ok", str(path))


def check_gtmos_home(home: Path | None = None) -> CheckResult:
    gtmos_home = home if home is not None else Path.home() / ".gtmos"
    if not gtmos_home.exists():
        return CheckResult("gtmos-home", "warn", f"{gtmos_home} does not exist yet — created on first harness/quickstart run")

    mode = stat.S_IMODE(gtmos_home.stat().st_mode)
    action = ""
    if mode & 0o077:
        try:
            gtmos_home.chmod(GTMOS_HOME_MODE)
            action = f" (was {oct(mode)}, chmod'd to {oct(GTMOS_HOME_MODE)})"
        except OSError as exc:
            action = f" (was {oct(mode)}, could not tighten permissions: {exc})"

    receipts_path = gtmos_home / "receipts.jsonl"
    line_count = 0
    if receipts_path.exists():
        line_count = sum(1 for line in receipts_path.read_text(encoding="utf-8").splitlines() if line.strip())

    return CheckResult("gtmos-home", "ok", f"{gtmos_home}{action}; {line_count} receipt(s)")


def check_writable_cwd(cwd: str = ".") -> CheckResult:
    path = Path(cwd)
    if os.access(path, os.W_OK):
        return CheckResult("writable-cwd", "ok", str(path.resolve()))
    return CheckResult("writable-cwd", "fail", f"{path.resolve()} is not writable")


def run_checks(
    start_dir: str = ".",
    env=None,
    home: Path | None = None,
    which=None,
) -> list[CheckResult]:
    which = which or shutil.which
    return [
        check_python_version(),
        check_claude_cli(which=which),
        check_hubspot_token(env=env),
        check_workspace(start_dir),
        check_gtmos_home(home),
        check_writable_cwd(start_dir),
    ]


def run(args: argparse.Namespace) -> int:
    start_dir = getattr(args, "dir", None) or "."
    env = getattr(args, "env", None)
    home = getattr(args, "home", None)
    which = getattr(args, "which", None)

    results = run_checks(start_dir=start_dir, env=env, home=home, which=which)

    if getattr(args, "json", False):
        payload = [{"name": r.name, "status": r.status, "detail": r.detail} for r in results]
        print(json.dumps(payload, indent=2))
    else:
        print("gtmos doctor — preflight")
        for r in results:
            print(f"[{r.status}] {r.name}: {r.detail}")

    return 1 if any(r.status == "fail" for r in results) else 0
