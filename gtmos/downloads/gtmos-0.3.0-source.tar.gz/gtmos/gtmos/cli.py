"""GTM OS command-line entrypoint. Argparse only, stdlib.

Each subcommand's implementation module is imported lazily inside its
handler function, so `gtmos --help` / `gtmos <cmd> --help` work even
before that module exists.
"""

from __future__ import annotations

import argparse

from gtmos import __version__


def _cmd_audit(args: argparse.Namespace) -> int:
    from gtmos.audit.cli_entry import run

    return run(args)


def _cmd_prospect(args: argparse.Namespace) -> int:
    from gtmos.commands.prospect import run

    return run(args)


def _cmd_stalk(args: argparse.Namespace) -> int:
    from gtmos.commands.stalk import run

    return run(args)


def _cmd_draft(args: argparse.Namespace) -> int:
    from gtmos.commands.draft import run

    return run(args)


def _cmd_brief(args: argparse.Namespace) -> int:
    from gtmos.commands.brief import run

    return run(args)


def _cmd_outcomes(args: argparse.Namespace) -> int:
    from gtmos.commands.outcomes import run

    return run(args)


def _cmd_abm(args: argparse.Namespace) -> int:
    from gtmos.abm.cli_entry import run

    return run(args)


def _cmd_funnel(args: argparse.Namespace) -> int:
    from gtmos.funnel.cli_entry import run

    return run(args)


def _cmd_team(args: argparse.Namespace) -> int:
    from gtmos.team.cli_entry import run

    return run(args)


def _cmd_play(args: argparse.Namespace) -> int:
    from gtmos.plays.cli_entry import run

    return run(args)


def _cmd_eval(args: argparse.Namespace) -> int:
    from gtmos.evals.cli_entry import run

    return run(args)


def _cmd_weekly(args: argparse.Namespace) -> int:
    from gtmos.weekly.cli_entry import run

    return run(args)


def _cmd_today(args: argparse.Namespace) -> int:
    from gtmos.today.cli_entry import run

    return run(args)


def _cmd_prompts(args: argparse.Namespace) -> int:
    from gtmos.prompts_cli import run

    return run(args)


def _cmd_serve(args: argparse.Namespace) -> int:
    from gtmos.serve.cli_entry import run

    return run(args)


def _cmd_doctor(args: argparse.Namespace) -> int:
    from gtmos.doctor import run

    return run(args)


def _cmd_quickstart(args: argparse.Namespace) -> int:
    from gtmos.quickstart import run

    return run(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gtmos", description="GTM OS — self-hosted GTM operating system")
    parser.add_argument("--version", action="version", version=f"gtmos {__version__}")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="print the resolved plan for the subcommand and execute nothing",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Every subparser also accepts --dry-run so it works in the natural
    # `gtmos <cmd> --dry-run ...` position, not just before the subcommand.
    # default=SUPPRESS means "not given here" leaves the top-level parser's
    # value (set below) untouched instead of clobbering it with False.
    dry_run_kwargs = dict(action="store_true", default=argparse.SUPPRESS, help=argparse.SUPPRESS)

    audit_p = subparsers.add_parser("audit", help="audit HubSpot contacts for GTM leaks")
    audit_p.add_argument("--input", metavar="FILE", help="offline contacts JSON (fallback to --portal)")
    audit_p.add_argument("--acv", type=float, help="average contract value, for $-leak estimate")
    audit_p.add_argument("--portal", action="store_true", help="fetch live from HubSpot API")
    audit_p.add_argument("--out", default="./audit-out", help="output directory (default ./audit-out)")
    audit_p.add_argument("--dry-run", **dry_run_kwargs)
    audit_p.set_defaults(func=_cmd_audit)

    prospect_p = subparsers.add_parser("prospect", help="generate a prospect list against an ICP")
    prospect_p.add_argument("icp", help="ICP description string")
    prospect_p.add_argument("--count", type=int, default=75, help="number of prospects (default 75)")
    prospect_p.add_argument("--input", metavar="FILE", help="offline pre-fetched candidate leads JSON")
    prospect_p.add_argument("--dry-run", **dry_run_kwargs)
    prospect_p.set_defaults(func=_cmd_prospect)

    stalk_p = subparsers.add_parser("stalk", help="research a founder for outreach personalization")
    stalk_p.add_argument("name", help="founder name")
    stalk_p.add_argument("--company", help="founder's company")
    stalk_p.add_argument("--input", metavar="FILE", help="offline pre-fetched CRM context JSON")
    stalk_p.add_argument("--dry-run", **dry_run_kwargs)
    stalk_p.set_defaults(func=_cmd_stalk)

    draft_p = subparsers.add_parser("draft", help="draft content")
    draft_p.add_argument("--type", choices=["linkedin", "x", "outreach"], required=True, help="content type")
    draft_p.add_argument("topic", help="topic to draft about")
    draft_p.add_argument("--dry-run", **dry_run_kwargs)
    draft_p.set_defaults(func=_cmd_draft)

    brief_p = subparsers.add_parser("brief", help="generate the daily GTM brief")
    brief_p.add_argument("--input", metavar="FILE", help="offline pipeline state JSON")
    brief_p.add_argument("--dry-run", **dry_run_kwargs)
    brief_p.set_defaults(func=_cmd_brief)

    outcomes_p = subparsers.add_parser("outcomes", help="log or report outcomes")
    outcomes_p.add_argument("--log", metavar='"mem_id verdict note"', help="log an outcome")
    outcomes_p.add_argument("--roi", action="store_true", help="print ROI report")
    outcomes_p.set_defaults(func=_cmd_outcomes)

    abm_p = subparsers.add_parser("abm", help="build 1:1 ABM ad-set plans, pages, and creative")
    abm_p.add_argument("--accounts", required=True, metavar="FILE", help="accounts JSON file")
    abm_p.add_argument("--out", default="./abm-out", help="output directory (default ./abm-out)")
    abm_p.add_argument(
        "--push",
        action="store_true",
        help="push the plan to LinkedIn (requires LINKEDIN_ACCESS_TOKEN + typed approval)",
    )
    abm_p.add_argument("--dry-run", **dry_run_kwargs)
    abm_p.set_defaults(func=_cmd_abm)

    funnel_p = subparsers.add_parser("funnel", help="deal-stage revenue-leak analysis")
    funnel_p.add_argument("--input", metavar="FILE", help="offline deals JSON (fallback to --portal)")
    funnel_p.add_argument("--portal", action="store_true", help="fetch live deals from HubSpot API")
    funnel_p.add_argument("--acv", type=float, help="average contract value, for imputation when amounts missing")
    funnel_p.add_argument("--stall-days", dest="stall_days", type=int, help="days without touch before a deal counts as stalled")
    funnel_p.add_argument("--out", default="./funnel-out", help="output directory (default ./funnel-out)")
    funnel_p.add_argument("--dry-run", **dry_run_kwargs)
    funnel_p.set_defaults(func=_cmd_funnel)

    init_p = subparsers.add_parser("init", help="scaffold a GTM OS team workspace (doctrine, plan, plays, config)")
    init_p.add_argument("--dir", default=".", help="target directory (default .)")
    init_p.add_argument("--name", help="team name (default: directory name)")
    init_p.add_argument("--force", action="store_true", help="overwrite existing scaffold files")
    init_p.add_argument("--dry-run", **dry_run_kwargs)
    init_p.set_defaults(func=_cmd_team, team_cmd="init")

    team_p = subparsers.add_parser("team", help="show or edit the team config (gtmos-team.json)")
    team_p.add_argument("--dir", default=".", help="directory to search for gtmos-team.json (default .)")
    team_p.add_argument("--show", action="store_true", help="print role→command map, icp, acv (default)")
    team_p.add_argument("--get", metavar="PATH", help="print one config value, e.g. team.acv")
    team_p.add_argument("--set", metavar="PATH=VALUE", help="set one config value, e.g. team.acv=9000")
    team_p.add_argument("--dry-run", **dry_run_kwargs)
    team_p.set_defaults(func=_cmd_team, team_cmd="team")

    play_p = subparsers.add_parser("play", help="signal plays: list, show, or run a multi-touch sequence")
    play_sub = play_p.add_subparsers(dest="action", required=True)

    play_list_p = play_sub.add_parser("list", help="list built-in signal plays")
    play_list_p.add_argument("--dry-run", **dry_run_kwargs)

    play_show_p = play_sub.add_parser("show", help="show one play's full sequence")
    play_show_p.add_argument("name", help="play name")
    play_show_p.add_argument("--dry-run", **dry_run_kwargs)

    play_run_p = play_sub.add_parser("run", help="build a per-target touch plan for a play")
    play_run_p.add_argument("name", help="play name")
    play_run_p.add_argument("--targets", required=True, metavar="FILE", help="targets JSON array")
    play_run_p.add_argument("--out", default="./play-out", help="output directory (default ./play-out)")
    play_run_p.add_argument("--start-date", dest="start_date", help="sequence start date YYYY-MM-DD (default today)")
    play_run_p.add_argument("--draft", action="store_true", help="upgrade template copy via the claude harness (first 10 targets)")
    play_run_p.add_argument("--dry-run", **dry_run_kwargs)

    play_touch_p = play_sub.add_parser("touch", help="log a completed touch for a target")
    play_touch_p.add_argument("name", help="play name")
    play_touch_p.add_argument("--target", required=True, metavar="COMPANY", help="target company (as in the plan)")
    play_touch_p.add_argument("--step", required=True, type=int, help="step number completed")
    play_touch_p.add_argument("--out", default="./play-out", help="plan/state directory (default ./play-out)")
    play_touch_p.add_argument("--dry-run", **dry_run_kwargs)

    play_status_p = play_sub.add_parser("status", help="show per-target sequence progress")
    play_status_p.add_argument("name", help="play name")
    play_status_p.add_argument("--out", default="./play-out", help="plan/state directory (default ./play-out)")
    play_status_p.add_argument("--today", metavar="YYYY-MM-DD", help="override today's date (for due/overdue calc)")
    play_status_p.add_argument("--dry-run", **dry_run_kwargs)

    play_p.set_defaults(func=_cmd_play)

    eval_p = subparsers.add_parser("eval", help="run the eval harness (regression, determinism, contract checks)")
    eval_p.add_argument("--judge", action="store_true", help="also run the LLM judge check on the latest audit report")
    eval_p.add_argument("--out", default="./eval-out", help="output directory (default ./eval-out)")
    eval_p.add_argument("--dry-run", **dry_run_kwargs)
    eval_p.set_defaults(func=_cmd_eval)

    weekly_p = subparsers.add_parser("weekly", help="assemble the weekly GTM ops review from audit/funnel/receipts")
    weekly_p.add_argument("--out", default="./weekly-out", help="output directory (default ./weekly-out)")
    weekly_p.add_argument("--dry-run", **dry_run_kwargs)
    weekly_p.set_defaults(func=_cmd_weekly)

    today_p = subparsers.add_parser("today", help="role-aware daily checklist — the morning loop")
    today_p.add_argument("--role", help="filter to one role (from gtmos-team.json)")
    today_p.add_argument("--dir", default=".", help="workspace directory (default .)")
    today_p.add_argument("--out", default="./today-out", help="output directory (default ./today-out)")
    today_p.add_argument("--today", metavar="YYYY-MM-DD", help="override today's date")
    today_p.add_argument("--dry-run", **dry_run_kwargs)
    today_p.set_defaults(func=_cmd_today)

    prompts_p = subparsers.add_parser("prompts", help="list, show, or export the harness prompt pack")
    prompts_sub = prompts_p.add_subparsers(dest="prompts_action", required=True)

    prompts_list_p = prompts_sub.add_parser("list", help="list prompts and override status")
    prompts_list_p.add_argument("--dry-run", **dry_run_kwargs)

    prompts_show_p = prompts_sub.add_parser("show", help="print one prompt's effective template")
    prompts_show_p.add_argument("name", help="prompt name")
    prompts_show_p.add_argument("--dry-run", **dry_run_kwargs)

    prompts_export_p = prompts_sub.add_parser("export", help="write builtin templates to an override skeleton")
    prompts_export_p.add_argument("--out", default="gtmos-prompts.json", help="output file (default gtmos-prompts.json)")
    prompts_export_p.add_argument("--dry-run", **dry_run_kwargs)

    prompts_p.set_defaults(func=_cmd_prompts)

    serve_p = subparsers.add_parser("serve", help="local web dashboard (zero-egress, reads CLI artifacts)")
    serve_p.add_argument("--host", default="127.0.0.1", help="bind address (default 127.0.0.1)")
    serve_p.add_argument("--port", type=int, default=8390, help="port (default 8390)")
    serve_p.add_argument("--dir", default=".", help="workspace directory (default .)")
    serve_p.add_argument("--lan", action="store_true", help="allow binding 0.0.0.0 (dashboard visible to local network)")
    serve_p.add_argument("--dry-run", **dry_run_kwargs)
    serve_p.set_defaults(func=_cmd_serve)

    doctor_p = subparsers.add_parser("doctor", help="preflight checks: python, claude CLI, token (masked), workspace, perms")
    doctor_p.add_argument("--dir", default=".", help="workspace directory (default .)")
    doctor_p.add_argument("--json", action="store_true", help="machine-readable output")
    doctor_p.add_argument("--dry-run", **dry_run_kwargs)
    doctor_p.set_defaults(func=_cmd_doctor)

    quickstart_p = subparsers.add_parser(
        "quickstart", help="plug into your CRM: doctor → init → audit → funnel → today, one command"
    )
    quickstart_p.add_argument("--contacts", metavar="FILE", help="offline contacts JSON (else live via GTMOS_HUBSPOT_TOKEN)")
    quickstart_p.add_argument("--deals", metavar="FILE", help="offline deals JSON (else live via GTMOS_HUBSPOT_TOKEN)")
    quickstart_p.add_argument("--acv", type=float, help="average contract value for $-leak estimates")
    quickstart_p.add_argument("--dir", default=".", help="workspace directory (default .)")
    quickstart_p.add_argument("--out-root", dest="out_root", default=".", help="root for audit-out/funnel-out/today-out (default .)")
    quickstart_p.add_argument("--dry-run", **dry_run_kwargs)
    quickstart_p.set_defaults(func=_cmd_quickstart)

    return parser


def _log_crash(command: str) -> str:
    """Write the full traceback to ~/.gtmos/errors.log; return the path."""
    import time
    import traceback
    from pathlib import Path

    log_path = Path.home() / ".gtmos" / "errors.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a") as f:
        f.write(f"\n--- {time.strftime('%Y-%m-%dT%H:%M:%S%z')} gtmos {command} ---\n")
        f.write(traceback.format_exc())
    return str(log_path)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.dry_run:
        plan = {k: v for k, v in vars(args).items() if k not in ("func", "dry_run")}
        print(f"[dry-run] gtmos {args.command}: {plan}")
        return 0

    # Fail-proof contract: a subcommand bug never dumps a traceback on an
    # operator. One clean line, full trace in the local error log, exit 1.
    try:
        return args.func(args) or 0
    except KeyboardInterrupt:
        print(f"\n{args.command}: interrupted")
        return 130
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 — the whole point is catching everything
        log_path = _log_crash(args.command)
        print(f"{args.command}: unexpected error: {exc} — full trace: {log_path}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
