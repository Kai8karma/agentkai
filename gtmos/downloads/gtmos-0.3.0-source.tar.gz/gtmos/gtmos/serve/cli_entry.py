"""`gtmos serve` handler — local web dashboard (Layer-2 surface).

Expected argparse.Namespace shape (wired by the integrator):
  host: str|None    (--host, default "127.0.0.1")
  port: int|None    (--port, default 8390)
  dir: str|None     (--dir, workspace root to read from, default ".")
  lan: bool         (--lan, default False — required to bind 0.0.0.0)
  dry_run: bool     (--dry-run, default False)

SECURITY: v1 has no auth (read-only dashboard), so binding beyond
loopback should be an explicit, visible choice — refuse --host 0.0.0.0
unless --lan is also passed, and warn plainly when it is.

Exit codes: 0 clean shutdown (Ctrl-C) or dry-run, 2 refused bind.
"""

from __future__ import annotations

import argparse

from gtmos.serve.server import ROUTES, build_server

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8390


def run(args: argparse.Namespace) -> int:
    host = getattr(args, "host", None) or DEFAULT_HOST
    port = getattr(args, "port", None)
    port = DEFAULT_PORT if port is None else port
    workspace = getattr(args, "dir", None) or "."
    lan = bool(getattr(args, "lan", False))

    if host == "0.0.0.0" and not lan:
        print("serve: refusing to bind 0.0.0.0 without --lan (dashboard would be visible to the local network)")
        return 2

    if getattr(args, "dry_run", False):
        print(f"[dry-run] gtmos serve would bind {host}:{port} (workspace: {workspace})")
        for method, path, desc in ROUTES:
            print(f"  {method:4} {path:16} {desc}")
        return 0

    if host == "0.0.0.0":
        print("serve: WARNING — binding 0.0.0.0, dashboard is visible to the local network (no auth, read-only)")

    server = build_server(host, port, workspace)
    print(f"serve: http://{host}:{port} (workspace: {workspace}) — Ctrl-C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0
