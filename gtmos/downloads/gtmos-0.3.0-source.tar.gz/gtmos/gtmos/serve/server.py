"""HTTP server for `gtmos serve` — the local dashboard (Layer-2 surface).

Zero-egress: no external assets, no CDN, no telemetry. Files are the
API — every route re-reads workspace files fresh, no caching, since the
CLI writes and this only reads. /api/refresh does nothing but confirm
that (it re-runs no external call, just acknowledges a re-read on the
next GET).

The workspace directory is carried on the server instance (a plain
attribute set in WorkspaceHTTPServer.__init__), never a module global,
so multiple servers in the same process (e.g. tests) stay isolated.
"""

from __future__ import annotations

import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from gtmos.serve import views

ROUTES = [
    ("GET", "/", "dashboard: leak headline, audit score, role action counts + links"),
    ("GET", "/role/<name>", "that role's checklist (today engine, falls back to today.json)"),
    ("GET", "/funnel", "funnel stage table + stalled deals + leak breakdown"),
    ("GET", "/weekly", "weekly-review.md rendered as <pre>"),
    ("GET", "/plays", "per-target play progress bars"),
    ("POST", "/api/refresh", "no-op — files are the API; re-reads happen on the next GET"),
]


class WorkspaceHTTPServer(ThreadingHTTPServer):
    def __init__(self, server_address, RequestHandlerClass, workspace: str):
        super().__init__(server_address, RequestHandlerClass)
        self.workspace_dir = Path(workspace)


class Handler(BaseHTTPRequestHandler):
    server_version = "gtmos-serve/0.1"

    def log_message(self, format, *args):  # noqa: A002 - stdlib signature
        pass  # quiet: no request logging/telemetry

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, status: int, body: str) -> None:
        self._send(status, body.encode("utf-8"), "text/html; charset=utf-8")

    def _send_json(self, status: int, payload: dict) -> None:
        self._send(status, json.dumps(payload).encode("utf-8"), "application/json")

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        ws = self.server.workspace_dir

        if path == "/":
            status, body = views.dashboard_page(ws)
            self._send_html(status, body)
            return
        if path.startswith("/role/") and len(path) > len("/role/"):
            role = path[len("/role/"):]
            status, body = views.role_page(ws, role)
            self._send_html(status, body)
            return
        if path == "/funnel":
            status, body = views.funnel_page(ws)
            self._send_html(status, body)
            return
        if path == "/weekly":
            status, body = views.weekly_page(ws)
            self._send_html(status, body)
            return
        if path == "/plays":
            status, body = views.plays_page(ws)
            self._send_html(status, body)
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found", "path": path})

    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        if path == "/api/refresh":
            self.send_response(HTTPStatus.NO_CONTENT)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found", "path": path})


def build_server(host: str, port: int, workspace: str) -> WorkspaceHTTPServer:
    return WorkspaceHTTPServer((host, port), Handler, workspace)
