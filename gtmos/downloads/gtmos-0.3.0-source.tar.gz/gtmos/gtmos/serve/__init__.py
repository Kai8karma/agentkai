"""`gtmos serve` — local web dashboard (Layer-2 surface). Loopback/LAN
only: no external assets, no CDN, no telemetry. Files are the API."""
