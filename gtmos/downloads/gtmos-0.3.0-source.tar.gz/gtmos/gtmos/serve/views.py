"""HTML rendering for `gtmos serve`. One shared _page() wrapper, inline
CSS only, no JS beyond a 60s meta-refresh on the dashboard. Every value
that could contain operator/CRM-supplied text (company, owner, dealname,
gap text) is html.escape'd before it lands in a response.

Every page-building function returns (status: int, html: str) so the
server layer never has to know why a page is 200 vs 404.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

ACCENT = "#10B981"

_CSS = f"""
body {{ background:#0d1117; color:#c9d1d9; font-family: ui-monospace, Menlo, Consolas, monospace;
        margin:0; padding:24px; }}
a {{ color:{ACCENT}; text-decoration:none; }}
a:hover {{ text-decoration:underline; }}
h1, h2 {{ color:{ACCENT}; }}
table {{ border-collapse:collapse; width:100%; margin-bottom:16px; }}
th, td {{ border:1px solid #30363d; padding:6px 10px; text-align:left; }}
th {{ color:{ACCENT}; }}
.card {{ border:1px solid #30363d; border-radius:6px; padding:16px; margin-bottom:16px; }}
.empty {{ border:1px dashed #30363d; border-radius:6px; padding:16px; color:#8b949e; }}
.nav {{ margin-bottom:16px; }}
.nav a {{ margin-right:12px; }}
.bar-track {{ display:inline-block; width:160px; height:10px; background:#30363d; vertical-align:middle; }}
.bar {{ display:inline-block; height:10px; background:{ACCENT}; }}
pre {{ white-space:pre-wrap; }}
code {{ color:{ACCENT}; }}
"""

_NAV = (
    '<div class="nav"><a href="/">dashboard</a><a href="/funnel">funnel</a>'
    '<a href="/weekly">weekly</a><a href="/plays">plays</a></div>'
)


def _page(title: str, body: str, refresh: bool = False) -> str:
    refresh_tag = '<meta http-equiv="refresh" content="60">' if refresh else ""
    return (
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"{refresh_tag}<title>gtmos — {html.escape(title)}</title>"
        f"<style>{_CSS}</style></head><body>"
        f"<h1>gtmos — {html.escape(title)}</h1>{_NAV}{body}</body></html>"
    )


def _empty_state(hint_command: str, label: str = "no data") -> str:
    return f'<div class="empty">{html.escape(label)} — run: <code>{html.escape(hint_command)}</code></div>'


def _dollar(value) -> str:
    if value is None:
        return "n/a"
    try:
        return f"${float(value):,.0f}"
    except (TypeError, ValueError):
        return "n/a"


def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


# -- dashboard -------------------------------------------------------------

def dashboard_page(workspace: Path) -> tuple[int, str]:
    funnel = _load_json(workspace / "funnel-out" / "funnel.json")
    scores = _load_json(workspace / "audit-out" / "scores.json")
    today = _load_json(workspace / "today-out" / "today.json")

    parts: list[str] = []

    if funnel is not None and funnel.get("leak_total") is not None:
        parts.append(
            f'<div class="card"><h2>Funnel leak</h2><p>{_dollar(funnel.get("leak_total"))} total leak, '
            f'{funnel.get("stalled_count", 0)} stalled deal(s).</p></div>'
        )
    else:
        parts.append(_empty_state("gtmos funnel --input deals.json", "no funnel data"))

    if scores is not None and scores.get("portal_score") is not None:
        parts.append(
            f'<div class="card"><h2>CRM integrity</h2><p>{scores["portal_score"]:.1f} / 100 '
            f'(grade {html.escape(str(scores.get("grade", "?")))})</p></div>'
        )
    else:
        parts.append(_empty_state("gtmos audit --input contacts.json", "no audit data"))

    role_body = ['<div class="card"><h2>Roles</h2>']
    sections = (today or {}).get("sections") if today else None
    if sections:
        rows = "".join(
            f'<tr><td><a href="/role/{html.escape(str(name))}">{html.escape(str(name))}</a></td>'
            f"<td>{len(items)}</td></tr>"
            for name, items in sections.items()
        )
        role_body.append(f"<table><tr><th>Role</th><th>Actions</th></tr>{rows}</table>")
    else:
        role_body.append(_empty_state("gtmos today", "no today data"))
    role_body.append("</div>")
    parts.append("".join(role_body))

    return 200, _page("dashboard", "".join(parts), refresh=True)


# -- role -------------------------------------------------------------

def _role_body(sections: dict, gaps: list) -> str:
    parts = []
    for name, items in sections.items():
        parts.append(f"<h2>{html.escape(str(name))}</h2>")
        if not items:
            parts.append("<p>Nothing here.</p>")
        else:
            parts.append("<ul>")
            for item in items:
                parts.append(f"<li>{html.escape(str(item.get('line', '')))}</li>")
            parts.append("</ul>")
    if gaps:
        parts.append("<h2>Gaps</h2><ul>")
        for gap in gaps:
            parts.append(f"<li>{html.escape(str(gap))}</li>")
        parts.append("</ul>")
    return "".join(parts)


def role_page(workspace: Path, role: str) -> tuple[int, str]:
    try:
        from gtmos.today.engine import build_today
    except ImportError:
        build_today = None

    if build_today is not None:
        try:
            result = build_today(workspace=str(workspace), role=role)
        except ValueError as exc:
            body = f'<div class="empty">{html.escape(str(exc))}</div>'
            return 404, _page(f"role: {role}", body)
        return 200, _page(f"role: {role}", _role_body(result["sections"], result.get("gaps", [])))

    data = _load_json(workspace / "today-out" / "today.json")
    if data is None:
        return 200, _page(f"role: {role}", _empty_state("gtmos today", "run gtmos today first"))

    sections = data.get("sections", {})
    matched = next((name for name in sections if str(name).lower() == role.lower()), None)
    if matched is None:
        known = ", ".join(sorted(str(n) for n in sections)) or "(none)"
        body = f'<div class="empty">unknown role — known roles: {html.escape(known)}</div>'
        return 404, _page(f"role: {role}", body)

    return 200, _page(f"role: {matched}", _role_body({matched: sections[matched]}, data.get("gaps", [])))


# -- funnel -------------------------------------------------------------

def funnel_page(workspace: Path) -> tuple[int, str]:
    data = _load_json(workspace / "funnel-out" / "funnel.json")
    if data is None:
        return 200, _page("funnel", _empty_state("gtmos funnel --input deals.json", "no funnel data"))

    parts = [f'<div class="card"><h2>You are losing {_dollar(data.get("leak_total"))}</h2></div>']

    stage_counts = data.get("stage_counts") or {}
    stage_amounts = data.get("stage_amounts") or {}
    parts.append("<h2>Stage table</h2><table><tr><th>Stage</th><th>Count</th><th>Amount</th></tr>")
    for stage, count in stage_counts.items():
        parts.append(
            f"<tr><td>{html.escape(str(stage))}</td><td>{count}</td>"
            f"<td>{_dollar(stage_amounts.get(stage))}</td></tr>"
        )
    parts.append("</table>")

    stalled = data.get("stalled_deals") or []
    parts.append("<h2>Stalled deals</h2>")
    if not stalled:
        parts.append("<p>None found.</p>")
    else:
        parts.append("<table><tr><th>Deal</th><th>Stage</th><th>Amount</th><th>Days stale</th><th>Owner</th></tr>")
        for sd in stalled:
            name = sd.get("dealname") or sd.get("id") or "(unnamed)"
            days_stale = sd.get("days_stale")
            days_str = f"{days_stale:.0f}" if isinstance(days_stale, (int, float)) else "n/a"
            parts.append(
                f"<tr><td>{html.escape(str(name))}</td><td>{html.escape(str(sd.get('dealstage', '')))}</td>"
                f"<td>{_dollar(sd.get('amount'))}</td><td>{days_str}</td>"
                f"<td>{html.escape(str(sd.get('owner', '')))}</td></tr>"
            )
        parts.append("</table>")

    leak_by_owner = data.get("leak_by_owner") or {}
    if leak_by_owner:
        parts.append("<h2>Leak by owner</h2><table><tr><th>Owner</th><th>Leak</th></tr>")
        for owner, value in leak_by_owner.items():
            parts.append(f"<tr><td>{html.escape(str(owner))}</td><td>{_dollar(value)}</td></tr>")
        parts.append("</table>")

    return 200, _page("funnel", "".join(parts))


# -- weekly -------------------------------------------------------------

def weekly_page(workspace: Path) -> tuple[int, str]:
    path = workspace / "weekly-out" / "weekly-review.md"
    if not path.exists():
        return 200, _page("weekly", _empty_state("gtmos weekly", "no weekly review"))
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return 200, _page("weekly", _empty_state("gtmos weekly", "no weekly review"))
    return 200, _page("weekly", f"<pre>{html.escape(text)}</pre>")


# -- plays -------------------------------------------------------------

def plays_page(workspace: Path) -> tuple[int, str]:
    play_dir = workspace / "play-out"
    plan_paths = sorted(play_dir.glob("*-plan.json")) if play_dir.exists() else []
    if not plan_paths:
        return 200, _page("plays", _empty_state("gtmos play run <name> --targets FILE", "no play plans"))

    try:
        from gtmos.plays import state as play_state
    except ImportError:
        play_state = None

    parts = []
    for plan_path in plan_paths:
        play_name = plan_path.name[: -len("-plan.json")]
        plan = _load_json(plan_path)
        if plan is None:
            continue

        state = play_state.load_state(play_dir, play_name) if play_state is not None else {"targets": {}}

        parts.append(f"<h2>{html.escape(play_name)}</h2><table><tr><th>Company</th><th>Progress</th></tr>")
        for target_plan in plan.get("targets", []):
            company = target_plan.get("target", {}).get("company") or "?"
            total = len(target_plan.get("touches", []))
            done = len(state.get("targets", {}).get(company, {}).get("steps_done", []))
            pct = int(round((done / total) * 100)) if total else 0
            bar = f'<span class="bar-track"><span class="bar" style="width:{pct}%"></span></span> {done}/{total}'
            parts.append(f"<tr><td>{html.escape(str(company))}</td><td>{bar}</td></tr>")
        parts.append("</table>")

    return 200, _page("plays", "".join(parts))
