"""`gtmos quickstart` — the one-command "plug into CRM, immediate impact"
path: doctor preflight -> scaffold team config -> audit -> funnel -> today.

Every step reuses the existing module python APIs directly (no subprocess).
Fail-proof by design: a step with a missing source prints a skip reason and
continues; an unexpected exception in one step is captured and reported,
and every remaining step still runs. Only the doctor preflight is a hard
abort — an unsafe environment isn't worth partial impact on.

Expected argparse.Namespace shape (wired by the integrator):
  contacts: str|None   (--contacts FILE, offline contacts export)
  deals: str|None      (--deals FILE, offline deals export)
  acv: float|None      (--acv, average contract value override)
  dir: str|None        (--dir, workspace root for team config, default ".")
  out_root: str|None   (--out-root, root for audit-out/funnel-out, default ".")
  dry_run: bool        (--dry-run, default False)
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from gtmos import doctor
from gtmos.audit import engine as audit_engine
from gtmos.audit import fetch as audit_fetch
from gtmos.audit import report as audit_report
from gtmos.funnel import engine as funnel_engine
from gtmos.funnel import fetch as funnel_fetch
from gtmos.funnel import report as funnel_report
from gtmos.team import scaffold as team_scaffold
from gtmos.team.config import config_get, find_config_path, load_config
from gtmos.today import engine as today_engine

TOTAL_STEPS = 5
SERVE_URL = "http://127.0.0.1:8390"


def _print_step(n: int, message: str) -> None:
    print(f"[{n}/{TOTAL_STEPS}] {message}")


def _source_plan(path: str | None, has_token: bool) -> str:
    if path:
        return f"file {path}"
    if has_token:
        return "live (GTMOS_HUBSPOT_TOKEN)"
    return "(skip — no source)"


def run(args: argparse.Namespace) -> int:
    workspace_dir = getattr(args, "dir", None) or "."
    out_root = getattr(args, "out_root", None) or "."
    contacts_path = getattr(args, "contacts", None)
    deals_path = getattr(args, "deals", None)
    acv_arg = getattr(args, "acv", None)

    audit_out_dir = Path(out_root) / "audit-out"
    funnel_out_dir = Path(out_root) / "funnel-out"
    has_token = bool(os.environ.get("GTMOS_HUBSPOT_TOKEN"))

    if getattr(args, "dry_run", False):
        print("[dry-run] quickstart plan:")
        print(f"  1. doctor preflight (dir={workspace_dir})")
        print(f"  2. scaffold gtmos-team.json in {workspace_dir} if missing")
        print(f"  3. audit from {_source_plan(contacts_path, has_token)} -> {audit_out_dir}")
        print(f"  4. funnel from {_source_plan(deals_path, has_token)} -> {funnel_out_dir}")
        print(f"  5. build today checklist from {workspace_dir}")
        return 0

    # (a) doctor preflight — hard abort on failure.
    try:
        checks = doctor.run_checks(start_dir=workspace_dir)
    except Exception as exc:
        print(f"quickstart: doctor preflight crashed — {exc}")
        return 1

    failed = [c for c in checks if c.status == "fail"]
    if failed:
        for c in checks:
            print(f"quickstart: [{c.status}] {c.name}: {c.detail}")
        print("quickstart: aborting — doctor preflight failed")
        return 1
    _print_step(1, f"doctor preflight passed ({len(checks)} check(s), no failures)")

    # (b) team scaffold, if none exists yet.
    try:
        if find_config_path(workspace_dir) is None:
            team_name = Path(workspace_dir).resolve().name or "Your Team"
            scaffold_result = team_scaffold.scaffold(workspace_dir, team_name=team_name)
            created = ", ".join(scaffold_result["created"]) or "none"
            _print_step(2, f"scaffolded team workspace — created {created}")
        else:
            _print_step(2, "team config already present — scaffold skipped")
    except Exception as exc:
        print(f"[2/{TOTAL_STEPS}] team scaffold: failed — {exc}")

    cfg = load_config(workspace_dir)

    # (c) audit — offline file, or live via GTMOS_HUBSPOT_TOKEN.
    audit_summary = None
    try:
        contacts = None
        if contacts_path:
            contacts = audit_fetch.load_json(contacts_path)
        elif has_token:
            contacts = audit_fetch.fetch_hubspot(os.environ.get("GTMOS_HUBSPOT_TOKEN"))

        if not contacts:
            _print_step(3, "audit skipped — no --contacts file and no GTMOS_HUBSPOT_TOKEN (or source empty)")
        else:
            result = audit_engine.run_engine(contacts)
            acv = acv_arg if acv_arg is not None else (config_get(cfg, "team.acv") or 0.0)
            audit_summary = audit_report.render(result, acv, str(audit_out_dir))
            _print_step(
                3,
                f"audit — {result.total_records} record(s), portal score "
                f"{audit_summary['portal_score']:.1f} ({audit_summary['grade']})",
            )
    except Exception as exc:
        print(f"[3/{TOTAL_STEPS}] audit: failed — {exc}")

    # (d) funnel — offline file, or live via GTMOS_HUBSPOT_TOKEN.
    funnel_summary = None
    try:
        deals = None
        if deals_path:
            deals = funnel_fetch.load_json(deals_path)
        elif has_token:
            deals = funnel_fetch.fetch_hubspot_deals(os.environ.get("GTMOS_HUBSPOT_TOKEN"))

        if not deals:
            _print_step(4, "funnel skipped — no --deals file and no GTMOS_HUBSPOT_TOKEN (or source empty)")
        else:
            acv = acv_arg if acv_arg is not None else config_get(cfg, "team.acv")
            if acv and funnel_engine.all_amounts_missing(deals):
                for deal in deals:
                    deal["amount"] = acv
            stall_days = config_get(cfg, "stages.stall_days") or funnel_engine.DEFAULT_STALL_DAYS
            result = funnel_engine.run_engine(deals, funnel_engine.DEFAULT_STAGE_ORDER, stall_days=stall_days)
            funnel_summary = funnel_report.render(result, str(funnel_out_dir))
            _print_step(
                4,
                f"funnel — {result.total_deals} deal(s), losing ${funnel_summary['leak_total']:,.0f} "
                f"({funnel_summary['stalled_count']} stalled)",
            )
    except Exception as exc:
        print(f"[4/{TOTAL_STEPS}] funnel: failed — {exc}")

    # (e) today build — pick up whatever audit/funnel output actually landed.
    today_result = None
    try:
        paths_override = {}
        if audit_summary:
            paths_override["audit_path"] = audit_out_dir / "scores.json"
        if funnel_summary:
            paths_override["funnel_path"] = funnel_out_dir / "funnel.json"
        today_result = today_engine.build_today(workspace=workspace_dir, paths_override=paths_override)
        _print_step(5, f"today — {today_result['summary']['actions']} action(s) queued")
    except Exception as exc:
        print(f"[5/{TOTAL_STEPS}] today: failed — {exc}")

    # (f) final banner — partial data still yields partial impact.
    portal_str = f"{audit_summary['portal_score']:.1f} ({audit_summary['grade']})" if audit_summary else "n/a — no audit data"
    leak_str = f"${funnel_summary['leak_total']:,.0f}" if funnel_summary else "n/a — no funnel data"

    print()
    print("=== quickstart complete ===")
    print(f"portal score: {portal_str}")
    print(f"funnel leak: {leak_str}")
    print(f"next: gtmos serve → {SERVE_URL}, gtmos today --role <role>")

    return 0
