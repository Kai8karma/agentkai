"""`gtmos play` handler — signal-play library + multi-touch sequence
planner. Deterministic end to end; --draft is the only path that touches
gtmos.harness.run_harness, one call per target, capped at 10 targets.

Expected argparse.Namespace shape (wired by the integrator's nested
subparser under the top-level "play" command):
  action: "list" | "show" | "run" | "touch" | "status"
  name: str            (show, run, touch, status)
  targets: str         (run — path to a JSON array of target dicts)
  out: str             (run, touch, status — default "./play-out")
  start_date: str|None (run — "YYYY-MM-DD")
  draft: bool          (run — default False)
  dry_run: bool        (run — default False, forwarded to run_harness)
  target: str          (touch — company name, matched case-insensitively)
  step: int            (touch — step number to mark done)
  today: str|None      (status — "YYYY-MM-DD", default today)

touch/status read the plan written by `gtmos play run` (<out>/<play>-plan.json)
and a sibling execution-state file (<out>/<play>-state.json, see
gtmos.plays.state) that tracks which touches a human has actually sent.

Exit codes: 0 success, 1 bad input (unreadable/invalid targets file, or
no plan found for touch/status), 2 unknown play/company or missing/invalid
action.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from gtmos.plays import library
from gtmos.plays import state as play_state
from gtmos.plays.planner import apply_drafted_copy, build_plan
from gtmos.prompts import render_prompt

DRAFT_TARGET_CAP = 10


def _load_targets(path: str) -> list[dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path} is not valid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise ValueError(f"{path} must contain a JSON array of targets")
    return data


def _list_table() -> str:
    rows = [("NAME", "TRIGGER", "TOUCHES")]
    for play in library.list_plays():
        rows.append((play.name, play.trigger, str(len(play.sequence))))
    widths = [max(len(r[i]) for r in rows) for i in range(3)]
    lines = []
    for i, row in enumerate(rows):
        lines.append("  ".join(cell.ljust(widths[j]) for j, cell in enumerate(row)))
        if i == 0:
            lines.append("  ".join("-" * w for w in widths))
    return "\n".join(lines)


def _show_text(play: library.Play) -> str:
    lines = [
        f"play: {play.name}",
        f"trigger: {play.trigger}",
        f"icp_filter: {play.icp_filter}",
        f"angle: {play.angle}",
        "sequence:",
    ]
    for touch in play.sequence:
        lines.append(f"  step {touch.step} | day {touch.day_offset:>2} | {touch.channel}")
        lines.append(f"    {touch.template}")
    return "\n".join(lines)


def _draft_prompt(play: library.Play, target_plan: dict) -> str:
    target = target_plan["target"]
    touches_block = "\n".join(
        f"STEP {t['step']} ({t['channel']}): {t['copy']}" for t in target_plan["touches"]
    )
    return render_prompt(
        "play-draft",
        company=target.get("company") or "[FILL: company]",
        signal=target.get("signal") or "[FILL: signal]",
        angle=play.angle,
        touches_block=touches_block,
    )


def _apply_drafts(play: library.Play, plan: dict, dry_run: bool) -> str:
    from gtmos.harness import run_harness

    target_plans = plan["targets"]
    cap = min(DRAFT_TARGET_CAP, len(target_plans))
    for target_plan in target_plans[:cap]:
        output = run_harness(
            command="play-draft",
            prompt=_draft_prompt(play, target_plan),
            allowed_tools=[],
            dry_run=dry_run,
        )
        apply_drafted_copy(target_plan, output)

    note = f"--draft applied to {cap} of {len(target_plans)} target(s) (cap {DRAFT_TARGET_CAP})"
    plan["draft_note"] = note
    return note


def _write_plan_json(plan: dict, out_dir: Path, play_name: str) -> Path:
    path = out_dir / f"{play_name}-plan.json"
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return path


def _write_plan_md(plan: dict, out_dir: Path, play_name: str) -> Path:
    lines = [f"# {play_name} play plan", ""]
    lines.append(f"_Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}_")
    lines.append(f"_Start date: {plan['start_date']}_")
    lines.append("")

    if plan.get("warnings"):
        lines.append("## Warnings")
        lines.append("")
        for warning in plan["warnings"]:
            lines.append(f"- {warning}")
        lines.append("")

    if plan.get("draft_note"):
        lines.append(f"_{plan['draft_note']}_")
        lines.append("")

    for target_plan in plan["targets"]:
        target = target_plan["target"]
        header = target.get("company") or "[FILL: company]"
        contact = target.get("first_name") or "[FILL: first_name]"
        lines.append(f"## {header} — {contact}")
        lines.append("")
        for touch in target_plan["touches"]:
            lines.append(f"- Step {touch['step']} ({touch['channel']}) — {touch['date']}")
            lines.append(f"  {touch['copy']}")
        lines.append("")

    path = out_dir / f"{play_name}-plan.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _load_plan(out_dir: str, play_name: str) -> dict | None:
    path = Path(out_dir) / f"{play_name}-plan.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _find_target(plan: dict, target_input: str) -> str | None:
    """Case-insensitive lookup of `target_input` against plan target
    companies. Returns the canonical (as-plan-cased) company name, or
    None if no target matches."""
    for target_plan in plan.get("targets", []):
        company = target_plan["target"].get("company") or ""
        if company.lower() == target_input.lower():
            return company
    return None


def _status_output(plan: dict, state: dict, today: str) -> tuple[str, str]:
    due = play_state.due_touches(plan, state, today)
    due_by_company: dict[str, list[dict]] = {}
    for touch in due:
        due_by_company.setdefault(touch["company"], []).append(touch)

    rows = [("COMPANY", "DONE STEPS", "NEXT DUE", "OVERDUE")]
    due_today = 0
    overdue_total = 0
    complete = 0

    for target_plan in plan.get("targets", []):
        company = target_plan["target"].get("company") or "?"
        total_steps = len(target_plan.get("touches", []))
        steps_done = sorted(state.get("targets", {}).get(company, {}).get("steps_done", []))
        done_str = ",".join(str(s) for s in steps_done) if steps_done else "-"

        company_due = sorted(due_by_company.get(company, []), key=lambda t: t["date"])
        company_overdue = sum(1 for t in company_due if t["overdue"])
        overdue_total += company_overdue
        due_today += len(company_due) - company_overdue

        if total_steps and len(steps_done) >= total_steps:
            complete += 1
            next_str = "done"
        elif company_due:
            nxt = company_due[0]
            next_str = f"step {nxt['step']} ({nxt['channel']}) {nxt['date']}"
        else:
            next_str = "-"

        rows.append((company, done_str, next_str, str(company_overdue) if company_overdue else "-"))

    widths = [max(len(r[i]) for r in rows) for i in range(4)]
    lines = []
    for i, row in enumerate(rows):
        lines.append("  ".join(cell.ljust(widths[j]) for j, cell in enumerate(row)))
        if i == 0:
            lines.append("  ".join("-" * w for w in widths))

    summary = f"play: {due_today} due today, {overdue_total} overdue, {complete} complete"
    return "\n".join(lines), summary


def run(args) -> int:
    action = getattr(args, "action", None)

    if action == "list":
        print(_list_table())
        return 0

    if action == "show":
        name = getattr(args, "name", None)
        play = library.get_play(name)
        if play is None:
            print(f"play: unknown play '{name}'")
            return 2
        print(_show_text(play))
        return 0

    if action == "run":
        name = getattr(args, "name", None)
        play = library.get_play(name)
        if play is None:
            print(f"play: unknown play '{name}'")
            return 2

        targets_path = getattr(args, "targets", None)
        if not targets_path:
            print("play: run requires --targets FILE")
            return 2

        try:
            targets = _load_targets(targets_path)
        except ValueError as exc:
            print(f"play: {exc}")
            return 1

        if not targets:
            print("play: no targets found in input")
            return 1

        start_date = getattr(args, "start_date", None)
        plan = build_plan(play, targets, start_date)

        dry_run = bool(getattr(args, "dry_run", False))
        draft_note = ""
        if getattr(args, "draft", False):
            draft_note = _apply_drafts(play, plan, dry_run)

        out_dir = Path(getattr(args, "out", None) or "./play-out")
        out_dir.mkdir(parents=True, exist_ok=True)

        json_path = _write_plan_json(plan, out_dir, play.name)
        _write_plan_md(plan, out_dir, play.name)

        print(
            f"play: {play.name} -> {len(targets)} target(s), "
            f"{len(play.sequence)} touches each — plan: {json_path}"
        )
        if plan.get("warnings"):
            print(f"play: {len(plan['warnings'])} target(s) missing signal evidence")
        if draft_note:
            print(f"play: {draft_note}")

        return 0

    if action == "touch":
        name = getattr(args, "name", None)
        play = library.get_play(name)
        if play is None:
            print(f"play: unknown play '{name}'")
            return 2

        out_dir = getattr(args, "out", None) or "./play-out"
        plan = _load_plan(out_dir, play.name)
        if plan is None:
            print(f"play: no plan found for '{play.name}' in {out_dir} — run `gtmos play run {play.name} --targets FILE` first")
            return 1

        target_input = getattr(args, "target", None)
        step = getattr(args, "step", None)
        if not target_input or step is None:
            print("play: touch requires --target COMPANY --step N")
            return 2

        company = _find_target(plan, target_input)
        if company is None:
            known = ", ".join(t["target"].get("company") or "?" for t in plan.get("targets", []))
            print(f"play: unknown company '{target_input}' — known targets: {known}")
            return 2

        state = play_state.load_state(out_dir, play.name)
        play_state.mark_touch(state, company, int(step))
        play_state.save_state(out_dir, play.name, state)

        print(f"play: {play.name} — marked {company} step {step} done")
        return 0

    if action == "status":
        name = getattr(args, "name", None)
        play = library.get_play(name)
        if play is None:
            print(f"play: unknown play '{name}'")
            return 2

        out_dir = getattr(args, "out", None) or "./play-out"
        plan = _load_plan(out_dir, play.name)
        if plan is None:
            print(f"play: no plan found for '{play.name}' in {out_dir} — run `gtmos play run {play.name} --targets FILE` first")
            return 1

        today = getattr(args, "today", None) or datetime.now(timezone.utc).date().isoformat()
        state = play_state.load_state(out_dir, play.name)
        table, summary = _status_output(plan, state, today)
        print(table)
        print(summary)
        return 0

    print(f"play: unknown action {action!r} (expected list, show, run, touch, or status)")
    return 2
