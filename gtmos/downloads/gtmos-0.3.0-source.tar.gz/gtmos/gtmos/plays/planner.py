"""Deterministic multi-touch sequence planner. No LLM, no network.

build_plan renders each play touch's template against a target dict,
computes real calendar dates from day_offset, and flags targets missing
a "signal" evidence field so a human can chase down proof before sending.
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from string import Template

from gtmos.plays.library import Play, Touch

SIGNAL_FIELD = "signal"
_TEMPLATE_FIELDS = ("first_name", "company", "signal")


class _FillDict(dict):
    """dict whose missing/blank keys render as "[FILL: <key>]" instead of
    raising or silently substituting an empty string."""

    def __missing__(self, key):
        return f"[FILL: {key}]"


def _render_touch(template: str, target: dict, angle: str) -> str:
    mapping = _FillDict(angle=angle)
    for field_name in _TEMPLATE_FIELDS:
        value = target.get(field_name)
        if value:
            mapping[field_name] = value
    return Template(template).substitute(mapping)


def _resolve_start_date(start_date: str | None) -> date:
    if not start_date:
        return date.today()
    return datetime.strptime(start_date, "%Y-%m-%d").date()


def _touch_date(start: date, day_offset: int) -> str:
    return (start + timedelta(days=day_offset)).isoformat()


def _render_target_touches(play: Play, target: dict, start: date) -> list[dict]:
    touches = []
    for touch in play.sequence:
        touches.append(
            {
                "step": touch.step,
                "channel": touch.channel,
                "day_offset": touch.day_offset,
                "date": _touch_date(start, touch.day_offset),
                "copy": _render_touch(touch.template, target, play.angle),
            }
        )
    return touches


def build_plan(play: Play, targets: list[dict], start_date: str | None = None) -> dict:
    """Render `play` against every target.

    Returns {"play", "start_date", "targets": [{"target", "touches"}],
    "warnings"}. `warnings` lists targets missing the `signal` evidence
    field — the play still renders for them (with "[FILL: signal]" in
    place of the missing value) so a plan is never blocked, just flagged.
    """
    start = _resolve_start_date(start_date)
    target_plans = []
    warnings = []

    for target in targets:
        if not target.get(SIGNAL_FIELD):
            label = target.get("first_name") or target.get("company") or "unknown target"
            warnings.append(f"{label}: missing '{SIGNAL_FIELD}' evidence field")
        target_plans.append(
            {
                "target": target,
                "touches": _render_target_touches(play, target, start),
            }
        )

    return {
        "play": play.name,
        "start_date": start.isoformat(),
        "targets": target_plans,
        "warnings": warnings,
    }


_STEP_RE = re.compile(r"STEP\s+(\d+)\s*(?:\([^)]*\))?\s*:\s*(.*)", re.IGNORECASE)


def apply_drafted_copy(target_plan: dict, harness_output: str) -> None:
    """Overwrite touch["copy"] in place with harness output, matched by
    step number ("STEP <n>: <copy>" lines). Blank/unmatched output leaves
    the deterministic template copy untouched."""
    if not harness_output:
        return
    rewritten: dict[int, str] = {}
    for line in harness_output.splitlines():
        match = _STEP_RE.match(line.strip())
        if match:
            text = match.group(2).strip()
            if text:
                rewritten[int(match.group(1))] = text
    for touch in target_plan["touches"]:
        if touch["step"] in rewritten:
            touch["copy"] = rewritten[touch["step"]]
