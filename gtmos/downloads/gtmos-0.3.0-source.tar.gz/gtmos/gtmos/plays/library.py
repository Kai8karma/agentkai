"""Built-in signal plays. Four dataclass-backed plays, each a trigger + ICP
filter + angle + a 4-5 touch sequence over ~14 days. Every sequence opens
with a linkedin_comment before any linkedin_dm (comment-before-DM: the
prospect googles/checks the sender's profile after a DM, so a real comment
on their post gives them something to find).

Templates use string.Template syntax ($first_name/$company/$signal/$angle)
and are rendered by gtmos.plays.planner.build_plan.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Touch:
    step: int
    channel: str  # "linkedin_comment" | "linkedin_dm" | "email"
    day_offset: int
    template: str


@dataclass
class Play:
    name: str
    trigger: str
    icp_filter: str
    angle: str
    sequence: list[Touch] = field(default_factory=list)


_POST_MERGER = Play(
    name="post-merger",
    trigger="target announced merger/acquisition",
    icp_filter="RevOps/Sales Ops/Marketing Ops leader at a company mid-merger or mid-acquisition",
    angle="systems+CRM consolidation chaos = leak audit",
    sequence=[
        Touch(
            step=1,
            channel="linkedin_comment",
            day_offset=0,
            template=(
                "Congrats on the $signal, $company — mergers like this are exactly when "
                "CRM data quietly forks into two systems of record. Following along."
            ),
        ),
        Touch(
            step=2,
            channel="linkedin_dm",
            day_offset=3,
            template=(
                "Hi $first_name, saw $company's $signal. $angle. Worth a 15-min look at "
                "where the two CRMs are already diverging?"
            ),
        ),
        Touch(
            step=3,
            channel="email",
            day_offset=6,
            template=(
                "Subject: $company post-$signal data check\n\n"
                "Hi $first_name,\n\n$angle. Most merged orgs don't notice the duplicate "
                "or contradictory records until a quarter in. Happy to run a free audit "
                "against your current CRM export — 20 minutes, no obligation.\n\n"
                "Worth a look?"
            ),
        ),
        Touch(
            step=4,
            channel="linkedin_dm",
            day_offset=10,
            template=(
                "$first_name — following up. If integration planning is underway, the "
                "audit takes 20 minutes and tells you exactly where the leak is before it "
                "compounds."
            ),
        ),
        Touch(
            step=5,
            channel="email",
            day_offset=14,
            template=(
                "Subject: closing the loop\n\nHi $first_name,\n\nLast note on this — if "
                "$company's post-$signal CRM cleanup lands on the roadmap later this "
                "year, keep me in mind. I'll leave the door open."
            ),
        ),
    ],
)

_NEW_REVOPS_HIRE = Play(
    name="new-revops-hire",
    trigger="new RevOps/Sales Ops leader started <90d",
    icp_filter="RevOps/Sales Ops/GTM Ops leader with tenure under 90 days",
    angle="incoming leader wants a baseline audit",
    sequence=[
        Touch(
            step=1,
            channel="linkedin_comment",
            day_offset=0,
            template=(
                "Congrats on the new seat at $company, $first_name — the first 90 days "
                "are the best window to baseline the CRM before you inherit its mess."
            ),
        ),
        Touch(
            step=2,
            channel="linkedin_dm",
            day_offset=3,
            template=(
                "Hi $first_name, congrats again on $signal. $angle — want a free "
                "baseline audit you can put in your first 90-day plan?"
            ),
        ),
        Touch(
            step=3,
            channel="email",
            day_offset=7,
            template=(
                "Subject: a baseline for your first 90 days at $company\n\n"
                "Hi $first_name,\n\n$angle. I can hand you a scored report on validity, "
                "freshness, and duplicate/leak findings before your first QBR — no cost, "
                "no obligation.\n\nWorth 20 minutes?"
            ),
        ),
        Touch(
            step=4,
            channel="linkedin_dm",
            day_offset=12,
            template=(
                "$first_name — still happy to run that baseline audit whenever it's "
                "useful. No pressure, just flagging it's on the table."
            ),
        ),
    ],
)

_HIRING_SPREE = Play(
    name="hiring-spree",
    trigger="3+ open GTM roles",
    icp_filter="VP/Director of Sales, Marketing, or RevOps at a company with 3+ open GTM roles",
    angle="scaling team amplifies data leaks",
    sequence=[
        Touch(
            step=1,
            channel="linkedin_comment",
            day_offset=0,
            template=(
                "Saw $company is scaling the GTM team fast — $signal. Every new rep "
                "added is another set of hands touching the CRM."
            ),
        ),
        Touch(
            step=2,
            channel="linkedin_dm",
            day_offset=3,
            template=(
                "Hi $first_name, noticed $signal at $company. $angle — want a quick "
                "read on how clean the data is before the team doubles?"
            ),
        ),
        Touch(
            step=3,
            channel="email",
            day_offset=7,
            template=(
                "Subject: scaling $company's GTM team without scaling the data mess\n\n"
                "Hi $first_name,\n\n$angle. A free audit now tells you exactly what shape "
                "the CRM is in before more reps start writing to it.\n\nOpen to a look?"
            ),
        ),
        Touch(
            step=4,
            channel="linkedin_dm",
            day_offset=12,
            template=(
                "$first_name — following up on the audit offer. Happy to send the "
                "scored report whenever useful."
            ),
        ),
    ],
)

_COMPLIANCE_WALL = Play(
    name="compliance-wall",
    trigger="regulated buyer/security review blocks cloud tools",
    icp_filter="Security/IT/RevOps leader at a regulated buyer blocked by security review on cloud tools",
    angle="zero-egress self-hosted wedge",
    sequence=[
        Touch(
            step=1,
            channel="linkedin_comment",
            day_offset=0,
            template=(
                "$company's security review stance makes sense — $signal. Cloud CRM "
                "tooling is exactly where that stalls."
            ),
        ),
        Touch(
            step=2,
            channel="linkedin_dm",
            day_offset=3,
            template=(
                "Hi $first_name, saw $signal at $company. $angle — it runs entirely in "
                "your infra, so it doesn't add to the review queue. Want a look?"
            ),
        ),
        Touch(
            step=3,
            channel="email",
            day_offset=6,
            template=(
                "Subject: a CRM audit that never leaves $company's infra\n\n"
                "Hi $first_name,\n\n$angle. Self-hosted, zero egress — the audit report "
                "never crosses your security boundary. Worth 20 minutes to walk through "
                "it?"
            ),
        ),
        Touch(
            step=4,
            channel="linkedin_dm",
            day_offset=10,
            template=(
                "$first_name — following up. If the cloud-tool freeze is still active, "
                "this is built specifically to run inside it."
            ),
        ),
        Touch(
            step=5,
            channel="email",
            day_offset=14,
            template=(
                "Subject: closing the loop on the self-hosted audit\n\nHi $first_name,\n\n"
                "Last note — if $company's security posture ever opens a window for "
                "this, I'll have it ready to run same day.\n\nBest"
            ),
        ),
    ],
)

PLAYS: dict[str, Play] = {
    p.name: p
    for p in (_POST_MERGER, _NEW_REVOPS_HIRE, _HIRING_SPREE, _COMPLIANCE_WALL)
}


def get_play(name: str) -> Play | None:
    return PLAYS.get(name)


def list_plays() -> list[Play]:
    return list(PLAYS.values())
