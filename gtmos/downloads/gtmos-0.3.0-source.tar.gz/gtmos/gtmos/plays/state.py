"""Play execution-state tracking — <out>/<play>-state.json.

State tracks which touches a human has actually sent, independent of the
plan file (which `gtmos play run` can regenerate at will). Touch dates are
plain "YYYY-MM-DD" strings throughout, which sort/compare correctly as
plain strings (no date parsing needed for due/overdue checks).

State shape: {"play": name, "targets": {"<company>": {"steps_done": [1, 2],
"last_touch": "<iso ts>"}}}
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

STATE_SUFFIX = "-state.json"


def _state_path(out_dir: str | Path, play_name: str) -> Path:
    return Path(out_dir) / f"{play_name}{STATE_SUFFIX}"


def load_state(out_dir: str | Path, play_name: str) -> dict:
    """Load <out>/<play>-state.json. Returns an empty scaffold
    ({"play": play_name, "targets": {}}) if the file is missing or
    unreadable — never crashes."""
    path = _state_path(out_dir, play_name)
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("targets"), dict):
                return data
            print(f"gtmos: warning — {path} has an unexpected shape, starting fresh")
        except (OSError, ValueError):
            print(f"gtmos: warning — {path} is corrupt, starting fresh")
    return {"play": play_name, "targets": {}}


def save_state(out_dir: str | Path, play_name: str, state: dict) -> Path:
    """Write state to <out>/<play>-state.json, creating out_dir if needed.

    Writes to a <path>.tmp sibling first, then os.replace()s it into place,
    so a crash mid-write can never leave a partial/corrupt state file — the
    original (if any) survives untouched until the replace succeeds.
    """
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    path = _state_path(out_path, play_name)
    tmp_path = path.with_name(path.name + ".tmp")
    tmp_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    try:
        os.replace(tmp_path, path)
    except OSError:
        tmp_path.unlink(missing_ok=True)
        raise
    return path


def mark_touch(state: dict, company: str, step: int, ts: str | None = None) -> None:
    """Mark `step` done for `company` in `state`, in place. Recording the
    same step twice is a no-op on steps_done but still refreshes last_touch."""
    ts = ts or datetime.now(timezone.utc).isoformat(timespec="seconds")
    targets = state.setdefault("targets", {})
    target = targets.setdefault(company, {"steps_done": [], "last_touch": None})
    if step not in target["steps_done"]:
        target["steps_done"].append(step)
        target["steps_done"].sort()
    target["last_touch"] = ts


def due_touches(plan: dict, state: dict, today: str) -> list[dict]:
    """Cross-reference a play plan against its state.

    A touch is due if its date <= today and its step is not in
    steps_done for that target's company; overdue if date < today.
    Returns a flat list of {company, step, channel, date, copy, overdue}
    dicts, plan order preserved (touch order within each target).
    """
    targets_state = state.get("targets", {})
    due: list[dict] = []
    for target_plan in plan.get("targets", []):
        company = target_plan["target"].get("company") or ""
        steps_done = set(targets_state.get(company, {}).get("steps_done", []))
        for touch in target_plan.get("touches", []):
            if touch["step"] in steps_done:
                continue
            if touch["date"] > today:
                continue
            due.append(
                {
                    "company": company,
                    "step": touch["step"],
                    "channel": touch["channel"],
                    "date": touch["date"],
                    "copy": touch["copy"],
                    "overdue": touch["date"] < today,
                }
            )
    return due
