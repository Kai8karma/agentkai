"""Signal-play library + multi-touch sequence planner — the SDR/marketing
surface of GTM OS. Deterministic, offline, no LLM calls except the optional
`--draft` copy upgrade (routed through gtmos.harness.run_harness, one call
per target, capped at 10 targets per run).

library.PLAYS -> dict[str, Play], four built-in signal plays:
  "post-merger"      trigger: target announced merger/acquisition
  "new-revops-hire"  trigger: new RevOps/Sales Ops leader started <90d
  "hiring-spree"     trigger: 3+ open GTM roles
  "compliance-wall"  trigger: regulated buyer/security review blocks cloud tools

planner.build_plan(play, targets, start_date) -> plan dict:
  {"play", "start_date", "targets": [{"target", "touches": [...]}], "warnings"}

cli_entry.run(args) -> int   `gtmos play list|show|run` handler.
"""

from __future__ import annotations
