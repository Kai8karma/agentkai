"""Deterministic ABM ad-set planner. No LLM, no network.

The craft problem: LinkedIn's Matched Audiences won't activate a campaign
below a practical minimum size. True 1:1 ABM (one ad set per account) is
only deliverable when a single account's estimated audience clears that
floor on its own — for most accounts it won't. So this planner estimates
each account's reachable audience, gives dedicated one_to_one ad sets to
the accounts that clear the floor alone, and greedily clusters the rest
into shared "clustered" ad sets sized to clear it together. Both outcomes
are honest: a clustered ad set says so, and says why.
"""

from __future__ import annotations

from dataclasses import dataclass

# Rough share of headcount reachable in a given department, as a fraction
# of total employee_count. Documented assumption, not a measured rate.
DEPARTMENT_SHARES = {
    "sales": 0.10,
    "marketing": 0.06,
    "engineering": 0.25,
    "finance": 0.05,
    "operations": 0.12,
    "it": 0.08,
    "hr": 0.04,
}
UNKNOWN_DEPARTMENT_SHARE = 0.08

# Rough share of a department reachable at a given seniority level.
SENIORITY_SHARES = {
    "director": 0.10,
    "vp": 0.04,
    "cxo": 0.02,
    "manager": 0.20,
    "senior": 0.25,
}
# Not specified upstream — mirrors the unknown-department fallback above
# so an unrecognized seniority label degrades gracefully rather than
# zeroing out the estimate.
UNKNOWN_SENIORITY_SHARE = 0.08

# employee_count is unknown for the account: assume SMB rather than refuse
# to plan at all.
DEFAULT_EMPLOYEE_COUNT_ASSUMPTION = 200

DEFAULT_DEPARTMENTS = ["sales", "marketing"]
DEFAULT_SENIORITIES = ["director", "vp", "cxo"]

# LinkedIn Matched Audiences will not reliably activate a targeting facet
# below this size. Below it, a 1:1 ad set for that account alone isn't
# deliverable.
LINKEDIN_AUDIENCE_FLOOR = 300

# Clustering target: floor plus margin, so a cluster isn't sitting right at
# the edge where normal day-to-day audience drift could stall delivery.
CLUSTER_TARGET = LINKEDIN_AUDIENCE_FLOOR + 150  # 450


@dataclass
class AdSetPlan:
    accounts: list[dict]
    tier: str  # "one_to_one" | "clustered"
    estimated_audience: int
    targeting: dict
    sizing_note: str


def estimate_audience(account: dict) -> int:
    """Rough reachable-audience estimate for one account.

    estimate = employee_count
               x sum(department_share for each requested department)
               x sum(seniority_share for each requested seniority)

    Multiple requested departments/seniorities are summed (not averaged) —
    each widens the reachable slice of headcount. employee_count of None
    assumes DEFAULT_EMPLOYEE_COUNT_ASSUMPTION (200, "assume SMB"). Floored
    at 0, truncated to an int.
    """
    employee_count = account.get("employee_count")
    if employee_count is None:
        employee_count = DEFAULT_EMPLOYEE_COUNT_ASSUMPTION

    departments = account.get("departments") or DEFAULT_DEPARTMENTS
    seniorities = account.get("seniorities") or DEFAULT_SENIORITIES

    department_share = sum(DEPARTMENT_SHARES.get(d.lower(), UNKNOWN_DEPARTMENT_SHARE) for d in departments)
    seniority_share = sum(SENIORITY_SHARES.get(s.lower(), UNKNOWN_SENIORITY_SHARE) for s in seniorities)

    estimate = employee_count * department_share * seniority_share
    return max(0, int(estimate))


def _account_ref(entry: dict) -> dict:
    ref = {"name": entry["name"], "domain": entry["domain"], "estimated_audience": entry["estimated_audience"]}
    if entry.get("pain"):
        ref["pain"] = entry["pain"]
    return ref


def _segment_label(departments: list[str]) -> str:
    titled = [d.strip().title() for d in departments if d and d.strip()]
    if not titled:
        return "Your segment"
    if len(titled) <= 2:
        return " & ".join(titled)
    return "Cross-functional teams"


def _one_to_one_plan(entry: dict) -> AdSetPlan:
    departments = entry.get("departments") or DEFAULT_DEPARTMENTS
    seniorities = entry.get("seniorities") or DEFAULT_SENIORITIES
    estimate = entry["estimated_audience"]
    return AdSetPlan(
        accounts=[_account_ref(entry)],
        tier="one_to_one",
        estimated_audience=estimate,
        targeting={
            "companies": [{"name": entry["name"], "domain": entry["domain"]}],
            "functions": departments,
            "seniorities": seniorities,
            "segment_label": entry["name"],
        },
        sizing_note=(
            f"est. audience {estimate} clears the {LINKEDIN_AUDIENCE_FLOOR} floor -> dedicated 1:1 ad set."
        ),
    )


def _build_cluster_plan(cluster: list[dict]) -> AdSetPlan:
    cluster_sum = sum(e["estimated_audience"] for e in cluster)
    departments = sorted({d for e in cluster for d in (e.get("departments") or DEFAULT_DEPARTMENTS)})
    seniorities = sorted({s for e in cluster for s in (e.get("seniorities") or DEFAULT_SENIORITIES)})
    names = ", ".join(e["name"] for e in cluster)
    smallest = min(e["estimated_audience"] for e in cluster)

    if cluster_sum >= CLUSTER_TARGET:
        note = (
            f"{len(cluster)} accounts clustered ({names}) — each below the "
            f"{LINKEDIN_AUDIENCE_FLOOR} floor individually (smallest est. {smallest}) -> "
            f"combined est. audience {cluster_sum} clears the {CLUSTER_TARGET} floor+margin target."
        )
    else:
        note = (
            f"{len(cluster)} accounts clustered ({names}) — combined est. audience {cluster_sum} "
            f"is still below the {CLUSTER_TARGET} floor+margin target even after grouping all "
            "remaining small accounts; recommend folding into a broader segment campaign."
        )

    return AdSetPlan(
        accounts=[_account_ref(e) for e in cluster],
        tier="clustered",
        estimated_audience=cluster_sum,
        targeting={
            "companies": [{"name": e["name"], "domain": e["domain"]} for e in cluster],
            "functions": departments,
            "seniorities": seniorities,
            "segment_label": _segment_label(departments),
        },
        sizing_note=note,
    )


def plan(accounts: list[dict]) -> list[AdSetPlan]:
    """Build ad-set plans for a list of raw account dicts.

    Accounts whose estimated audience clears LINKEDIN_AUDIENCE_FLOOR alone
    get a dedicated one_to_one ad set. The rest are sorted largest-estimate
    first and greedily packed into clustered ad sets, closing each cluster
    once it clears CLUSTER_TARGET (floor + margin). A final partial cluster
    that never reaches CLUSTER_TARGET is still emitted — its sizing_note
    says so honestly.
    """
    entries = []
    for account in accounts:
        entries.append({**account, "estimated_audience": estimate_audience(account)})

    big = [e for e in entries if e["estimated_audience"] >= LINKEDIN_AUDIENCE_FLOOR]
    small = sorted(
        (e for e in entries if e["estimated_audience"] < LINKEDIN_AUDIENCE_FLOOR),
        key=lambda e: e["estimated_audience"],
        reverse=True,
    )

    plans = [_one_to_one_plan(e) for e in big]

    cluster: list[dict] = []
    cluster_sum = 0
    for entry in small:
        cluster.append(entry)
        cluster_sum += entry["estimated_audience"]
        if cluster_sum >= CLUSTER_TARGET:
            plans.append(_build_cluster_plan(cluster))
            cluster = []
            cluster_sum = 0
    if cluster:
        plans.append(_build_cluster_plan(cluster))

    return plans
