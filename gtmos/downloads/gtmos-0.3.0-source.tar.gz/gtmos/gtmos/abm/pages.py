"""Render one landing page per ABM plan.

render_all(plans, out_dir) -> list[str] of written file paths.

Slug: first account's name for tier="one_to_one", "cluster-<n>" (1-based
position in `plans`) for tier="clustered". All account-sourced strings
(names, pains) are html.escape()'d before substitution — untrusted input.
"""

from __future__ import annotations

import html
import re
from pathlib import Path

from gtmos.abm.templates import FOOTER_LOGO_NOTE, LANDING_PAGE, LANDING_PAGE_CLUSTERED

DEFAULT_CTA_URL = "#book"

_GENERIC_SUBHEAD = "Bad data doesn't quit — it just costs you quietly, deal by deal."


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.strip().lower()).strip("-")
    return slug or "account"


def cta_url(plan) -> str:
    return getattr(plan, "cta_url", None) or DEFAULT_CTA_URL


def _pain_subhead(pain: str | None) -> str:
    if not pain:
        return _GENERIC_SUBHEAD
    return f"Your team is fighting {html.escape(pain)} — bad data dressed up as pipeline."


def _render_one_to_one(plan) -> str:
    account = plan.accounts[0]
    name = html.escape(str(account.get("name", "")))
    domain = account.get("domain")
    pain = account.get("pain")

    if domain:
        logo_block = (
            f'<img class="logo" src="https://logo.clearbit.com/{html.escape(domain)}" '
            'onerror="this.style.display=\'none\'">'
        )
        footer_logo_note = FOOTER_LOGO_NOTE
    else:
        logo_block = ""
        footer_logo_note = ""

    page = LANDING_PAGE
    page = page.replace("{{company}}", name)
    page = page.replace("{{subhead}}", _pain_subhead(pain))
    page = page.replace("{{cta_url}}", html.escape(cta_url(plan)))
    page = page.replace("{{logo_block}}", logo_block)
    page = page.replace("{{footer_logo_note}}", footer_logo_note)
    return page


def _render_clustered(plan) -> str:
    accounts = plan.accounts
    targeting = getattr(plan, "targeting", None) or {}
    segment_label = html.escape(str(targeting.get("segment_label") or "Your segment"))
    pains = [a["pain"] for a in accounts if a.get("pain")]
    subhead = _pain_subhead(pains[0] if pains else None)
    member_names = [html.escape(str(a.get("name", ""))) for a in accounts]
    member_list = " ".join(f"<span>{n}</span>" for n in member_names)

    page = LANDING_PAGE_CLUSTERED
    page = page.replace("{{segment_label}}", segment_label)
    page = page.replace("{{subhead}}", subhead)
    page = page.replace("{{member_list}}", member_list)
    page = page.replace("{{cta_url}}", html.escape(cta_url(plan)))
    return page


def render_all(plans, out_dir: str) -> list[str]:
    pages_dir = Path(out_dir) / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    written: list[str] = []
    for i, plan in enumerate(plans, start=1):
        if plan.tier == "one_to_one":
            slug = slugify(str(plan.accounts[0].get("name", "")))
            html_out = _render_one_to_one(plan)
        elif plan.tier == "clustered":
            slug = f"cluster-{i}"
            html_out = _render_clustered(plan)
        else:
            raise ValueError(f"unknown plan tier: {plan.tier!r}")

        out_path = pages_dir / f"{slug}.html"
        out_path.write_text(html_out)
        written.append(str(out_path))

    return written
