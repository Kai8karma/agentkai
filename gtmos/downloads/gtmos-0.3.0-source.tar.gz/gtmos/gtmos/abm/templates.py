"""Module-level string templates for ABM assets.

Every template is a plain string with {{token}} placeholders, replaced via
str.replace by pages.py / creative.py (no templating engine — stdlib only).
Callers MUST html.escape() any account-sourced string (name, pain, segment
label, member names) before substitution; these templates do not escape.

Single-file HTML: no external CSS/JS/font requests, system font stack,
one accent color, mobile-first. Logo images reference
https://logo.clearbit.com/<domain> — never fetched at generation time.
"""

from __future__ import annotations

ACCENT = "#0a66c2"

# Shared CSS, inlined into every page/creative. System font stack only.
_BASE_CSS = f"""
  :root {{ --accent: {ACCENT}; --ink: #0f1720; --muted: #5b6675; --bg: #ffffff; --line: #e6e9ee; }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; color: var(--ink); background: var(--bg);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    line-height: 1.5;
  }}
  a {{ color: inherit; }}
"""

VALUE_BULLETS_HTML = """
      <ul class="value-row">
        <li><strong>Scored report.</strong> Every record graded on validity, freshness, completeness.</li>
        <li><strong>Dupe + $-leak findings.</strong> Duplicate records and the pipeline dollars they're hiding.</li>
        <li><strong>Runs in your infra.</strong> Self-hosted — your CRM data never leaves your machine.</li>
      </ul>
"""

FOOTER_LOGO_NOTE = '<p class="logo-note">Logo shown for identification purposes only.</p>'

LANDING_PAGE = (
    """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{company}} — CRM Integrity Audit</title>
<style>"""
    + _BASE_CSS
    + """
  .wrap { max-width: 720px; margin: 0 auto; padding: 32px 20px 64px; }
  .logo { width: 48px; height: 48px; border-radius: 8px; margin-bottom: 16px; object-fit: contain; }
  h1 { font-size: clamp(28px, 5vw, 40px); line-height: 1.15; margin: 0 0 12px; }
  .subhead { color: var(--muted); font-size: 18px; margin: 0 0 28px; }
  .value-row { list-style: none; margin: 0 0 32px; padding: 0; display: grid; gap: 14px; }
  .value-row li { padding: 14px 16px; border: 1px solid var(--line); border-radius: 10px; font-size: 15px; }
  .cta { display: inline-block; background: var(--accent); color: #fff; text-decoration: none;
         font-weight: 600; padding: 14px 28px; border-radius: 8px; font-size: 16px; }
  footer { margin-top: 48px; border-top: 1px solid var(--line); padding-top: 16px; }
  .logo-note, footer p { color: var(--muted); font-size: 13px; margin: 4px 0; }
</style>
</head>
<body>
  <div class="wrap">
    {{logo_block}}
    <h1>{{company}}, your CRM is leaking pipeline you can't see</h1>
    <p class="subhead">{{subhead}}</p>
"""
    + VALUE_BULLETS_HTML
    + """
    <a class="cta" href="{{cta_url}}">Get the audit</a>
    <footer>
      {{footer_logo_note}}
      <p>Prepared for {{company}} · not affiliated with {{company}}.</p>
    </footer>
  </div>
</body>
</html>
"""
)

LANDING_PAGE_CLUSTERED = (
    """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{segment_label}} — CRM Integrity Audit</title>
<style>"""
    + _BASE_CSS
    + """
  .wrap { max-width: 720px; margin: 0 auto; padding: 32px 20px 64px; }
  h1 { font-size: clamp(28px, 5vw, 40px); line-height: 1.15; margin: 0 0 12px; }
  .subhead { color: var(--muted); font-size: 18px; margin: 0 0 24px; }
  .value-row { list-style: none; margin: 0 0 28px; padding: 0; display: grid; gap: 14px; }
  .value-row li { padding: 14px 16px; border: 1px solid var(--line); border-radius: 10px; font-size: 15px; }
  .members { color: var(--muted); font-size: 13px; margin: 0 0 32px; }
  .members span { display: inline-block; margin: 0 8px 6px 0; padding: 4px 10px; border: 1px solid var(--line);
                  border-radius: 999px; }
  .cta { display: inline-block; background: var(--accent); color: #fff; text-decoration: none;
         font-weight: 600; padding: 14px 28px; border-radius: 8px; font-size: 16px; }
  footer { margin-top: 48px; border-top: 1px solid var(--line); padding-top: 16px; }
  footer p { color: var(--muted); font-size: 13px; margin: 4px 0; }
</style>
</head>
<body>
  <div class="wrap">
    <h1>{{segment_label}}, your CRM is leaking pipeline you can't see</h1>
    <p class="subhead">{{subhead}}</p>
"""
    + VALUE_BULLETS_HTML
    + """
    <p class="members">{{member_list}}</p>
    <a class="cta" href="{{cta_url}}">Get the audit</a>
    <footer>
      <p>Benchmarked across a peer segment — company names shown are for context, not endorsement.</p>
    </footer>
  </div>
</body>
</html>
"""
)

# 1200x627 — LinkedIn single-image ad spec. Left: text block. Right: logo,
# degrades gracefully via onerror if the domain has no Clearbit logo.
# NOTE: HTML is the deliverable for now — render to PNG later via
# playwright/screenshot when a headless-browser step is wired in.
CREATIVE_CARD = (
    """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{{company}} — ad creative</title>
<style>"""
    + _BASE_CSS
    + """
  html, body { width: 1200px; height: 627px; overflow: hidden; }
  .card { width: 1200px; height: 627px; display: flex; align-items: stretch; }
  .text { flex: 1 1 62%; padding: 64px 56px; display: flex; flex-direction: column; justify-content: center; }
  .eyebrow { color: var(--accent); font-weight: 700; font-size: 15px; letter-spacing: 0.04em;
             text-transform: uppercase; margin: 0 0 14px; }
  .headline { font-size: 40px; line-height: 1.2; margin: 0 0 20px; font-weight: 700; }
  .hook { color: var(--muted); font-size: 20px; margin: 0 0 32px; max-width: 32ch; }
  .cta { display: inline-block; background: var(--accent); color: #fff; text-decoration: none;
         font-weight: 600; padding: 14px 26px; border-radius: 8px; font-size: 17px; width: fit-content; }
  .art { flex: 1 1 38%; background: #f4f6f8; display: flex; align-items: center; justify-content: center; }
  .art img { max-width: 55%; max-height: 55%; object-fit: contain; }
</style>
</head>
<body>
  <div class="card">
    <div class="text">
      <p class="eyebrow">{{company}}</p>
      <h1 class="headline">{{headline}}</h1>
      <p class="hook">{{hook}}</p>
      <a class="cta" href="{{cta_url}}">{{cta_label}}</a>
    </div>
    <div class="art">
      <img src="https://logo.clearbit.com/{{domain}}" onerror="this.style.display='none'">
    </div>
  </div>
</body>
</html>
"""
)
