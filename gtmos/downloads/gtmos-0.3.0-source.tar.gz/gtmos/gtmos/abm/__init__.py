"""ABM planner + asset generators — deterministic, offline, no LLM calls, no
network calls at generation time. Logo URLs are referenced
(https://logo.clearbit.com/<domain>), never fetched. The LinkedIn API push
is a stub gated on LINKEDIN_ACCESS_TOKEN + an explicit typed "PUSH"
confirmation — gtmos never creates a paid campaign without a human typing
approval (see cli_entry.run and creative.push_to_linkedin).

planner.plan(accounts) -> list[AdSetPlan], the shape asset generators consume:
  .accounts            list[dict] — each dict has name/domain, optional pain
  .tier                "one_to_one" | "clustered"
  .estimated_audience  int — LinkedIn matched-audience size estimate
  .targeting           dict — {companies, functions, seniorities, segment_label}
  .sizing_note         str — one honest sentence on why this tier was chosen

pages.render_all(plans, out_dir) -> list[str]     landing pages
creative.render_all(plans, out_dir) -> list[str]  ad creatives + manifest
"""
