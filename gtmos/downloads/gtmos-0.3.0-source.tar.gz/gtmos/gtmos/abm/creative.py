"""Render one LinkedIn ad creative (HTML) per ABM plan + a manifest.

render_all(plans, out_dir) -> list[str] of written creative HTML paths.
Also writes out_dir/creatives-manifest.json: one row per plan with
slug, headline, logo_url, and the target ad set (targeting + estimated
audience) that creative maps to.

push_to_linkedin() is a stub only — see the safety rail in its docstring.
No network call happens anywhere in this module.
"""

from __future__ import annotations

import html
import json
import os
from pathlib import Path

from gtmos.abm.pages import cta_url, slugify
from gtmos.abm.templates import CREATIVE_CARD

DEFAULT_CTA_LABEL = "Get the audit"


def _headline_and_hook(plan) -> tuple[str, str, str]:
    """Returns (display_name, headline, hook) — all pre-escape callers must
    still escape display_name/headline/hook pieces built from account data."""
    account = plan.accounts[0]
    name = str(account.get("name", ""))
    pain = account.get("pain")
    if plan.tier == "clustered":
        targeting = getattr(plan, "targeting", None) or {}
        segment_label = str(targeting.get("segment_label") or "your segment")
        headline = f"{segment_label}, your CRM is leaking pipeline"
        hook = f"Peer companies in {segment_label} lose deals to bad CRM data. Here's the scored proof."
        return segment_label, headline, hook

    headline = f"{name}, your CRM is leaking pipeline"
    if pain:
        hook = f"{pain} is costing you pipeline you can't see. Get the scored report."
    else:
        hook = "Dupes, dead records, stale data — get the scored report on what it's costing you."
    return name, headline, hook


def _render_creative(plan) -> tuple[str, str, str]:
    """Returns (html_out, headline_plain, logo_url)."""
    account = plan.accounts[0]
    domain = account.get("domain") or ""
    display_name, headline, hook = _headline_and_hook(plan)

    card = CREATIVE_CARD
    card = card.replace("{{company}}", html.escape(display_name))
    card = card.replace("{{headline}}", html.escape(headline))
    card = card.replace("{{hook}}", html.escape(hook))
    card = card.replace("{{cta_url}}", html.escape(cta_url(plan)))
    card = card.replace("{{cta_label}}", DEFAULT_CTA_LABEL)
    card = card.replace("{{domain}}", html.escape(domain))

    logo_url = f"https://logo.clearbit.com/{domain}" if domain else ""
    return card, headline, logo_url


def render_all(plans, out_dir: str) -> list[str]:
    creatives_dir = Path(out_dir) / "creatives"
    creatives_dir.mkdir(parents=True, exist_ok=True)

    written: list[str] = []
    manifest: list[dict] = []

    for i, plan in enumerate(plans, start=1):
        if plan.tier == "one_to_one":
            slug = slugify(str(plan.accounts[0].get("name", "")))
        elif plan.tier == "clustered":
            slug = f"cluster-{i}"
        else:
            raise ValueError(f"unknown plan tier: {plan.tier!r}")

        html_out, headline, logo_url = _render_creative(plan)
        out_path = creatives_dir / f"{slug}.html"
        out_path.write_text(html_out)
        written.append(str(out_path))

        manifest.append(
            {
                "slug": slug,
                "headline": headline,
                "logo_url": logo_url,
                "target_ad_set": {
                    "targeting": getattr(plan, "targeting", None) or {},
                    "estimated_audience": getattr(plan, "estimated_audience", None),
                },
            }
        )

    manifest_path = Path(out_dir) / "creatives-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))

    return written


def push_to_linkedin(manifest_path: str) -> int:
    """Stub for pushing creatives to the LinkedIn Marketing API. NOT wired
    into render_all or any CLI command — recommend-first doctrine: gtmos
    never creates a paid campaign without a human explicitly approving it.

    Safety rail (do not weaken):
      1. Requires LINKEDIN_ACCESS_TOKEN in the environment — no token, no push.
      2. Requires the operator to type the literal word PUSH at a prompt.
    Anything short of both conditions is a no-op that prints what *would*
    happen. There is no live API call in this function today; it exists so
    a future implementation has the guard rail already in place.
    """
    token = os.environ.get("LINKEDIN_ACCESS_TOKEN")
    if not token:
        print("[gtmos abm] LINKEDIN_ACCESS_TOKEN not set — refusing to push. "
              "This is a plan-only run; import the manifest into Campaign "
              "Manager manually or set the token once the LinkedIn API "
              "application is approved.")
        return 1

    print(f"[gtmos abm] About to push creatives from {manifest_path} to LinkedIn. "
          "This creates a LIVE ad campaign that can spend real money.")
    confirmation = input('Type PUSH (all caps) to confirm, anything else cancels: ')
    if confirmation != "PUSH":
        print("[gtmos abm] Not confirmed — no push performed.")
        return 1

    # NOTE: no actual LinkedIn Marketing API call is implemented yet. When
    # the API application (docs/linkedin-api-application.md) is approved,
    # the campaign-group/campaign/creative POST calls go here, guarded by
    # the two checks above — never relax them.
    print("[gtmos abm] LinkedIn push not yet implemented (API application "
          "pending). No campaign was created.")
    return 0
