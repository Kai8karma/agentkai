"""`gtmos abm` handler. Loads accounts, plans ad sets, renders pages/creative,
writes the campaign plan + summary. No LLM calls — deterministic end to end.

--push is a recommend-first safety rail, not a real integration: gtmos never
creates a paid LinkedIn campaign without a human typing "PUSH" at a prompt,
and even then there is no live API call yet (see docs/linkedin-api-application.md).
"""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from gtmos.abm import planner

MISSING_TOKEN_MESSAGE = (
    "abm: --push requires LinkedIn Advertising API approval. Set "
    "LINKEDIN_ACCESS_TOKEN once approved — see docs/linkedin-api-application.md. "
    "Until then, import the generated Campaign-Manager-ready artifacts "
    "(pages, creatives, campaign-plan.json) into Campaign Manager manually."
)


def _load_accounts(path: str) -> list[dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path} is not valid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise ValueError(f"{path} must contain a JSON array of accounts")
    for i, account in enumerate(data):
        if not isinstance(account, dict) or not account.get("name") or not account.get("domain"):
            raise ValueError(f"account at index {i} missing required 'name'/'domain'")
    return data


def _render_assets(module_name: str, plans: list, out_dir: str) -> list[str]:
    try:
        module = __import__(module_name, fromlist=["render_all"])
    except ImportError:
        print(f"abm: {module_name} not available yet — skipping")
        return []
    return module.render_all(plans, out_dir)


def _write_plan_json(plans: list, out_dir: Path) -> Path:
    path = out_dir / "campaign-plan.json"
    path.write_text(json.dumps([asdict(p) for p in plans], indent=2), encoding="utf-8")
    return path


def _write_summary(
    plans: list,
    out_dir: Path,
    total_accounts: int,
    page_paths: list[str],
    creative_paths: list[str],
) -> Path:
    one_to_one = [p for p in plans if p.tier == "one_to_one"]
    clustered = [p for p in plans if p.tier == "clustered"]
    total_audience = sum(p.estimated_audience for p in plans)

    lines: list[str] = []
    lines.append("# ABM Campaign Plan Summary")
    lines.append("")
    lines.append(f"_Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}_")
    lines.append("")
    lines.append(
        f"{total_accounts} accounts -> {len(plans)} ad sets "
        f"({len(one_to_one)} one_to_one, {len(clustered)} clustered)."
    )
    lines.append("")

    lines.append("## Ad sets")
    lines.append("")
    lines.append("| Ad set | Tier | Accounts | Est. audience | Sizing note |")
    lines.append("|---|---|---|---|---|")
    for i, p in enumerate(plans, start=1):
        names = ", ".join(a["name"] for a in p.accounts)
        lines.append(f"| {i} | {p.tier} | {names} | {p.estimated_audience} | {p.sizing_note} |")
    lines.append("")

    lines.append("## Totals")
    lines.append("")
    lines.append(f"- Total accounts: {total_accounts}")
    lines.append(f"- One-to-one ad sets: {len(one_to_one)}")
    lines.append(f"- Clustered ad sets: {len(clustered)}")
    lines.append(f"- Total estimated audience across ad sets: {total_audience}")
    lines.append("")

    lines.append("## Assets")
    lines.append("")
    lines.append(f"- Pages: {len(page_paths)} written" if page_paths else "- Pages: not available yet")
    lines.append(f"- Creatives: {len(creative_paths)} written" if creative_paths else "- Creatives: not available yet")
    lines.append("")

    lines.append("## Next steps")
    lines.append("")
    lines.append(
        "Push requires LinkedIn API approval — see docs/linkedin-api-application.md. "
        "Until then, import the generated pages/creatives/campaign-plan.json into "
        "Campaign Manager manually."
    )
    lines.append("")

    path = out_dir / "CAMPAIGN-SUMMARY.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _handle_push() -> int:
    token = os.environ.get("LINKEDIN_ACCESS_TOKEN")
    if not token:
        print(MISSING_TOKEN_MESSAGE)
        return 2

    print(
        "abm: --push would push the generated campaign plan (ad sets, targeting, "
        "creatives) to LinkedIn Campaign Manager via the Advertising API. This "
        "would create a LIVE ad campaign that can spend real money."
    )
    confirmation = input('Type PUSH (all caps) to confirm, anything else cancels: ')
    if confirmation != "PUSH":
        print("abm: push not confirmed, aborting")
        return 3

    print("abm: API client not yet implemented — approval pending")
    return 3


def run(args: argparse.Namespace) -> int:
    try:
        accounts = _load_accounts(args.accounts)
    except ValueError as exc:
        print(f"abm: {exc}")
        return 1

    if not accounts:
        print("abm: no accounts found in input")
        return 1

    plans = planner.plan(accounts)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    page_paths = _render_assets("gtmos.abm.pages", plans, str(out_dir))
    creative_paths = _render_assets("gtmos.abm.creative", plans, str(out_dir))

    plan_path = _write_plan_json(plans, out_dir)
    _write_summary(plans, out_dir, len(accounts), page_paths, creative_paths)

    one_to_one = sum(1 for p in plans if p.tier == "one_to_one")
    clustered = sum(1 for p in plans if p.tier == "clustered")
    print(
        f"abm: {len(accounts)} accounts -> {len(plans)} ad sets "
        f"({one_to_one} one_to_one, {clustered} clustered) — plan: {plan_path}"
    )

    if args.push:
        return _handle_push()

    return 0
