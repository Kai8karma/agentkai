"""Single chokepoint for all LLM (claude CLI) calls made by GTM OS.

Every command that needs narrative/drafting output MUST go through
run_harness(). Scoring/deterministic logic never touches this module.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

# Shared bound for any command that loops on harness calls (e.g. the draft
# command's judge-revision loop). run_harness() itself is one call.
MAX_ITERATIONS = 3

RECEIPTS_PATH = Path.home() / ".gtmos" / "receipts.jsonl"


def _append_receipt(command: str, prompt_chars: int, duration_s: float, exit_code: int) -> None:
    RECEIPTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    receipt = {
        "ts": time.time(),
        "command": command,
        "prompt_chars": prompt_chars,
        "duration_s": duration_s,
        "exit": exit_code,
    }
    with RECEIPTS_PATH.open("a") as f:
        f.write(json.dumps(receipt) + "\n")


def run_harness(
    command: str,
    prompt: str,
    allowed_tools: list[str] | None,
    timeout: int = 180,
    dry_run: bool = False,
    bare: bool = False,
) -> str:
    """Shell out to the claude CLI and return its text output.

    `command` is a short label for the caller (e.g. "audit-narrative"),
    recorded in the receipt log for traceability. It is not passed to
    claude directly.
    """
    # bare=True adds --bare: skips CLAUDE.md/settings/MCP discovery, ~10x
    # faster startup. Only for pure-text calls — every current command needs
    # the user's MCP servers (brain, Apollo, HubSpot), so default stays False.
    argv = ["claude", "-p", prompt, "--output-format", "text"]
    if bare:
        argv.insert(1, "--bare")
    if allowed_tools:
        argv += ["--allowedTools", ",".join(allowed_tools)]

    if dry_run:
        print(f"[dry-run] would call: {' '.join(argv[:2])} <prompt:{len(prompt)} chars> ...")
        return ""

    # CRITICAL QUIRK: USER must not propagate to claude subprocess or
    # keychain auth 401s.
    env = {k: v for k, v in os.environ.items() if k != "USER"}

    start = time.monotonic()
    exit_code = 1
    output = ""
    try:
        result = subprocess.run(
            argv,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        exit_code = result.returncode
        output = result.stdout
        if exit_code != 0 and result.stderr:
            output = output or result.stderr
    finally:
        duration = time.monotonic() - start
        _append_receipt(command, len(prompt), duration, exit_code)

    return output
