DRAFT — requires review by qualified counsel before customer-facing use.

# GTM OS — License

Copyright © 2026 Kai (kaikarma). All rights reserved.

This software ("GTM OS") and its accompanying documentation are the
proprietary property of kaikarma. No license to use, copy, modify, merge,
publish, distribute, sublicense, or sell copies of this software is
granted except as expressly set out below.

## Commercial license

Use of GTM OS by a team or organization requires a **separate, signed
order form or End User License Agreement (EULA)** with kaikarma. That
agreement — not this file — governs the scope of your license (seats,
term, permitted use) once executed.

## Evaluation license

Absent a signed order form, GTM OS may be installed and run for
**evaluation purposes only, for a period of 30 days** from first
installation. Evaluation use is limited to assessing the software for a
potential purchase and may not be used to generate production output,
outreach, or reporting relied upon for business decisions beyond that
purpose.

## Restrictions

- No redistribution, in source or compiled form, in whole or in part.
- No sublicensing, resale, or transfer of this software to any third
  party.
- No removal or alteration of copyright, license, or attribution notices.
- No use beyond the evaluation period without an executed commercial
  license.

## No warranty

THIS SOFTWARE IS PROVIDED "AS IS," WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.
IN NO EVENT SHALL KAIKARMA BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER
LIABILITY ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE OR THE
USE OR OTHER DEALINGS IN THE SOFTWARE.

## Contact

Licensing inquiries: contact kaikarma directly for an order form.
