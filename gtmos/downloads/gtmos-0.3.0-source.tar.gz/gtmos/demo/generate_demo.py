"""Deterministic generator for the GTM OS demo portal.

Produces 500 fictional B2B contact records (Indian + US companies, all
made up) with a realistic CRM dirt profile, then writes demo/demo-portal.json.
Seeded on random.Random(42) and a hardcoded "now" anchor so re-running this
script always produces byte-identical output — no wall-clock dependency.

Run: python3 demo/generate_demo.py
Then score it with the real engine: gtmos audit --input demo/demo-portal.json
"""

from __future__ import annotations

import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from gtmos.audit.engine import DISPOSABLE_DOMAIN_MARKERS, JUNK_VALUES

SEED = 42
N = 500
# Anchor "now" for all date math below — NOT datetime.now(). Keeps this
# generator's output byte-identical no matter what day it's run on. The
# real pipeline (gtmos audit) scores freshness against the actual wall
# clock, so this only lines up exactly on 2026-07-09; that's fine, it's
# a demo fixture, not a live system.
NOW = datetime(2026, 7, 9, 0, 0, 0, tzinfo=timezone.utc)

OUT_PATH = Path(__file__).parent / "demo-portal.json"

# --- fictional company pool (obviously synthetic, no real company names) ---

US_COMPANIES = [
    "Meridian Gearworks", "Cobalt Harbor Logistics", "Brightline Analytics",
    "Fenwick Alloy Systems", "Cascade Ridge Foods", "Sable Peak Robotics",
    "Ironwood Freight Co", "Lucent Grove Media", "Tanner Bay Materials",
    "Halcyon Field Energy", "Pinehollow Data Systems", "Redshale Manufacturing",
    "Vantage Crest Capital", "Norwood Trail Chemicals", "Amberline Aerospace",
    "Driftwood Kinetics", "Sterling Bluff Textiles", "Kestrel Point Biotech",
    "Copperlane Industrial", "Wrenfield Instruments",
]

INDIA_COMPANIES = [
    "Meghna Precision Tools", "Konkan Steelworks", "Rajdhani Polymer Industries",
    "Deccan Circuit Systems", "Malabar Agro Exports", "Vindhya Forge & Foundry",
    "Ashoka Freight Solutions", "Nilgiri Textiles", "Ganges Valley Electronics",
    "Sahyadri Industrial Gases", "Brahmaputra Logistics", "Kaveri Precision Castings",
    "Aravalli Mineral Processing", "Godavari Pharma Components", "Chambal Engineering Works",
    "Satpura Auto Ancillaries", "Yamuna Cold Chain Systems", "Vindhyachal Ceramics",
    "Coromandel Packaging Co", "Thar Renewable Systems",
]

US_FIRST = ["James", "Emily", "Michael", "Sarah", "David", "Laura", "Robert", "Jessica",
            "William", "Ashley", "Daniel", "Megan", "Matthew", "Rachel", "Andrew", "Nicole",
            "Joshua", "Amanda", "Ryan", "Brittany"]
US_LAST = ["Sullivan", "Brennan", "Whitfield", "Caldwell", "Ferris", "Donovan", "Hargrove",
           "Kowalski", "Blackwood", "Pemberton", "Ashford", "Wexler", "Marsh", "Talbot",
           "Hollis", "Kessler", "Brant", "Fowler", "Gaines", "Merritt"]

IN_FIRST = ["Priya", "Rohit", "Ananya", "Arjun", "Kavya", "Vivaan", "Meera", "Aditya",
            "Tanvi", "Karthik", "Isha", "Rahul", "Sneha", "Aryan", "Divya", "Nikhil",
            "Pooja", "Sameer", "Riya", "Varun"]
IN_LAST = ["Sharma", "Menon", "Reddy", "Kapoor", "Iyer", "Chauhan", "Krishnan", "Bhatt",
           "Saxena", "Rao", "Nair", "Malhotra", "Desai", "Pillai", "Verma", "Joshi",
           "Ansari", "Gupta", "Naidu", "Bose"]

JOB_TITLES = [
    "VP Sales", "Director of Operations", "Procurement Manager", "Head of Marketing",
    "Plant Manager", "Business Development Manager", "Chief Financial Officer",
    "Regional Sales Director", "Supply Chain Lead", "IT Manager", "Account Executive",
    "Product Manager", "Purchasing Head", "Operations Analyst", "General Manager",
    "VP Engineering", "Category Manager", "Customer Success Lead", "Founder & CEO", "COO",
]

OWNERS = ["Asha Rao", "Daniel Kim", "Priya Menon", "Marcus Webb", "Sofia Alvarez", "Rohit Batra"]

LIFECYCLE_STAGES = ["subscriber", "lead", "marketingqualifiedlead", "salesqualifiedlead",
                    "opportunity", "customer"]
LIFECYCLE_WEIGHTS = [10, 30, 20, 15, 15, 10]

JUNK_LOCAL_PARTS = sorted(v for v in JUNK_VALUES if v and v not in {"-", ""})
JUNK_DOMAIN_LABELS = ["example", "test", "email", "domain"]
DISPOSABLE_DOMAIN = DISPOSABLE_DOMAIN_MARKERS[0] + ".com"  # "mailinator.com"


def slugify(name: str) -> str:
    return "".join(ch for ch in name.lower() if ch.isalnum())


def build_companies() -> list[dict]:
    companies = []
    for name in US_COMPANIES:
        companies.append({"name": name, "domain": f"{slugify(name)}.com", "region": "us"})
    for name in INDIA_COMPANIES:
        tld = "in" if len(companies) % 2 == 0 else "com"
        companies.append({"name": name, "domain": f"{slugify(name)}.{tld}", "region": "in"})
    return companies


def make_phone(rng: random.Random, region: str) -> str:
    if region == "us":
        return f"+1 {rng.randint(200,989)} {rng.randint(200,989)} {rng.randint(1000,9999)}"
    return f"+91 {rng.randint(70000,99999)} {rng.randint(10000,99999)}"


def make_date(days_ago: int) -> str:
    return (NOW - timedelta(days=days_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")


def sample_freshness_days(rng: random.Random) -> int:
    """Baseline (non-flagged) freshness spread — most B2B contacts aren't
    touched every month, so this deliberately skews older than 'perfect'."""
    band = rng.choices(
        population=[(1, 30), (31, 90), (91, 180), (181, 365)],
        weights=[20, 25, 30, 25],
        k=1,
    )[0]
    return rng.randint(*band)


def build_base_record(rng: random.Random, idx: int, companies: list[dict]) -> dict:
    region = rng.choice(["us", "in"])
    if region == "us":
        first, last = rng.choice(US_FIRST), rng.choice(US_LAST)
    else:
        first, last = rng.choice(IN_FIRST), rng.choice(IN_LAST)
    company = rng.choice(companies)
    email = f"{first.lower()}.{last.lower()}{idx}@{company['domain']}"
    phone_state = rng.choices(["missing", "malformed", "ok"], weights=[45, 15, 40], k=1)[0]
    has_jobtitle = rng.random() > 0.35  # ~35% baseline missing job title
    freshness_days = sample_freshness_days(rng)
    stage = rng.choices(LIFECYCLE_STAGES, weights=LIFECYCLE_WEIGHTS, k=1)[0]
    createdate_days = freshness_days + rng.randint(30, 700)

    if phone_state == "missing":
        phone = None
    elif phone_state == "malformed":
        phone = str(rng.randint(100, 99999))  # 3-5 digits, fails the 7-15 digit check
    else:
        phone = make_phone(rng, company["region"])

    return {
        "email": email,
        "firstname": first,
        "lastname": last,
        "company": company["name"],
        "jobtitle": rng.choice(JOB_TITLES) if has_jobtitle else None,
        "phone": phone,
        "lifecyclestage": stage,
        "last_activity_date": make_date(freshness_days),
        "owner": rng.choice(OWNERS),
        "createdate": make_date(createdate_days),
    }


def apply_junk_email(rng: random.Random, record: dict, idx: int) -> None:
    """Format-valid-but-placeholder, malformed, or disposable-domain email.
    No phone on file either -> fails BOTH reachability checks -> capped dead.

    Each variant keeps whichever side of the local-part/domain junk check
    is load-bearing fixed (so it still trips engine._valid_email), while
    varying the other side by idx so 40 separate dead records don't
    accidentally collapse into one giant coincidental dupe cluster.
    """
    kind = rng.choice(["placeholder_local", "placeholder_domain", "malformed", "disposable"])
    if kind == "placeholder_local":
        # local part must be an exact JUNK_VALUES token; domain can vary freely
        record["email"] = f"{rng.choice(JUNK_LOCAL_PARTS)}@lead{idx}corp.com"
    elif kind == "placeholder_domain":
        # domain's first label must be an exact junk token; local can vary freely
        record["email"] = f"contact{idx}@{rng.choice(JUNK_DOMAIN_LABELS)}.com"
    elif kind == "malformed":
        # fails the email regex outright regardless of idx suffix
        record["email"] = rng.choice([f"not-an-email-{idx}", f"john.doe{idx}@", f"missing-at-sign-{idx}.com"])
    else:
        # disposable-domain check is substring-based; local part can vary freely
        record["email"] = f"lead{idx}@{DISPOSABLE_DOMAIN}"
    record["phone"] = None


def apply_stale(rng: random.Random, record: dict) -> None:
    days = rng.randint(366, 900)
    record["last_activity_date"] = make_date(days)


def apply_ownerless(record: dict) -> None:
    record["owner"] = None


def apply_lifecycle_inconsistent(rng: random.Random, record: dict) -> None:
    record["lifecyclestage"] = rng.choice(["customer", "opportunity"])
    days = rng.randint(366, 900)
    record["last_activity_date"] = make_date(days)


def build_dupe_clusters(rng: random.Random, records: list[dict], excluded: set[int], target_participants: int) -> list[list[int]]:
    """Mutate records in place to create dupe clusters find_dupes() will catch.
    Mixes exact-email dupes and fuzzy lastname+company dupes."""
    pool = [i for i in range(len(records)) if i not in excluded]
    rng.shuffle(pool)
    clusters: list[list[int]] = []
    used: set[int] = set()
    participants = 0
    kind_toggle = 0

    while participants < target_participants and pool:
        size = rng.choices([2, 3], weights=[70, 30], k=1)[0]
        group = []
        while len(group) < size and pool:
            candidate = pool.pop()
            if candidate not in used:
                group.append(candidate)
        if len(group) < 2:
            break
        used.update(group)
        source_idx, *target_idxs = group

        if kind_toggle % 2 == 0:
            # exact-email cluster: same email, re-entered with different job title
            shared_email = records[source_idx]["email"]
            for ti in target_idxs:
                records[ti]["email"] = shared_email
                records[ti]["jobtitle"] = rng.choice(JOB_TITLES)
        else:
            # fuzzy lastname+company cluster: same person, different email each time
            shared_lastname = records[source_idx]["lastname"]
            shared_company = records[source_idx]["company"]
            for ti in target_idxs:
                records[ti]["lastname"] = shared_lastname
                records[ti]["company"] = shared_company
                domain_choice = rng.choice(["gmail.com", "outlook.com", "yahoo.com"])
                records[ti]["email"] = f"{records[ti]['firstname'].lower()}.{shared_lastname.lower()}{ti}@{domain_choice}"

        kind_toggle += 1
        clusters.append(group)
        participants += len(group)

    return clusters


def generate() -> list[dict]:
    rng = random.Random(SEED)
    companies = build_companies()

    records = [build_base_record(rng, i, companies) for i in range(N)]

    all_idx = list(range(N))
    junk_email_idx = set(rng.sample(all_idx, round(N * 0.12)))
    stale_idx = set(rng.sample(all_idx, round(N * 0.22)))
    ownerless_idx = set(rng.sample(all_idx, round(N * 0.12)))
    lifecycle_idx = set(i for i in rng.sample(all_idx, round(N * 0.10)) if i not in junk_email_idx)

    for i in junk_email_idx:
        apply_junk_email(rng, records[i], i)
    for i in stale_idx:
        apply_stale(rng, records[i])
    for i in ownerless_idx:
        apply_ownerless(records[i])
    for i in lifecycle_idx:
        apply_lifecycle_inconsistent(rng, records[i])

    # Dupe clusters: keep away from the junk-email and lifecycle buckets so
    # each dirt category stays legible in the report as its own story beat.
    dupe_excluded = junk_email_idx | lifecycle_idx
    build_dupe_clusters(rng, records, dupe_excluded, target_participants=round(N * 0.10))

    # createdate isn't scored by the engine, but recompute it last, from
    # each record's FINAL last_activity_date, so stale/lifecycle mutations
    # (which rewrite last_activity_date after the base record is built)
    # don't leave a record that was apparently "created after" its last
    # activity — sloppy generator artifact, not a real CRM pattern.
    for r in records:
        last_activity = datetime.fromisoformat(r["last_activity_date"].replace("Z", "+00:00"))
        days_ago = (NOW - last_activity).days
        r["createdate"] = make_date(days_ago + rng.randint(30, 700))

    return records


def main() -> None:
    records = generate()
    OUT_PATH.write_text(json.dumps(records, indent=2), encoding="utf-8")
    print(f"wrote {len(records)} records to {OUT_PATH}")


if __name__ == "__main__":
    main()
