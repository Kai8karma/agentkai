DRAFT — requires review by qualified counsel before customer-facing use.

# Privacy Policy — GTM OS

_Last updated: 2026-07-13_

This policy describes what data GTM OS touches, where it flows, and — the
short version — why almost none of it ever reaches us (kaikarma, the vendor
that builds GTM OS). GTM OS is software you run on your own machine, against
your own HubSpot token, using your own Claude Code / Anthropic auth. We do
not operate a server that your CRM data passes through.

## 1. Data categories touched

GTM OS reads and processes CRM contact and deal fields when you run its
commands: name, email, phone, company, job title, industry, employee count,
lifecycle stage, owner, activity timestamps, and deal-stage/value fields
(see `docs/integrity-score-methodology.md` for the exact fields the audit
engine scores). Harness commands (`prospect`, `stalk`, `draft`, `brief`)
additionally read whatever context your Claude Code session's MCP servers
expose (e.g. HubSpot, Apollo, calendar, brain memory) at your direction.

## 2. Where that data flows

**It flows to your own machine's memory and disk, and nowhere we operate.**
Concretely:

- **HubSpot API** — GTM OS calls the HubSpot REST API directly from your
  machine, using a token you hold in `GTMOS_HUBSPOT_TOKEN`. This is a
  direct connection between your machine and HubSpot's servers. We are not
  in the middle of it.
- **The `claude` CLI** — harness commands (`gtmos/harness.py`, function
  `run_harness()`) shell out to a local `claude` subprocess using your own
  Anthropic authentication. This is a local process call, not a network
  call to us.
- **Local disk** — audit reports, funnel output, play state, and the
  receipts log are written to files on your machine (`report.json`,
  `./funnel-out/`, `./play-out/`, `~/.gtmos/receipts.jsonl`, etc.).

GTM OS ships as source you install and run yourself (`uv pip install -e .`
/ `pip install -e .`). There is no GTM OS server, no hosted API, and no
telemetry call built into the tool. We (the vendor) receive **nothing** at
runtime — no contact records, no deal data, no prompts, no receipts —
unless you separately choose to send us something (e.g. a support email
with a file attached).

## 3. Subprocessors

Because GTM OS runs entirely on your infrastructure, the only third
parties that ever see your CRM data are ones **you** already chose and
authenticated to, using **your own accounts and credentials**:

- **HubSpot** — your CRM of record; governed by your existing HubSpot
  agreement and DPA.
- **Anthropic** — via your own Claude Code / `claude` CLI authentication;
  governed by your existing Anthropic terms and DPA.
- **Any MCP server you've authorized** — e.g. Apollo, LinkedIn — again,
  under your own account and their own terms.

We (kaikarma, the vendor) are not a subprocessor of your CRM data in the
traditional sense, because your data is never routed through infrastructure
we operate. See `docs/DPA-POSTURE.md` for the procurement-facing version of
this argument.

## 4. What the vendor does and does not receive

- **At runtime: nothing.** No CRM data, no prompts, no receipts, no usage
  telemetry is transmitted from the tool to kaikarma. There is no
  phone-home code path in this codebase.
- **If you contact support:** anything you choose to paste into an email,
  ticket, or bug report (e.g. a redacted report.json, a stack trace) is
  received by us as an ordinary support artifact, exactly as if you'd
  emailed us a screenshot. We do not solicit CRM exports as part of
  support and recommend redacting personal data before sending anything.

## 5. The receipts log — exactly what it contains

Every harness command call (`prospect`, `stalk`, `draft`, `brief`, and
`play --draft`) writes one line to `~/.gtmos/receipts.jsonl` on your
machine. Per `gtmos/harness.py::_append_receipt()`, each line is a JSON
object with exactly these fields:

| Field | Contents |
|---|---|
| `ts` | Unix timestamp of the call |
| `command` | short label for the caller, e.g. `"audit-narrative"` (not the CRM data itself) |
| `prompt_chars` | the **character count** of the prompt sent to `claude` — an integer, not the prompt text |
| `duration_s` | how long the subprocess call took |
| `exit` | the subprocess exit code |

**The receipts log never contains prompt text, CRM field values, or model
output.** This is verified directly against the source: `run_harness()`
constructs the receipt from `len(prompt)` (a length, not the string) and
never writes `prompt`, `output`, or any CRM record to
`RECEIPTS_PATH`. The log is a local audit trail of *that a call happened,
how big it was, how long it took, and whether it succeeded* — not of its
contents. It lives on your disk; we never see it unless you choose to
share it.

## 6. Data retention

Retention is entirely customer-controlled, because all state lives in
files on your machine:

- Audit reports, funnel output, play state, config (`gtmos-team.json`) —
  retained until you delete them.
- `~/.gtmos/receipts.jsonl` — grows until you rotate or delete it; GTM OS
  does not currently auto-rotate this file (**FIXME**: no size/age-based
  rotation exists in `harness.py` today — if you need retention limits,
  manage the file yourself, e.g. via cron/logrotate).
- HubSpot and Anthropic have their own retention policies for data that
  transits their APIs under your account — see their respective DPAs.

## 7. GDPR / DPDP (India) posture

Under GDPR and India's DPDP Act, the roles are:

- **You (the customer)** are the **data controller** for your CRM data,
  and — because GTM OS executes entirely on infrastructure you provision
  and control — you are also the **processor host**: the processing
  happens on your machine, under your operational control.
- **kaikarma (the vendor)** ships **software**, not a processing service.
  We do not receive, store, transmit, or otherwise process your personal
  data as defined under GDPR Art. 4(2) or DPDP, because no personal data
  flows through infrastructure we operate or control.
- Your obligations toward data subjects (access, deletion, rectification
  requests) are fulfilled the same way they are today: directly in
  HubSpot, since that remains your system of record. GTM OS does not
  create a second copy of record outside files you generate yourself.

This is an architectural claim, not a certification — see
`docs/DPA-POSTURE.md` for what we will and won't sign to formalize it, and
have your counsel confirm this framing fits your specific regulatory
obligations.

## Questions

security@kaikarma (see `SECURITY.md` for scope and response targets).
