# The CRM Integrity Audit — $3,000, 5 business days

Most "CRM health check" vendors log into your portal, point at some red
numbers, and hand you a slide graded on a curve nobody can check. This one
is different for one reason: **the scoring methodology is
[published in full](integrity-score-methodology.md)** — five weighted
dimensions, the duplicate-detection rules, the $-leak formula, all of it.
You can reimplement it yourself if you want to. Nothing about the number we
hand you is a black box.

## 1. The offer

A fixed-scope, fixed-price audit of your CRM data. **$3,000. 5 business
days. No subscription, no lock-in.** We score every contact and company
record, find every duplicate, and tell you in dollars what bad data is
costing your pipeline.

## 2. What you get

- **A scored report** — composite CRM Integrity Score (0–100, letter grade
  A–F) with the full decomposition: completeness, validity, freshness,
  ownership, consistency. Methodology is the public doc linked above —
  nothing hidden in the scoring.
- **Duplicate clusters** — exact-match (same email) and probable
  fuzzy-match (same surname + company) clusters, reported for you to merge.
  We don't auto-merge; that's a decision you make with the report in hand.
- **A $-leak estimate** — the share of records that are unreachable by any
  channel (no valid email, no valid phone), translated into a dollar
  figure using your actual ACV. Order-of-magnitude, not a forecast —
  see the model in the methodology doc.
- **A top-10 fix list** — the ten highest-leverage fixes ranked by dollar
  and workflow impact, not just the ten worst-looking records.
- **A 60-minute readout call** — walk the report live, answer questions,
  leave with a prioritized punch list.

## 3. How it runs

The audit runs **on your infrastructure, with your API keys.** Your CRM
data never leaves your machines — there's no third-party portal, no data
lake, no vendor holding a copy of your customer list after the engagement
ends. That's a tiebreaker for security-conscious teams, not the headline:
the headline is the recovered pipeline this report puts a number on.

## 4. The guarantee

If the audit doesn't surface at least **$30,000 in recoverable pipeline**
(via the $-leak estimate), **the audit is free.** We only get paid if the
number is real.

## 5. Free teaser

Not ready to commit $3,000 sight unseen? Send 10 records — we'll score
them against the same public methodology and hand back the result, no
charge. It's the exact same engine, just a smaller sample.

## 6. Upgrade path (available post-audit)

For teams that want the integrity score maintained instead of re-measured
once: a **$10,000/mo Integrity Retainer** — weekly re-audit, drift alerts
when the score moves, and a standing remediation loop. This is offered
*after* the audit, once you've seen the report and the methodology firsthand
— never sold cold.

## FAQ

**Does this only work with HubSpot?**
The audit is built against HubSpot's contact/company model first; the
scoring methodology itself is CRM-agnostic and portable to other platforms
on request.

**What access do you need?**
Read access via API key/OAuth scoped to contacts and companies. No admin
rights, no write access needed to run the audit.

**How is the score actually computed?**
Five weighted dimensions (completeness 0.30, validity 0.25, freshness 0.25,
ownership 0.10, consistency 0.10) — published in full at
[integrity-score-methodology.md](integrity-score-methodology.md), including
the duplicate-detection rules and the $-leak formula. Deterministic
scoring, no model judgment calls.

**What if our data is actually fine?**
Then the report says so — a high score is a valid outcome, and it's the
cheapest confirmation you'll ever get that your CRM isn't secretly bleeding
pipeline. The guarantee stands either way.

**Who sees our data?**
Nobody outside the engagement. The audit runs on your infrastructure with
your keys — we never hold a copy of your customer data after the report is
delivered.

---

*Demo data referenced in any accompanying materials (sample scores, sample
reports) uses fictional companies and is clearly labeled as demo data —
no real client names or logos.*
