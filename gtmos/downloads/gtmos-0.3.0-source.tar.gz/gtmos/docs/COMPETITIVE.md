# GTM OS vs the field — capability position (2026-07-09)

Source: full teardown of Baseloop (baseloop.io) and Oxygen (oxygen-agent.com),
2026-07-09 (kai-brain mem 1349). Every row is either **parity**, **wedge**
(we have it, they don't), or **deferred** (they have it, we deliberately
don't — with the reason). No row is an unacknowledged gap.

## Wedge rows — verified open, we ship them

| Capability | Baseloop | Oxygen | GTM OS |
|---|---|---|---|
| Standalone CRM integrity audit (diagnostic product with published methodology) | ✗ dedupe-on-sync only | ✗ tagline only, no mechanism | ✓ `gtmos audit` — deterministic 5-dimension score, dupe penalty, $-leak model, open methodology doc |
| Self-hosted / zero data egress | ✗ cloud SaaS | ✗ "we host it for you" | ✓ runs on your machine, your keys; score path has zero network |
| Actual installable CLI | ✗ hosted web app + skill files | ✗ hosted web app + skill files | ✓ `pip install` → `gtmos` binary |
| Compounding memory across runs | ✗ stateless re-runs | ✗ stateless re-runs | ✓ outcomes loop (`gtmos outcomes`) writes win/loss to persistent brain; scoring context survives between engagements |
| Cost observability tied to every LLM call | ✗ | partial (credits, not per-action receipts) | ✓ every harness call receipted to `~/.gtmos/receipts.jsonl` |

## Parity rows

| Capability | Them | GTM OS |
|---|---|---|
| Runs from Claude Code | both | ✓ harness commands dispatch through `claude` CLI |
| HubSpot | both | ✓ direct REST (customer token) + offline JSON |
| AI outreach drafting | both | ✓ `gtmos draft` with voice-fingerprint + eval gate |

## Deferred rows — their game, deliberately not played (30-day doctrine: no feature race)

| Capability | Why deferred |
|---|---|
| 40–50-provider enrichment waterfall | Funded arms race; enters day 60+ only if audit clients pull it |
| Native multichannel sequencer | Routes exist via harness + user's own tools; native = post-revenue |
| Credit pricing / self-serve PLG | Service-first motion: $3k audit ON the product is the revenue vehicle |
| Salesforce native | Neither competitor has it either (Oxygen: none; Baseloop: partial) — open lane, sequenced after HubSpot case study |

## Watch list

- **ColdIQ** — now a product company (unified data API, 700+ endpoints, skills directory). Third builder-lane player. Needs dedicated teardown before day 30.
- **gtm.ai (ZoomInfo)** and **Highspot GTM Agent** — incumbents entering the category; validates it, crowds the tagline space.
