# `gtmos abm` — account-based marketing, plan-first

`gtmos abm` turns a list of target accounts into a full ABM campaign kit —
landing pages, ad creatives, and a LinkedIn ad-set plan with matched-audience
sizing — entirely offline, entirely deterministic. No LLM call is involved
(unlike `draft` / `prospect` / `stalk`, this command does not touch
`gtmos/harness.py`): the same input JSON always produces the same output.

It is a **two-stage flow**: `plan` (always safe, no network, no spend) and
`push` (gated behind an explicit human approval, see below). Everything in
stage one is designed to be usable on its own — most runs never reach stage
two, because Campaign Manager's manual CSV/creative import works fine and
doesn't need LinkedIn API approval at all.

## Usage

```
python3 -m gtmos.cli abm --accounts accounts.json --out ./abm-out
python3 -m gtmos.cli abm --accounts accounts.json --out ./abm-out --push
```

| flag | meaning |
|---|---|
| `--accounts FILE` | required. JSON array of target accounts (schema below). |
| `--out DIR` | output directory (default `./abm-out`). Created if missing. |
| `--push` | attempt the LinkedIn API push after planning. Requires `LINKEDIN_ACCESS_TOKEN` **and** a typed `PUSH` confirmation — see Spend safety. |

## Input schema

A JSON array of account objects:

```json
{
  "name": "Meridian Freight Systems",
  "domain": "meridianfreightsystems.com",
  "employee_count": 8000,
  "industry": "Logistics",
  "pain": "manual load-matching across five regional CRMs post-merger"
}
```

| field | required | notes |
|---|---|---|
| `name` | yes | used for page/creative copy and the landing-page slug |
| `domain` | no | used to build a Clearbit logo URL (`https://logo.clearbit.com/<domain>`) — **never fetched**, only referenced, so generation stays offline and works even for domains with no logo on file |
| `employee_count` | no | drives the tiering/clustering decision below; `null`/missing is treated as unknown, not zero, and the account still gets placed (never crashes the planner) |
| `industry` | no | informs clustering + creative copy |
| `pain` | no | a real, specific pain point — used verbatim (HTML-escaped) in page/creative copy; falls back to generic copy when absent |

See `tests/fixtures/abm_accounts.json` for a worked example, including one
account with an unknown `employee_count` and one with an `&` in its name
(escaping is a pinned test — company names are untrusted input and go
through `html.escape()` before landing in any generated page or creative).

## The audience-floor / clustering model

LinkedIn Matched Audiences (company-list targeting) won't reliably serve an
ad below roughly **300 estimated members** in an ad set — smaller than that
and the platform either won't spend the budget or serves too thin a sample
to learn anything. `gtmos abm` plans around that floor:

- **Large accounts** (roughly ≥1,000 employees, tunable) get their own
  **`one_to_one`** plan — one landing page, one creative, one ad set, built
  entirely around that single company. A company that size clears the
  audience floor solo once you count the relevant buying-committee
  functions/seniorities at it.
- **Small accounts** get grouped into **`clustered`** plans — several
  similar-profile accounts (same rough industry/size band) targeted
  together as one ad set with one shared landing page and creative, so the
  combined estimated audience clears the floor even though no individual
  account would.
- **Unknown headcount** (`employee_count: null`) is never dropped or
  crashed on — it's treated as small-by-default and routed into clustering,
  since assuming "large" for an unverified account risks a one-to-one plan
  that never clears the floor alone.

**Honesty note on the sizing math:** the department-share and
seniority-share priors used to turn `employee_count` into an estimated
matched-audience number are rough industry-rule-of-thumb estimates, not a
calibrated model — LinkedIn doesn't publish its own audience-size formula,
and matched-audience size also depends on facets this planner doesn't have
(actual LinkedIn membership overlap, job-title taxonomy quirks, etc.). Every
plan's `estimated_audience` should be read as "probably big enough to
serve," not as a precise forecast, and Campaign Manager's own audience-size
estimate (shown at import time) is the number to trust before spending
anything. The priors live in `gtmos/abm/planner.py` and are meant to be
edited as real campaign data comes back — there's no reason to treat them
as fixed.

## Output

```
<out>/campaign-plan.json      — every plan: tier, accounts, targeting, estimated_audience
<out>/CAMPAIGN-SUMMARY.md     — human-readable summary, incl. a sizing_note per plan
<out>/pages/*.html            — one landing page per plan (single-file HTML, no external requests)
<out>/creatives/*.html        — one LinkedIn ad creative per plan (1200x627 single-file HTML)
<out>/creatives-manifest.json — one row per creative: slug, headline, logo_url, target ad set
```

Every account from the input file is placed in exactly one plan. Pages and
creatives are single-file HTML (system fonts, no external CSS/JS/font
requests) — a plain-text placeholder or screenshot renders them at a glance,
but there is currently **no PNG rendering step**: LinkedIn's native ad
formats want images for some placements, and today's output is
"Campaign-Manager-import-ready HTML," not a finished PNG asset. Rendering
these to PNG (e.g. via a headless-browser screenshot) is a natural next
step but isn't wired in yet — treat the HTML as the source of truth and
screenshot it yourself if you need an image today.

## Plan → push, and why push is hard to trigger by accident

Stage one (`plan`, the default) only ever writes files to `--out`. It never
touches the network and never talks to LinkedIn.

Stage two (`--push`) is a **stub**, guarded by two independent checks, both
required:

1. **`LINKEDIN_ACCESS_TOKEN` must be set in the environment.** No token, no
   push — the command prints why and exits non-zero instead of silently
   doing nothing.
2. **The operator must type the literal word `PUSH`** at an interactive
   confirmation prompt. Anything else cancels.

This is deliberate, load-bearing, recommend-first doctrine: **gtmos never
creates a paid LinkedIn campaign without a human explicitly typing approval
for it.** Even with both checks satisfied, no live LinkedIn Marketing API
call is implemented yet (see `docs/linkedin-api-application.md` — API access
is still pending approval); today `--push` with a valid token and a typed
`PUSH` prints that the push isn't implemented yet and exits cleanly. Do not
weaken either check when the real API call is wired in.

## Campaign Manager manual-import fallback

Until (or instead of) the LinkedIn API push, everything `gtmos abm`
produces is meant to be usable by hand: open `campaign-plan.json` and
`creatives-manifest.json`, and manually create the matching campaign
groups / campaigns / ad sets / creatives in LinkedIn Campaign Manager,
using the plan's `targeting` and `estimated_audience` as your ad-set
targeting brief and the rendered `pages/`/`creatives/` HTML as your
copy/creative source. This is slower than an API push, but it needs no
API approval, no token, and no code change — it works today.
