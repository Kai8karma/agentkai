DRAFT — requires review by qualified counsel before customer-facing use.

# DPA Posture — a one-pager for procurement

## The short version

You will likely ask us for a Data Processing Agreement (DPA), because
that's the standard ask for any vendor touching CRM data. Our honest
answer: **a traditional DPA mostly doesn't apply to GTM OS**, because we
are never in a position to process your personal data in the first
place. Below is why, what we'll sign instead, and where our compliance
posture stands today.

## Why a traditional DPA mostly doesn't apply

A DPA exists to govern a processor's handling of personal data on a
controller's behalf — access controls, sub-processing, breach
notification, deletion on termination, audit rights over the processor's
systems. Those clauses assume the vendor's infrastructure holds or
transits your data.

GTM OS's architecture removes that premise:

- GTM OS is software you **install and run on infrastructure you
  control**. There is no kaikarma-operated server, database, or API in
  the data path.
- The two systems it talks to outside your machine — the **HubSpot API**
  and the **`claude` CLI** — are reached using **your own credentials**
  (`GTMOS_HUBSPOT_TOKEN`, your own Anthropic/Claude Code auth). We never
  hold or route through a kaikarma-owned copy of those credentials.
- The only artifact that could theoretically reach us is something you
  choose to send us directly (e.g. a support email) — not something the
  software transmits on its own. There is no telemetry or phone-home path
  in the codebase (verified against `gtmos/harness.py` and the CLI entry
  points).

In short: there's no vendor-side "processing" for a DPA to govern, because
there's no vendor-side data.

## What we will sign

We recognize "no DPA" isn't a satisfying answer for a security review, so
we will sign:

- **A mutual NDA** — standard confidentiality terms covering any
  information exchanged during evaluation, sales, or support (e.g.
  screenshots, logs, or config you share with us for troubleshooting).
- **A security representation letter** — a written statement of the
  architecture claims in this document and in `SECURITY.md` (local-only
  execution, zero runtime dependencies, token handling, chokepoint
  design), so your security team has something citable and signable on
  our side.

If your procurement process requires a DPA as a checkbox regardless of
applicability, we're open to signing a narrowly-scoped one that reflects
reality (e.g. covering the limited case of support artifacts you send us)
rather than a boilerplate one that implies processing we don't do.

## Compliance posture, stated honestly

- **No SOC 2 certification exists today.** kaikarma is a solo-operator
  vendor; a formal audit is not yet in place.
- **The architecture itself narrows what an audit would need to cover.**
  Because GTM OS never receives, stores, or processes your personal data
  — it ships software that runs on your infrastructure — the scope of any
  future certification is inherently small: it would need to attest to
  the *code's* behavior (no phone-home, no token persistence, chokepoint
  enforcement — see `SECURITY.md`), not to operational controls over a
  multi-tenant service, because there isn't one.
- **The flows that do carry your data are already governed by agreements
  you hold.** Your HubSpot data flows under your existing HubSpot
  agreement/DPA. Your prompts and CRM context passed to the `claude` CLI
  flow under your existing Anthropic terms/DPA. We are not a party to
  either of those data flows.

## Data-flow diagram

```
 Your infrastructure (laptop / server you control)
 ┌──────────────────────────────────────────────────────────────┐
 │                                                                │
 │   GTM OS (installed locally, runs as your OS user)            │
 │                                                                │
 │   ┌────────────┐        ┌──────────────────┐                  │
 │   │  Your       │──────▶│ deterministic     │──▶ report.json  │
 │   │  HubSpot    │ token │ audit/funnel      │    (local disk) │
 │   │  data (via  │ you   │ engine (no LLM)   │                 │
 │   │  HubSpot    │ hold  └──────────────────┘                  │
 │   │  API) ◀─────┘                                             │
 │   └────────────┘                                              │
 │         ▲                                                     │
 │         │ REST call, your GTMOS_HUBSPOT_TOKEN                 │
 │         │                                                     │
 │   ┌─────┴──────┐        ┌──────────────────┐                  │
 │   │ harness.py  │──────▶│  `claude` CLI     │──▶ text output  │
 │   │ chokepoint  │ local │  (your Anthropic  │    + receipt    │
 │   │             │ subproc│  auth, your MCP  │    metadata     │
 │   └────────────┘  call  │  servers)         │    only         │
 │                          └──────────────────┘                  │
 │                                                                │
 │   receipts.jsonl (ts, command, prompt_chars, duration, exit)  │
 │   — metadata only, stays on this machine                      │
 └──────────────────────────────────────────────────────────────┘
             │                                    │
             ▼                                    ▼
     ┌───────────────┐                   ┌────────────────────┐
     │ HubSpot        │                   │ Anthropic           │
     │ (your account, │                   │ (your account,      │
     │ your DPA)      │                   │ your DPA)            │
     └───────────────┘                   └────────────────────┘

     kaikarma (the vendor) is not in this diagram at runtime —
     no server, no data store, no telemetry endpoint exists to draw.
```

## Bottom line for your security review

If your checklist requires "vendor has a signed DPA," the honest and
defensible answer is: the architecture is designed so that a DPA governs
a data flow that doesn't exist on our side. We'll put that claim in
writing (NDA + security rep letter) and stand behind the specific,
code-verified claims in `SECURITY.md` and `PRIVACY.md`. Have your counsel
confirm this framing satisfies your specific regulatory posture before
relying on it.
