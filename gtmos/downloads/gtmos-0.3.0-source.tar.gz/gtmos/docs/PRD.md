# GTM OS — Product Requirements Document

Status: v0.3 (current working tree). Owner: product. Last updated: 2026-07-13.

## 0. Thesis

Show GTM teams where they are losing money, without their CRM data ever
leaving their machines.

Every capability claim below is checked against the current code
(`gtmos/cli.py`, command implementation modules, `tests/`). Anything not
shipped is explicitly marked **[ROADMAP]**.

## 1. Problem

CRM data quality and pipeline-stage leakage are the two most common,
least-visible sources of lost revenue in a GTM org, and every existing way
to measure them requires handing a vendor read (often write) access to the
CRM — a cloud SaaS tool, a services firm doing a manual audit, or an
in-house project that never gets prioritized. Meanwhile the tools that *do*
run held-locally (spreadsheets, one-off scripts) have no published
methodology, no repeatable scoring, and no loop that turns a one-time
finding into a weekly habit.

### Personas, jobs-to-be-done, current painful alternative

| Persona | Job to be done | Painful alternative today |
|---|---|---|
| Founder / CRO | Know, in dollars, where GTM is bleeding — without giving a vendor a copy of the customer list | Hire a consultant for a one-time slide deck graded on a curve nobody can check, or eyeball the CRM personally once a quarter |
| RevOps | Keep CRM data and pipeline health measurably improving, catch drift before it compounds | A dashboard tool (cloud) with a black-box "health score," or a manual dedupe/audit pass in a spreadsheet with no revenue translation |
| SDR / outbound | Know exactly which accounts to touch today, in what order, without re-deriving it from three tools | A rep's personal tracker (Notion, spreadsheet) that decays the moment they're on PTO; sequences built by hand per account |
| Marketing / ABM | Ship 1:1 account campaigns tied to a real trigger signal, not a generic template blast | A generic ABM platform charging per-contact SaaS fees, still cloud-hosted, still opaque on how "fit" is scored |

## 2. Positioning vs alternatives

Source: `docs/COMPETITIVE.md` (teardown of Baseloop and Oxygen, 2026-07-09).

Cloud GTM tools are structurally unable to offer zero-egress: they are
hosted web apps or SaaS platforms by design, so "your CRM data never
leaves your infrastructure" is not a configuration option they can add —
it's a different product. GTM OS's wedge is built on that structural gap,
not on a feature race:

| Capability | Baseloop | Oxygen | GTM OS |
|---|---|---|---|
| Standalone CRM integrity audit, published methodology | dedupe-on-sync only | tagline only, no mechanism | `gtmos audit` — deterministic 5-dimension score, dupe penalty, $-leak model, open methodology doc |
| Self-hosted / zero data egress | cloud SaaS | "we host it for you" | runs on your machine, your keys; score path has zero network calls |
| Installable CLI | hosted web app + skill files | hosted web app + skill files | `pip install -e .` → `gtmos` binary |
| Compounding memory across runs | stateless re-runs | stateless re-runs | `gtmos outcomes` writes win/loss to a persistent brain; scoring context survives between engagements |
| Cost observability on every LLM call | none | partial (credits, not per-action receipts) | every harness call receipted to `~/.gtmos/receipts.jsonl` |

Deliberately deferred (their game, not played — see `docs/COMPETITIVE.md`
for the "no feature race" doctrine): a 40–50-provider enrichment
waterfall, a native multichannel sequencer, credit-based self-serve
pricing, and native Salesforce support. None of these are gaps we've
missed; each has a stated reason for waiting.

## 3. Product principles

1. **Deterministic scores — no LLM in a number path.** `audit`, `funnel`,
   `play` planning, `eval`, `weekly`, `init`, `team` are pure Python. The
   same input always produces the same score. This is enforced, not just
   claimed: `gtmos eval`'s `harness-contract` check statically scans
   `gtmos/` for `subprocess.*` calls outside `gtmos/harness.py` and fails
   the build if it finds one.
2. **Single harness chokepoint with receipts.** Every LLM-backed command
   (`prospect`, `stalk`, `draft`, `brief`, `play run --draft`) shells out
   to the `claude` CLI through exactly one function —
   `run_harness()` in `gtmos/harness.py`. It caps iterations
   (`MAX_ITERATIONS = 3`), enforces a 180-second per-call timeout, and
   writes a receipt (timestamp, command, prompt size, duration, exit
   code) for every call to `~/.gtmos/receipts.jsonl`. Agent usage is
   auditable, not a black box.
3. **Files are the API.** Every command reads and writes plain JSON/Markdown
   artifacts in the workspace directory (`gtmos-team.json`, `report.json`,
   `play-out/`, `today-out/`, `weekly-review.md`, etc.). `gtmos serve`
   doesn't run its own pipeline — it reads the same files the CLI writes.
   There is no hidden database and no server-side state.
4. **CLI = engine, serve = surface.** `gtmos serve` is a local, read-only
   web dashboard for non-terminal roles. It binds to `127.0.0.1` by
   default; `--host 0.0.0.0` is refused unless `--lan` is also passed
   (`gtmos/serve/cli_entry.py`), so exposing it beyond loopback is a
   visible, deliberate choice, never an accident.

## 4. Functional requirements

All 16 top-level subcommands in `gtmos/cli.py`, mapped to the persona(s)
in `README.md`'s role table and the loop (daily / weekly / play / setup)
each belongs to per `docs/TEAM-PLAYBOOK.md`. Acceptance criteria are
falsifiable — each is either checkable by an exit code, a diffable
artifact, or a committed test.

| Command | Persona | Loop | What it does | Acceptance criteria |
|---|---|---|---|---|
| `gtmos init` | Founder/CRO | Setup | Scaffolds `gtmos-team.json`, `DOCTRINE.md`, `PLAN.md`, `PLAYS.md` in a target dir | Running `gtmos init --name "X"` in an empty dir creates all four files; re-running without `--force` leaves them untouched; with `--force` it overwrites. Exit 0. |
| `gtmos team` | Founder/CRO | Setup | Shows or edits `gtmos-team.json` (roles, ICP, ACV, stage config) | `gtmos team --get team.acv` prints the value in `gtmos-team.json`; `gtmos team --set team.acv=9000` then `--get` returns `9000.0`. Exit 0. |
| `gtmos audit` | Founder/CRO, RevOps | Weekly | Deterministic CRM Integrity Score: 5-dimension score, duplicate clusters, $-leak estimate | Same input JSON (`--input`) with same `--acv` produces byte-identical `report.json` across two runs (this is `gtmos eval`'s `audit-determinism` check). Exit 0 on valid input; nonzero on unreadable/malformed input. |
| `gtmos funnel` | Founder/CRO, RevOps | Weekly | Deal-stage revenue-leak analysis: stage table, conversion funnel, stalled-deal detection, $-leak model | `gtmos funnel --input deals.json --out ./funnel-out` writes a stage table and a `$-leak` figure computed as `closed-lost value + 0.5 × stalled open value` (median-imputed for unvalued deals); `--stall-days` changes which deals are flagged stalled. Exit 0. |
| `gtmos play list` | SDR, Marketing | Play | Lists the 4 built-in signal plays | `gtmos play list` prints exactly 4 names: post-merger, new-revops-hire, hiring-spree, compliance-wall. Exit 0. |
| `gtmos play show <name>` | SDR, Marketing | Play | Prints one play's full touch sequence | Output shows every step's channel and day offset for the named play; unknown name exits nonzero. |
| `gtmos play run <name>` | SDR, Marketing | Play | Builds a per-target touch plan from a targets JSON, writes plan + state | `--targets targets.json --start-date YYYY-MM-DD` produces a `play-out/` plan with one entry per target, dated from the start date; `--draft` upgrades copy through the harness, capped at the first 10 targets — the 11th+ target keeps template copy verbatim (checked by `tests/test_plays.py`). |
| `gtmos play touch` | SDR | Daily | Logs a completed touch for a target/step | After `gtmos play touch <name> --target "Acme" --step 2`, `gtmos play status <name>` shows step 2 as done for Acme. State persists in `play-out/`. |
| `gtmos play status` | SDR, Founder/CRO | Daily | Shows per-target sequence progress, due/overdue | Targets past their scheduled step date and not yet touched show as overdue; `--today` overrides the date for deterministic testing. |
| `gtmos today` | All 4 roles | Daily | Role-aware checklist: stalled deals, audit grade, due/overdue play touches, unstarted targets, activity pulse | `gtmos today --role sdr` in a workspace directory returns only the SDR section; missing data sources (no audit run yet, no plays started) degrade to an empty/gap-labeled section, never a crash. Exit 0; exit 2 on an unknown `--role`. |
| `gtmos eval` | RevOps | Weekly | Eval harness: audit regression vs. committed golden, determinism check, receipts-log integrity, static harness-contract scan (no LLM outside the chokepoint); `--judge` adds an LLM-graded actionability check | Exit 0 only if every check in `gtmos/evals/suite.py` (`audit-regression`, `audit-determinism`, `receipts-integrity`, `harness-contract`, and `judge` when `--judge` is passed) reports `passed=True`. Exit 1 on any failure, with the failing check named. |
| `gtmos weekly` | RevOps, Founder/CRO | Weekly | Assembles whatever exists (audit score, funnel leak, receipts activity) into `weekly-review.md` | Running with only a prior `audit` output (no `funnel` run yet) still produces `weekly-review.md`, with the missing source listed under gaps rather than failing. Exit 0. |
| `gtmos prompts` | Any (prompt tuning) | As needed | Lists / shows / exports the versioned harness prompt registry (`gtmos/prompts.py`) | `gtmos prompts export` writes `gtmos-prompts.json`; after editing one template's `"template"` key and re-running `gtmos prompts show <name>`, the edited text is what's printed — proving the override, not just the builtin, is live. |
| `gtmos serve` | Non-terminal roles (marketing, founder) | Daily/Weekly | Local read-only web dashboard rendering the same JSON/Markdown artifacts the CLI writes | `gtmos serve` binds `127.0.0.1:8390` by default; `gtmos serve --host 0.0.0.0` (no `--lan`) exits 2 and refuses to bind; with `--lan` it binds and warns plainly that the dashboard is now LAN-visible. |
| `gtmos abm` | Marketing, Founder/CRO | Play (ABM) | Deterministic 1:1 ABM ad-set plan, LinkedIn-Campaign-Manager-ready pages/creative, no LLM | `gtmos abm --accounts accounts.json --out ./abm-out` writes `campaign-plan.json` plus rendered page/creative assets, same output for the same input every run (no LLM call in this path). `--push` without `LINKEDIN_ACCESS_TOKEN` prints the exact remediation message pointing to `docs/linkedin-api-application.md` and does not push. |
| `gtmos prospect` | Founder/CRO, SDR | Play (setup) | Harness command: builds a tagged, deduplicated ICP-matched lead list via whatever prospecting MCP is connected | With `--input candidates.json --dry-run`, runs fully offline against pre-fetched candidates and returns tagged output with no network/MCP call and no `claude` subprocess invoked. |
| `gtmos stalk` | Founder/CRO, SDR | Play (per-touch) | Harness command: founder recon brief — profile, recent activity, prior CRM touch history, one suggested personalization hook | With `--input crm-context.json --dry-run`, produces a recon summary using only the pre-fetched context, with prior-touch history stated explicitly as "none found" when the input has none (never implied). |
| `gtmos draft` | Founder/CRO, SDR, Marketing | Play (per-touch) | Harness command: drafts outreach copy or narrative content (LinkedIn, X, outreach) in-voice, self-eval gated | `gtmos draft --type outreach "<topic>"` returns a draft plus a `VOICE=x HOOK=x DENSITY=x CTA=x FORMAT=x` self-score line, per the `draft-outreach` prompt's output contract in `gtmos/prompts.py`. |
| `gtmos brief` | Founder/CRO | Daily | Harness command: assembles a pre-call/morning brief from CRM state plus whatever brain/calendar context is available | With `--input pipeline.json --dry-run`, produces pipeline state, pending follow-ups, and top-3 actions using only the supplied file — no network call. |
| `gtmos outcomes` | Founder/CRO, RevOps | Weekly | Thin wrapper over the `brain` CLI to log recall win/loss/neutral outcomes | `gtmos outcomes --log "mem_id win"` exits 0 only if the underlying `brain` CLI accepts the log; `--roi` prints the ROI report from `brain`. Requires `brain` on `PATH` — not vendored. |

Note on count: the codebase currently exposes **16** top-level
subcommands (`play` and `prompts` each fan out into sub-actions —
list/show/run/touch/status, and list/show/export respectively — which are
not separately counted). `today`, `prompts`, and `serve` are the newest
additions (uncommitted in git as of this writing; see `CHANGELOG.md` v0.3).

## 5. Non-functional requirements

| Requirement | Current state |
|---|---|
| Offline-capable | Every command that touches a CRM or MCP accepts an `--input`/`--dry-run` path that runs against a local file with zero network calls (`audit`, `funnel`, `prospect`, `stalk`, `draft`, `brief`, `abm`). Deterministic commands (`audit`, `funnel`, `play` planning, `eval`, `weekly`, `init`, `team`, `abm` planning) never need a network call at all. |
| Zero external dependencies | `pyproject.toml` declares `dependencies = []` — stdlib only (`argparse`, `json`, `http.server`, etc.). No vendored SDKs, no npm build step. |
| Zero telemetry | Nothing in `gtmos/` phones home. The only two systems the tool talks to outside the local machine are the HubSpot API (customer's own token, `GTMOS_HUBSPOT_TOKEN`) and the local `claude` CLI subprocess (customer's own Claude Code auth) — both documented in `README.md`'s "Self-hosting model." |
| Receipts audit trail | Every harness (LLM) call writes one line to `~/.gtmos/receipts.jsonl`: `ts`, `command`, `prompt_chars`, `duration_s`, `exit`. `gtmos eval`'s `receipts-integrity` check verifies the log's shape. |
| Test coverage gate | 131 test functions across 12 test files in `tests/` (verified by direct count as of this writing, not asserted from memory). No CI pipeline is checked into this repo yet — running the suite is a local/pre-push step today; wiring it into the buyer's own CI is a deployment-time task, not a shipped feature. **[gap, tracked below]** |
| Eval harness | `gtmos eval` exists and runs four deterministic checks plus an opt-in LLM judge check; it is designed to be wired into pre-push per `docs/TEAM-PLAYBOOK.md`, but no `.github/workflows` or pre-push hook ships in this repo — the buyer wires it into their own CI/hooks. |
| Deterministic scoring | Enforced by `gtmos eval`'s `harness-contract` check: a static regex scan (`subprocess\.(run|Popen|call|check_output|check_call)`) over `gtmos/` fails the build if any file outside `gtmos/harness.py` shells out — the constraint is machine-checked, not a style guideline. |

### Known gap (flagged, not hidden)

The installed package version (`gtmos/__init__.py`, `__version__ = "0.1.0"`)
has not been bumped to reflect the v0.2/v0.3 feature work already in the
tree. `gtmos --version` will under-report the actual feature set until
this is corrected. Tracked as a pre-release housekeeping item, not a
functional defect.

## 6. Success metrics

| Metric | Definition | Target (initial) |
|---|---|---|
| Activation | Time from `gtmos init` to a completed first `gtmos funnel` (or `audit`) report | < 30 minutes on a workspace with a HubSpot token already in hand |
| Weekly-loop retention | Fraction of workspaces that run the Monday sequence (`audit → funnel → eval → weekly`) in a given week, of those that ran it the prior week | Track from first paying engagement; no baseline yet — this is a measurement to stand up, not a number we're claiming today |
| $-leak surfaced per customer | Sum of `audit`'s $-leak estimate + `funnel`'s $-leak estimate, per engagement | Reported per `docs/OFFER.md`'s guarantee: audit must surface ≥ $30,000 recoverable pipeline or the audit is free |
| Touch-log rate | Fraction of `today`-surfaced due/overdue play touches that get a matching `gtmos play touch` log within 24h | Used as the workspace-health signal in `gtmos weekly`'s gap list; no target set yet, tracked from first team-scale rollout |

## 7. Out of scope / non-goals (v1)

- **No cloud sync.** There is no server component that stores customer CRM
  data outside the customer's machine. This is a structural choice, not a
  missing feature — see Section 2.
- **No hosted SaaS.** `gtmos serve` is a local dashboard, not a hosted
  multi-tenant product. Running it for a team means running it on a
  machine that team can reach (localhost or `--lan`), not standing up a
  hosted instance.
- **No auto-send of outreach.** `draft`, `play run --draft`, and `abm`
  produce copy and campaign plans, never send anything. A human sends
  every touch and logs it via `gtmos play touch`. `abm --push` requires a
  human to type approval and, even then, has no live LinkedIn API call
  wired yet (`docs/linkedin-api-application.md`) — it prints artifacts for
  manual import into Campaign Manager.
- **No auto-merge of duplicates.** `audit` reports duplicate clusters; a
  human decides what to merge.
- **No 40–50-provider enrichment waterfall, no native multichannel
  sequencer, no credit-based self-serve pricing, no native Salesforce
  support** — deliberately deferred per `docs/COMPETITIVE.md`, each with a
  stated re-evaluation trigger rather than a date.

## 8. Roadmap

Every v0.4 candidate below is gated on a falsifiable adoption signal
observed from real usage, not a calendar date. None are committed; all are
**[ROADMAP]**.

| Candidate | Gate to build it |
|---|---|
| Slack digest surface (push `weekly`/`today` summaries into Slack) | ≥ 3 active workspaces ask for a non-dashboard, non-CLI way to see the daily/weekly output without opening a terminal or browser |
| More CRM adapters beyond HubSpot (e.g. Pipedrive, Attio) | A paying or piloting customer's primary CRM is not HubSpot and they'd otherwise not proceed — validated demand, not a guess at the next-largest CRM by market share |
| Multi-workspace support (one `gtmos` install managing several `gtmos-team.json` workspaces) | A single operator or agency runs GTM OS for ≥ 3 client workspaces and the current one-workspace-per-directory model becomes the friction point, evidenced by actual repeated `--dir` juggling |
| Salesforce native support | Deferred per `docs/COMPETITIVE.md` until after a published HubSpot case study — sequenced, not blocked on nothing |
| 40–50-provider enrichment waterfall | Only if audit/funnel clients explicitly pull for it post-engagement — see `docs/COMPETITIVE.md`'s "day 60+" doctrine |
