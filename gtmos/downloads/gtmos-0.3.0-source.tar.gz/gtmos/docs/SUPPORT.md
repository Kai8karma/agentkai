# GTM OS — Support Policy

GTM OS is a self-hosted CLI maintained by a solo vendor. This document
states, honestly, what support looks like at this stage — no enterprise
SLA fiction, no round-the-clock promise this team can't keep.

## Channels

- **Primary: direct email/message to the maintainer** (the channel you
  already have from the engagement or pilot). There is no ticketing
  portal, status page, or shared Slack workspace at this stage.
- **Bug reports and feature requests:** same channel. If/when this
  repository is hosted somewhere with issue tracking, that becomes the
  preferred channel for anything non-urgent — this document will be
  updated when that's true; it is not true today.

## Response targets by severity (best-effort, solo-vendor honest)

There is one person behind this product. These are honest targets, not
contractual SLAs — treat them as "this is what to expect," not "this is
guaranteed."

| Severity | Definition | Target first response | Target resolution |
|---|---|---|---|
| **Sev 1 — data-loss or incorrect $-leak/score on a live engagement** | `gtmos audit`/`funnel` produces a wrong number that's about to go into a client-facing report, or a command corrupts a workspace's state file (`play-out/`, `gtmos-team.json`) | Same business day | As fast as the fix can be verified — no invented deadline; you'll get an honest update if it's slower than hoped |
| **Sev 2 — a command errors or crashes** | Any `gtmos` subcommand exits nonzero unexpectedly, or a harness command hangs past its 180s timeout without a receipt written | 1 business day | Best-effort within the week |
| **Sev 3 — behavior is confusing but not wrong** | Unclear error message, a flag that doesn't do what the docs imply, a gap in `--dry-run` coverage | Acknowledged within a few business days | Bundled into the next update, no fixed date |
| **Sev 4 — feature request / roadmap question** | "Can it do X" where X is in `docs/PRD.md`'s roadmap or out-of-scope section | Acknowledged, pointed at the relevant PRD section | Evaluated against the adoption-signal gate in `docs/PRD.md` §8 — not promised |

There is no 24/7 on-call. If a Sev 1 happens outside business hours, it
gets picked up at the start of the next business day unless the channel
you're using is checked more often — say so plainly if timing matters for
your engagement, and the target above will be treated as a floor to beat,
not a ceiling to wait for.

## What a bug report needs

To act on a bug quickly, include:

1. **The exact command you ran**, including flags (redact `--acv` or any
   business-sensitive numbers if you need to, but keep the flag names).
2. **`gtmos eval` output**, run in the same workspace, right before or
   after the bug — this tells us in one shot whether the deterministic
   engine, the receipts log, or the harness contract itself is implicated,
   before we start guessing.
3. **A receipts excerpt**, if the bug touched a harness command
   (`prospect`, `stalk`, `draft`, `brief`, `play run --draft`): the last
   few lines of `~/.gtmos/receipts.jsonl` for that command (`ts`,
   `command`, `prompt_chars`, `duration_s`, `exit`). This is the fastest
   way to tell "the LLM call failed" from "the harness chokepoint itself
   is broken."
4. **What you expected vs. what you got.** Include the actual output/error
   text, not a paraphrase.
5. **Your CRM data does not need to leave your machine to report a bug.**
   If the bug is data-shape-dependent, send a minimal, synthetic
   reproduction (a small `--input` JSON with fake names/emails) rather
   than a real export. That keeps this support channel consistent with
   the product's own zero-egress principle.

Reports missing (2) and (3) for a harness-command bug will likely get a
first reply asking for them — including them up front is the single
biggest speed-up available to you.

## Upgrade path

There is no auto-updater and no hosted "latest version" to pull from a
registry — GTM OS is installed from source.

```bash
git pull
uv pip install -e .        # or: pip install -e .
pytest                      # the test suite is the upgrade gate
```

**The test suite is the gate, not a formality.** If `pytest` doesn't pass
clean after a `git pull`, do not run the new version against a live
workspace — file it as a Sev 1/2 per the table above and stay on the
previous commit until it's resolved. `gtmos eval` (the product's own eval
harness) is a second, workspace-level gate worth running after any
upgrade, since it checks your specific workspace's audit determinism and
receipts integrity, not just the code.

## Versioning promise

GTM OS follows **semantic versioning** (semver): `MAJOR.MINOR.PATCH`.

- **No breaking CLI changes within a minor version.** A flag, subcommand,
  or output-file shape that exists in `0.3.x` will keep working
  (same name, same meaning) through the rest of the `0.3` line. Breaking
  changes — a renamed flag, a removed subcommand, a changed output schema
  — are reserved for a minor or major bump and will be called out plainly
  in `CHANGELOG.md`, not buried in a patch note.
- **Patch releases are fixes only.** No new subcommands, no flag
  behavior changes in a patch release.
- **Pre-1.0 caveat, stated honestly:** the package's installed
  `__version__` (`gtmos/__init__.py`) is still `0.1.0` even though the
  feature set described in `README.md` and `docs/PRD.md` corresponds to
  what this document calls v0.3 — the version string has not yet been
  bumped to track the feature work. Until that's corrected, treat
  `CHANGELOG.md`'s version headers, not `gtmos --version`'s output, as the
  source of truth for what's actually shipped. This gap is tracked in
  `docs/PRD.md` §5.
