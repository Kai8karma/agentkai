# The CRM Integrity Score: an open methodology

Most CRM "health" checks are a vibe: a vendor logs into your portal, points
at some red numbers, and hands you a slide. There is no published,
reproducible standard for what "clean CRM data" actually means, so every
audit is graded on a curve nobody can check.

This document publishes ours in full: five weighted dimensions, the rubric
behind each one, the duplicate-detection method, and the revenue-leak model
— including the assumption baked into it. It is deliberately boring and
specific enough that you could reimplement it yourself. Deterministic
scoring only; nothing here depends on a model's judgment call.

## The composite score

Every contact and company record gets a score from 0–100 on each of five
dimensions. The overall **CRM Integrity Score** is the weighted average:

| Dimension | Weight |
|---|---|
| Completeness | 0.30 |
| Validity | 0.25 |
| Freshness | 0.25 |
| Ownership | 0.10 |
| Consistency | 0.10 |

```
composite = 0.30·completeness + 0.25·validity + 0.25·freshness
          + 0.10·ownership   + 0.10·consistency
```

**Unreachability cap.** A record with no working email *and* no working
phone is commercially dead regardless of how complete or consistent its
other fields are, so its composite is capped at **45** (bottom of the D
band). This prevents well-groomed-but-unreachable records from hiding in
the B range.

**Portal score.** The portal-level score is the mean composite across all
scored records, minus a duplicate penalty:

```
portal = record_mean − min(10, duped_record_share × 25)
```

where `duped_record_share` is the fraction of records sitting in any
duplicate cluster. Duplication is portal-level rot that per-record scores
cannot see — a portal where 20% of records are duplicates loses 5 points
even if every individual record looks pristine. The penalty is capped at
10 points so duplication alone cannot move a portal more than one grade
band. The report always shows the decomposition (record mean, penalty,
dead share, at-risk share) next to the headline score.

### Why these weights

The three largest weights (completeness, validity, freshness — 0.80 of the
total) are the dimensions that break downstream workflows on their own:
a record with a missing field, a malformed contact detail, or a stale
lifecycle stage will misroute, misfire, or simply get skipped no matter how
well everything else about it is kept. Completeness edges out validity and
freshness because it is the precondition for the other four dimensions
being measurable at all — you cannot judge the validity of a phone number
that was never entered, or the freshness of a lifecycle stage that was
never set.

Ownership and consistency get smaller weights (0.10 each) because they are
real but narrower failure modes: an unowned record stalls follow-up, and an
inconsistent record (a title that doesn't match a role, a company name that
doesn't match its associated company) erodes trust in reporting — but
neither one blocks a workflow the way a missing email address does.
Weights sum to 1.00 by construction.

## Dimension 1 — Completeness (0.30)

Measures whether the fields a GTM motion actually depends on are populated.
Define a required-field set per object type (a sensible default for a
contact record):

| Field | Required for |
|---|---|
| Email | any outbound motion |
| First + last name | personalization |
| Company name | segmentation, routing |
| Job title | ICP fit, personalization |
| Phone | multi-channel outreach |
| Industry | segmentation |
| Company size (employee count) | ICP fit |
| Lifecycle stage | routing, reporting |

**Score = (populated required fields ÷ total required fields) × 100.**
A field counts as populated only if it holds a real value — an empty
string, a literal `"null"`/`"N/A"`/`"unknown"`, or a value under 2
characters does not count.

## Dimension 2 — Validity (0.25)

Measures whether the fields that *are* populated hold plausible, usable
values — completeness asks "is it there," validity asks "is it real."

| Check | Rule | Failure examples |
|---|---|---|
| Email syntax | matches standard RFC 5322-lite pattern (`local@domain.tld`, domain must contain a dot) | `jane at acme.com`, `jane@acme` |
| Email placeholder | neither the local part nor the domain base is a placeholder token (`test`, `asdf`, `example`, …) — format-valid placeholder addresses are dead addresses | `test@test.com`, `asdf@example.com` |
| Email domain class | not a known disposable-mail domain | `bob@mailinator.com`, `x@yopmail.com` |
| Phone format | digits-only length between 7 and 15 after stripping formatting (loose E.164 sanity check) | `555-CALL`, `12345` |
| Placeholder text | populated text fields do not match a known placeholder token list (`test`, `asdf`, `n/a`, `unknown`, `xxx`, …) | first name = `"Test"` |

**Score = (fields passing validity checks ÷ fields checked) × 100.** Only
populated fields are checked (an empty field is a completeness failure, not
a validity failure — the two dimensions are deliberately non-overlapping so
a single defect isn't double-counted).

## Dimension 3 — Freshness (0.25)

Measures how current the record's engagement signal is, using the most
recent of: last activity date, last modified date, or last contacted date.

| Days since last signal | Score |
|---|---|
| ≤ 90 | 100 |
| 91–180 | 75 |
| 181–365 | 50 |
| 366–730 | 25 |
| > 730 or never recorded | 0 |

Bucketed rather than continuous on purpose: a stakeholder reading a report
should be able to say "this record hasn't moved in over a year" without
doing arithmetic, and bucket edges are deliberately round (one quarter, two
quarters, one year, two years).

## Dimension 4 — Ownership (0.10)

Measures whether a record has a live, accountable owner.

| Condition | Score |
|---|---|
| Owner assigned and owner is an active CRM user | 100 |
| Owner assigned but owner is deactivated/departed | 40 |
| No owner assigned | 0 |

A departed owner scores above zero (not zero) because the record still has
routing metadata that a reassignment pass can act on — it is a smaller
defect than having no owner at all, which usually means the record was
never triaged.

## Dimension 5 — Consistency (0.10)

Measures whether related fields agree with each other, catching the class
of error that completeness and validity checks miss because each field
looks fine in isolation.

| Check | Rule |
|---|---|
| Contact ↔ company name match | the contact's free-text company field matches (case-insensitive, normalized) the name of its associated company record, when one exists |
| Lifecycle stage ↔ activity | a record marked as an active deal stage (e.g. "opportunity," "customer") has at least one logged activity in the last 365 days |
| Title ↔ seniority field | if both a job title and a separate seniority/level field exist, they don't contradict (e.g. title contains "VP" but seniority field says "individual contributor") |

**Score = (checks passed ÷ checks applicable) × 100.** A check is only
"applicable" if both sides of the comparison exist — you can't be
inconsistent about a field you don't have (that's a completeness problem).

## Grade bands

The composite score maps to a letter grade for reporting:

| Grade | Composite score |
|---|---|
| A | ≥ 85 |
| B | ≥ 70 |
| C | ≥ 55 |
| D | ≥ 40 |
| F | < 40 |

Bands are spaced 15 points apart (except the F floor) so a single dimension
slipping a full grade band moves the composite by roughly the weight of
that dimension — the bands are calibrated to the same scale as the scoring,
not picked arbitrarily.

## Duplicate detection

Duplicates are found in two passes, run in order:

**Tier 1 — exact match.** Records are grouped by lowercased, whitespace-
trimmed email address. Any group with more than one record is a confirmed
duplicate cluster (email is treated as a unique identity key; two records
sharing one is definitionally the same person).

**Tier 2 — fuzzy match.** Records *not* already placed in a tier-1 cluster
are grouped by a composite key of normalized last name (lowercased) plus
normalized company (lowercased, legal suffixes like "Inc"/"LLC"/"Ltd"
stripped, whitespace collapsed). Records sharing that composite key form a
probable duplicate cluster. This deliberately trades some false positives
(two genuinely different people with the same surname at the same company)
for zero missed same-person pairs — probable clusters are labeled as such
in the report.

Clusters are reported, not auto-merged — merge is a decision a human makes
with the report in hand.

## The $-leak model

The dollar-leak estimate translates "some records are unreachable" into a
number a revenue conversation can use. It is explicitly an **order-of-
magnitude estimate**, not a forecast — it exists to make the cost of bad
data legible, not to be precise to the dollar.

```
$-leak = unreachable_share × total_records × ACV × 2%
```

- **`unreachable_share`** — the fraction of scored records that fail the
  validity door entirely: no syntactically valid email *and* no
  plausible-format phone number. These records cannot be reached through
  any standard outbound channel, full stop.
- **`total_records`** — the count of records the audit scored (a segment,
  such as "open pipeline contacts," or the whole portal).
- **`ACV`** — the average contract value for the business being audited,
  supplied as an input; the model does not guess this.
- **`2%`** — a deliberately conservative baseline outbound-to-close
  conversion rate, used as a floor rather than an average. Real conversion
  rates vary enormously by motion and market; 2% is chosen because it is
  low enough that the resulting number understates rather than overstates
  the case, and low enough to survive the obvious objection ("our real
  conversion rate is higher, so this actually understates our exposure")
  rather than the opposite one.

**Stated assumption, explicitly:** the model assumes every unreachable
record represents a lead that could otherwise have entered a normal
outbound motion at the stated baseline conversion rate. It does not adjust
for lead quality, ICP fit, or stage — those are covered by the completeness
and ownership dimensions, not this model. Treat the output as "money left
on the table if these records were fixed and run through your normal
funnel at a conservative rate," not as a guaranteed recovery figure.
