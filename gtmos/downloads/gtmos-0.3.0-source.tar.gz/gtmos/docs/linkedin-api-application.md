# LinkedIn Marketing Developer Platform — application draft

> Submit at: developer.linkedin.com → My Apps → create app → request "Advertising API" access.
> Prereqs before submitting: a LinkedIn Company Page for the firm (the app must be associated with it), and the app's privacy policy URL (agentkai.io/privacy — needs a page; one paragraph is enough).

## Form answers (paste-ready, edit bracketed bits)

**App name:** GTM OS
**Company:** [kaikarma / agentkai legal name]
**App description:**
GTM OS is a self-hosted go-to-market CLI for B2B teams. The Advertising API
integration lets a customer create and manage their own account-based
LinkedIn campaigns (campaign groups, campaigns, creatives, and matched
audiences) from their own infrastructure, using their own OAuth-authorized
ad account. All API calls are initiated by the authenticated advertiser for
their own account; no data brokerage, no audience resale, no cross-customer
data pooling.

**Use case category:** Advertising / Campaign management for advertisers.

**Endpoints requested:**
- Campaign Management (adAccounts, campaignGroups, campaigns, creatives)
- Audiences (matched audiences / DMP segments — company-list targeting)
- Reporting (adAnalytics — campaign performance readback)

**How data is used:** Campaign objects are created on the advertiser's own
ad account at their explicit command-line instruction. Performance data is
displayed to that advertiser only, stored locally on their machine. No
LinkedIn member data is retrieved, stored, or enriched; targeting uses
LinkedIn's native facets (company, function, seniority) referenced by URN
only.

**Data retention:** No LinkedIn data retained server-side (there is no
server). Local campaign-plan files live on the customer's machine under
their control.

**Estimated volume:** [<10] ad accounts initially; low hundreds of API
calls/day at peak (campaign creation runs are batch, infrequent).

## Honest-mode notes (not for the form)

- Approval historically takes 2–6 weeks; thin/vague applications get
  rejected. The self-hosted, advertiser-initiated framing above is accurate
  AND the strongest approval angle — LinkedIn's review cares about member
  data handling, and we handle none.
- Until approved, `gtmos abm` runs in plan mode: it generates everything
  (pages, creatives, ad-set plans with audience sizing) and outputs
  Campaign-Manager-ready artifacts. The API push is the last mile, not the
  product.
- Rejection fallback: CSV/manual import flow into Campaign Manager — ugly
  but functional, and what most "$20k ABM software" quietly does anyway.
