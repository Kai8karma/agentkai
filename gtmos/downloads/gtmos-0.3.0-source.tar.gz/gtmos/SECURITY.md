DRAFT — requires review by qualified counsel before customer-facing use.

# Security Policy — GTM OS

_Last updated: 2026-07-13_

## Threat model

GTM OS is self-hosted: it runs as a Python CLI plus a local read-only
dashboard on infrastructure you control. There is no vendor-operated
server in the request path, so the attack surface we're responsible for
is narrow and specific:

- **In scope:** the GTM OS codebase itself (the audit/funnel engines, the
  `claude` CLI chokepoint, the local dashboard server, the receipts
  logger, the CLI argument handling).
- **Out of scope (governed by your own agreements, not us):** HubSpot's
  infrastructure and API security, Anthropic's infrastructure and the
  `claude` CLI's own security posture, any MCP server you've authorized
  (Apollo, LinkedIn, etc.), and the security of the machine you run GTM OS
  on (OS hardening, disk encryption, physical access — that's yours).

## Token handling

`GTMOS_HUBSPOT_TOKEN` is read from the environment at call time
(`os.environ.get("GTMOS_HUBSPOT_TOKEN")` in `gtmos/audit/fetch.py`,
`gtmos/audit/cli_entry.py`, `gtmos/funnel/fetch.py`,
`gtmos/funnel/cli_entry.py`, `gtmos/commands/stalk.py`,
`gtmos/commands/brief.py`). We grepped the codebase for any write path
that persists this value to disk (config files, logs, receipts, cache
files) and found none — the token is held in process memory only, for the
duration of the HubSpot API call it authorizes, and is never written into
`gtmos-team.json`, `report.json`, `~/.gtmos/receipts.jsonl`, or any other
artifact GTM OS produces.

The same pattern holds for `LINKEDIN_ACCESS_TOKEN` (read in
`gtmos/abm/cli_entry.py` and `gtmos/abm/creative.py`, gating the
LinkedIn-push stub) — read from environment, never written to disk.

**If a future code path ever needs to persist a token** (e.g. a config
cache), that would be a material change to this section requiring
re-review before ship — flag it in a PR description if you're the one
adding it.

## Local dashboard binding policy

`gtmos serve` (`gtmos/serve/cli_entry.py`, `gtmos/serve/server.py`) binds
`127.0.0.1` by default (`DEFAULT_HOST = "127.0.0.1"`). Binding to
`0.0.0.0` (exposing the dashboard to your local network) requires the
explicit `--lan` flag — the CLI **refuses** to bind `0.0.0.0` without it
(`gtmos/serve/cli_entry.py`: `if host == "0.0.0.0" and not lan: ... print
"serve: refusing to bind 0.0.0.0 without --lan"`), and prints an explicit
warning when `--lan` is used. The dashboard is read-only: it serves JSON
artifacts already written to disk by other GTM OS commands and does not
expose a write/mutation endpoint. It carries no authentication layer —
treat `--lan` as "trusted local network only," not "safe to expose
further" (e.g. do not port-forward it to the internet).

## No external assets, no CDN

The dashboard's HTML/CSS is served inline from `gtmos/serve/views.py` —
there are no `<script src="https://...">` or stylesheet references to any
external host. We grepped `gtmos/serve/*.py` for `http://`/`https://`
references and found none pointing at a CDN or third-party asset; the only
URL literal present is the dashboard's own local bind address printed to
the terminal. Loading the dashboard makes zero outbound network requests
beyond what your browser does to reach `127.0.0.1`.

## Supply chain

`pyproject.toml` declares `dependencies = []` — GTM OS has **zero runtime
dependencies** beyond the Python 3.11+ standard library. The only
`[build-system]` dependency is `setuptools>=68`, needed to build/install
the package, not at runtime. This means:

- No transitive dependency tree to audit for CVEs at runtime.
- No supply-chain attack surface from a compromised third-party PyPI
  package reaching your CRM data.
- The only external code executing against your data is the `claude` CLI
  itself (your own Anthropic-distributed binary) and whatever MCP servers
  you've separately authorized — both outside this repo's supply chain.

## The harness chokepoint as the LLM security boundary

`gtmos/harness.py::run_harness()` is the single point in the codebase that
shells out to the `claude` CLI. This matters for security, not just
architecture: every LLM-backed command's blast radius is bounded by this
one function — same timeout (default 180s per call), same shared loop
bound (`MAX_ITERATIONS = 3`, defined here, enforced by looping callers
such as `draft`'s judge-revision loop), same environment sanitization
(strips `USER` before
passing env to the subprocess), same receipt logging, in one reviewable
place, rather than scattered `subprocess.run(["claude", ...])` calls
across the codebase that could each drift independently.

This is enforced, not just documented: `gtmos eval` runs a static
**harness-contract check** (`gtmos/evals/suite.py::check_harness_contract`)
that scans every `.py` file under `gtmos/` other than `harness.py` for the
signature of a bypass — a `subprocess.run/Popen/call/check_output/
check_call` invocation in a file that also mentions "claude". If any file
outside `harness.py` matches, the check fails and `gtmos eval` exits 1.
Wire `gtmos eval` into CI/pre-push so a chokepoint bypass cannot land
silently.

## Receipts as audit trail

Every harness call appends one line to `~/.gtmos/receipts.jsonl`
(`ts`, `command`, `prompt_chars`, `duration_s`, `exit` — see `PRIVACY.md`
§5 for exact contents, and note it never contains prompt text or CRM
data). `gtmos eval` also runs a **receipts-integrity check**
(`check_receipts_integrity`) that parses every line and confirms the
required keys are present, so a malformed or tampered receipts file is
caught rather than silently trusted.

## Vulnerability disclosure

Report suspected vulnerabilities to **security@kaikarma**. Please include
reproduction steps and the affected file/function where possible. We
follow **90-day coordinated disclosure**: we ask for 90 days from your
report before public disclosure, and commit to keeping you updated on
remediation progress within that window.

## Severity response targets (honest, solo-vendor)

kaikarma is a solo-operator vendor. Response targets are set accordingly
— slower than a funded security team, but real and tracked:

| Severity | Acknowledgment target |
|---|---|
| Critical (e.g. remote data exposure, token leak) | 72 hours |
| High | 5 business days |
| Medium / Low | Best-effort, typically within 2 weeks |

These are acknowledgment targets, not fix SLAs — a fix timeline will be
communicated once the report is triaged.
