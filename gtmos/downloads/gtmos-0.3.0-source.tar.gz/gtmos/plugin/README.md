# GTM OS — Claude Code plugin

Two independent install tiers, on purpose (see below): a **skills tier**
(this plugin — teaches Claude Code how to run and interpret GTM OS) and a
**CLI tier** (the actual `gtmos` self-hosted engine the skills call out to).

## (a) Install the skills — via the plugin marketplace

```
/plugin marketplace add <repo-url-placeholder>
/plugin install gtmos
```

This adds three skills to Claude Code:

- **`crm-integrity-audit`** — run the deterministic CRM Integrity Score
  (`gtmos audit`) against a contacts export or a live HubSpot token, and
  get the score, top 3 fixes, and $-leak estimate explained back to you.
- **`gtm-draft`** — draft LinkedIn/X/outreach copy through `gtmos draft`'s
  judge-gated pipeline (independent pass/fail scoring, not a rubber
  stamp).
- **`gtm-brief`** — assemble the daily/pre-call pipeline brief via
  `gtmos brief` (pipeline state, follow-ups, top 3 actions).

The skills are instructions for Claude Code — they tell it which
`gtmos` commands to run and how to read the output. They do **not**
replace the CLI; without it installed, the skills will tell you so and
point you at tier (b).

## (b) Install the CLI — self-host the engine

```bash
git clone <repo-url-placeholder>
cd gtmos
pip install -e .        # or: uv pip install -e .
gtmos --version
```

This installs the `gtmos` console script: `audit` (deterministic,
offline-capable, no LLM in the score path), plus the harness commands
`prospect`, `stalk`, `draft`, `brief` (which shell out to your own
`claude` CLI + whatever MCP servers you've authorized), and `outcomes`
(a thin wrapper around the `brain` CLI). Full command reference and
architecture in the [gtmos repo README](../README.md).

## Why two tiers

The plugin and the CLI solve different problems. The plugin tier gets
Claude Code to *use* GTM OS correctly out of the box — right commands,
right flags, honest interpretation of a FAIL or a low score — without
you needing to memorize flags or scoring internals. The CLI tier is the
actual audit-first, self-hosted engine: your CRM data, your HubSpot
token, your `claude` CLI auth, nothing leaving your machine except calls
you already authorized. You can run the CLI with zero Claude Code
plugin installed (plain terminal), and you can read/extend the skills
without ever installing the CLI (they're just markdown). Most people
want both: the CLI to do the work, the plugin so Claude Code drives it
correctly the first time.
