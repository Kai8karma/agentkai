---
name: crm-integrity-audit
description: Run the local gtmos CLI's deterministic CRM Integrity Score against a contacts export or a live HubSpot token, then explain the score, the top 3 fixes, and the $-leak estimate in plain language. Trigger phrases -- "audit my crm", "crm integrity score", "how dirty is my hubspot", "score my contacts", "gtm os audit".
---

# CRM Integrity Audit

## When to use this

The user wants to know how clean/reliable their CRM data is, asks for a
"CRM integrity score," wants to know how much revenue is leaking out
through dead/unreachable records, or hands you a contacts export (JSON)
or a HubSpot token and asks you to audit it.

This wraps `gtmos audit` — a deterministic, offline-capable scoring
engine with **no LLM in the scoring path**. Every score is reproducible
from the same input. Your job is to run it and then translate the
output for the user, not to re-score anything yourself.

## Preconditions — check the CLI is available first

```bash
gtmos --version
```

If that fails (`command not found`), the CLI isn't installed. Tell the
user:

> The `gtmos` CLI isn't installed. Install it with `pip install -e .`
> (or `uv pip install -e .`) from the gtmos repo root, then re-run.

Do not attempt to hand-roll a scoring substitute — the whole point of
this audit is a deterministic engine, not an LLM guess.

If `gtmos` is checked out but not installed as a console script, you
can also run it in-place:

```bash
PYTHONPATH=/path/to/gtmos python3 -m gtmos.cli audit --input contacts.json --acv 8000 --out ./audit-out
```

## Exact commands

**Offline, from a contacts JSON export (no token needed):**

```bash
gtmos audit --input contacts.json --acv 8000 --out ./audit-out
```

**Live HubSpot portal:**

```bash
export GTMOS_HUBSPOT_TOKEN=pat-xxxxxxxx
gtmos audit --portal --acv 8000 --out ./audit-out
```

`--acv` is the average contract value the user's business closes at —
ask for it if not given; it only changes the $-leak line, not the
score itself. `--out` defaults to `./audit-out` if omitted.

This writes two files: `audit-out/integrity-report.md` (human-readable)
and `audit-out/scores.json` (machine-readable — read this one if you
need exact numbers to quote).

## How to interpret the output

**Portal score (0–100) and grade.** Bands: A ≥85, B ≥70, C ≥55, D ≥40,
F below 40. This is a weighted blend of five per-record dimensions,
averaged across all records, minus a duplicate-cluster penalty:

| Dimension | Weight | What it measures |
|---|---|---|
| completeness | 30% | email/company/jobtitle/lastname/phone/owner present, not junk placeholders |
| validity | 25% | email format + not a disposable/placeholder domain; phone digit count sane |
| freshness | 25% | recency of `last_activity_date` |
| ownership | 10% | record has an assigned owner |
| consistency | 10% | internal coherence (e.g. lifecycle stage vs. activity) |

Read `## Dimension averages (worst first)` in the report — the lowest
score there is where you should tell the user to focus.

**Top 3 fixes.** Don't invent these — derive them from what the report
actually surfaces:
1. The single worst dimension in the ranked table (highest-leverage
   fix — it's usually the cheapest one too, e.g. "backfill owner" beats
   any activity-driven fix).
2. The duplicate clusters section — if non-empty, merging the largest
   clusters is almost always fix #2 (duplicates suppress both scoring
   and rep trust in the data).
3. The `## Top 20 worst records` table — pull the shared pattern (e.g.
   most of them fail the same dimension) rather than treating them as
   20 separate one-off fixes.

**$-leak explanation.** The report's `## $-leak estimate` section
computes: `unreachable_pct × total_records × ACV × 2%`. "Unreachable"
means `validity < 40 or freshness <= 10` — i.e., the email/phone is
dead or the record hasn't been touched in a long time, so it can't
realistically convert. The 2% is a conservative baseline conversion
rate assumption, not a measured one — say so explicitly when you quote
the number, and note that `--acv` is user-editable if their real
contract value differs from what was passed.

Frame the $-leak number as "money currently unreachable in the
pipeline, priced at your ACV," not as a guaranteed loss — it's a
leak *estimate*, not a forecast.

## Failure modes

- **`command not found: gtmos`** — CLI not installed. Point to `pip
  install -e .` from the gtmos repo, or the `PYTHONPATH=... python3 -m
  gtmos.cli` fallback above.
- **`audit: pass --input <file.json> or --portal ...`** — neither
  source was given. Ask the user for a contacts export path or confirm
  they want to set `GTMOS_HUBSPOT_TOKEN` and use `--portal`.
- **`audit: no contacts found in source`** — the input file parsed but
  was empty; check the export actually contains records.
- **HubSpot fetch error** (`RuntimeError` about the HubSpot API) — the
  token is missing, expired, or scoped wrong. Ask the user to check
  `GTMOS_HUBSPOT_TOKEN` and their HubSpot app's contact-read scope.
- **Report has zero records after a large export** — check the input
  JSON shape matches the expected contact fields (`email`, `firstname`,
  `lastname`, `company`, `jobtitle`, `phone`, `lifecyclestage`,
  `last_activity_date`, `owner`, `createdate`) — a mismatched export
  schema will silently score everything as maximally incomplete.
