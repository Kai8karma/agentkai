---
name: gtm-brief
description: Assemble the daily/pre-call GTM pipeline brief through the gtmos CLI (pipeline state + receipts log + brain search), then present pipeline state, pending follow-ups, and today's top 3 actions. Trigger phrases -- "gtm brief", "pipeline brief", "morning gtm brief", "what should I do today gtm", "gtm os brief".
---

# GTM Brief

## When to use this

The user wants a pipeline/pre-call brief: current deal state, pending
follow-ups, and the highest-leverage actions for the day. This wraps
`gtmos brief`, which combines three inputs inside one harness call:

1. **Pipeline state** — either a live HubSpot deals search (if
   `GTMOS_HUBSPOT_TOKEN` is set) or a `--input` JSON file, or an
   explicit "no pipeline data available" if neither is present. It
   never invents a pipeline number.
2. **Recent gtmos activity** — the local receipts log
   (`~/.gtmos/receipts.jsonl`), read directly, deterministic.
3. **Brain search** — run inside the harness call itself, for open
   follow-ups/flags/decisions tagged to the pilot.

## Preconditions

```bash
gtmos --version
```

If missing, tell the user to install per the crm-integrity-audit skill's
fallback. This command also needs a working `claude` CLI and, if the
user wants live pipeline data instead of an offline file, a valid
`GTMOS_HUBSPOT_TOKEN`.

## Exact commands

**Live (uses `GTMOS_HUBSPOT_TOKEN` if set, else says no data):**

```bash
gtmos brief
```

**Offline, from a pre-fetched pipeline JSON:**

```bash
gtmos brief --input pipeline.json
```

There is no `--acv` flag on `brief` (that's audit-only) and no `--out`
— output prints straight to stdout.

## How to interpret the output

The brief always has exactly three sections:

1. **Pipeline state** — one paragraph, numbers sourced only from the
   pipeline block or brain search. If it says "no pipeline data
   available," that's the CLI being honest that neither
   `GTMOS_HUBSPOT_TOKEN` nor `--input` produced anything — don't treat
   that as a bug, tell the user to set the token or pass an export.
2. **Pending follow-ups** — bullet list from brain search / receipts;
   "none found" is a valid, honest answer, not a failure.
3. **Today's 3 highest-leverage actions** — ranked, one sentence each,
   grounded in the pilot's weekly loop (content → send batch ≥24h later
   → follow-ups/triage → Friday funnel readout) and pre-registered halt
   guards (60-day stop, spend cap, day-30 trip-wire: fewer than 3 calls
   from 75 touches). If a halt guard is at risk, it will surface as one
   of the 3 actions, not buried in a footnote — flag that prominently to
   the user rather than summarizing past it.

Present these three sections to the user roughly as-is; add your own
color only on the "today's 3 actions" section if the user asks you to
prioritize further.

## Failure modes

- **`command not found: gtmos`** — not installed; see install fallback
  in crm-integrity-audit.
- **Pipeline section says "no pipeline data available"** — expected,
  not an error, when there's no token and no `--input`. Ask the user
  which they'd prefer (export a HubSpot deals JSON, or set
  `GTMOS_HUBSPOT_TOKEN`).
- **`HubSpot deals search failed: ...`** — token invalid/expired or
  missing the deals-read scope; ask the user to check
  `GTMOS_HUBSPOT_TOKEN`.
- **Empty/garbled output** — underlying `claude` CLI call failed or hit
  the 180s timeout; check `claude` is on PATH and authenticated. This
  is a harness-layer failure, not a `gtmos brief` logic bug.
- **Brief looks stale on follow-ups** — the receipts log only has
  entries once `gtmos` commands have actually been run on this machine
  (`~/.gtmos/receipts.jsonl`); a fresh install with no history will show
  little/no receipts data, which is expected.
