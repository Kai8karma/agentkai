---
name: gtm-draft
description: Draft LinkedIn posts, X posts, or outreach copy through the gtmos CLI's judge-gated content pipeline, then explain the pass/fail gate scores to the user. Trigger phrases -- "draft a linkedin post", "gtm content", "draft outreach copy", "write an x post about", "gtm os draft".
---

# GTM Draft

## When to use this

The user wants a LinkedIn post, X post, or outreach line drafted through
their own voice + judge gate, rather than a one-shot draft from you
directly. This wraps `gtmos draft`, which:

1. Pulls the user's voice fingerprint and relevant brain memories inside
   one `claude -p` harness call.
2. Writes a draft matching the content type's format rules.
3. Self-scores the draft, then hands it to a **separate, independent
   judge call** (no MCPs, bare mode) that scores it 1–10 on five
   dimensions and decides pass/fail. Self-scores are advisory only —
   the independent judge is what actually gates.
4. Revises up to `MAX_ITERATIONS - 1` times if the judge fails it, then
   reports honest pass/fail — it does not silently ship a failing draft.

Do not draft the content yourself as a substitute for running this —
the whole value is the independent judge gate.

## Preconditions

```bash
gtmos --version
```

If missing, tell the user to `pip install -e .` from the gtmos repo (see
crm-integrity-audit skill for the fallback `PYTHONPATH` invocation).
This command also needs a working `claude` CLI on the user's machine
(it shells out to it) — if that's not set up, `gtmos draft` will fail
at the harness call, not at the CLI-missing check.

## Exact commands

```bash
gtmos draft --type linkedin "why most CRM audits miss the $-leak"
gtmos draft --type x "one-line hook about dead pipeline data"
gtmos draft --type outreach "opening line referencing a specific verified fact"
```

`--type` must be one of `linkedin`, `x`, `outreach`. The topic is a
free-text positional argument — pass through what the user asked for.

Format rules per type (for your own reference, so you can explain a
FAIL sensibly):
- **linkedin** — hook-first, under ~200 words, one idea, no hashtag
  stuffing.
- **x** — single post, under 280 characters, one idea, no thread unless
  asked.
- **outreach** — ≤3 lines, one verified fact/leak, one number, one ask;
  never invents a trigger — if there's no verifiable fact to hang the
  line on, it says so instead of drafting a generic line.

## How to interpret the output

On success you'll see the draft followed by:

```
[gate PASS] VOICE=x HOOK=x DENSITY=x CTA=x FORMAT=x
```

Explain the five dimensions plainly if asked:
- **VOICE** — matches the user's actual voice card (tone, patterns),
  not generic LinkedIn-speak.
- **HOOK** — first line alone earns the read.
- **DENSITY** — no filler, exactly one idea.
- **CTA** — a clear next step, or deliberately none if the format
  doesn't need one.
- **FORMAT** — obeys the type's format rule above.

`GATE_MIN = 8` on every dimension — "8 means genuinely publishable," per
the judge prompt, so a passing score is a real bar, not a rubber stamp.

On failure you'll see:

```
[gate FAIL after 3 attempts] {'HOOK': 5, ...} — do not publish as-is
```

Tell the user plainly which dimension(s) failed and that the CLI itself
is refusing to call it ready — don't paper over a FAIL by presenting
the draft as done. Offer to try again with a narrower topic or more
context (e.g. a specific brain memory or fact to anchor an `outreach`
draft on), since a common failure mode is that the topic itself gave
the model nothing verifiable to hook onto.

## Failure modes

- **`command not found: gtmos`** — not installed; see install fallback
  above.
- **`gtmos draft requires --type one of (...)`** — missing/invalid
  `--type`; ask the user which of linkedin/x/outreach they want.
- **`gtmos draft requires a topic`** — no topic text passed.
- **Empty output / harness returns nothing** — usually means the
  underlying `claude` CLI call failed or timed out (180s cap per call).
  Check the user has `claude` on PATH and is authenticated; this is not
  a `gtmos` bug, it's the harness's single subprocess chokepoint
  failing upstream.
- **Gate FAIL every time on `outreach`** — often means the topic has no
  verifiable fact behind it. Ask the user for a specific data point
  (e.g. an audit finding, a brain memory ID) to anchor the draft on
  instead of a vague topic string.
